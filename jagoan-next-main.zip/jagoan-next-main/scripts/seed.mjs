import mysql from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Read .env.local if exists
const envPath = path.resolve(__dirname, '../.env.local');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  for (const line of envContent.split('\n')) {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
      const [k, ...v] = trimmed.split('=');
      const key = k.trim();
      let val = v.join('=').trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      process.env[key] = val;
    }
  }
}

const host = process.env.TIDB_HOST || 'gateway01.ap-southeast-1.prod.aws.tidbcloud.com';
const port = parseInt(process.env.TIDB_PORT || '4000', 10);
const user = process.env.TIDB_USER || '473gWetUXSjEahq.root';
const password = process.env.TIDB_PASSWORD || 'EZ3EXSaF1bZ8u6lR';
const database = process.env.TIDB_DATABASE || 'test';

console.log(`\n======================================================`);
console.log(`🌱 JAGOAN SEARCH — TIDB CLOUD DATABASE SEEDER (FULL)`);
console.log(`======================================================`);
console.log(`Connecting to TiDB Cloud (${host}:${port}/${database})...\n`);

async function seed() {
  const connection = await mysql.createConnection({
    host,
    port,
    user,
    password,
    database,
    ssl: {
      minVersion: 'TLSv1.2',
      rejectUnauthorized: true,
    },
    connectTimeout: 10000,
  });

  try {
    console.log(`✓ Connected to TiDB Cloud successfully!`);

    // 1. CREATE TABLES
    console.log(`\n1. Creating/Verifying database tables...`);

    // Users
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) UNIQUE NOT NULL,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'agent',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    try {
      await connection.query(`ALTER TABLE users ADD COLUMN username VARCHAR(100) UNIQUE NULL AFTER id;`);
    } catch (e) {
      // already exists
    }
    console.log(`   ✓ Table 'users' ready`);

    // Tutorial Views (Audit Log)
    await connection.query(`
      CREATE TABLE IF NOT EXISTS tutorial_views (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tutorial_id INT NULL,
        tutorial_title VARCHAR(255) NOT NULL,
        tutorial_url VARCHAR(500) NOT NULL,
        username VARCHAR(100) NOT NULL,
        user_role VARCHAR(50) DEFAULT 'agent',
        source VARCHAR(50) DEFAULT 'web',
        viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_username (username),
        INDEX idx_viewed_at (viewed_at),
        INDEX idx_tutorial_id (tutorial_id)
      );
    `);
    console.log(`   ✓ Table 'tutorial_views' (Audit Log) ready`);

    // Categories
    await connection.query(`
      CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log(`   ✓ Table 'categories' ready`);

    // Subcategories
    await connection.query(`
      CREATE TABLE IF NOT EXISTS subcategories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        category_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log(`   ✓ Table 'subcategories' ready`);

    // Checklist Templates
    await connection.query(`
      CREATE TABLE IF NOT EXISTS checklist_templates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        subcategory_id INT NOT NULL,
        parent_id INT DEFAULT NULL,
        trigger_condition VARCHAR(255) DEFAULT NULL,
        task TEXT NOT NULL,
        command_snippet TEXT DEFAULT NULL,
        hint TEXT DEFAULT NULL,
        type VARCHAR(50) DEFAULT 'standard',
        options JSON DEFAULT NULL,
        \`order\` INT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log(`   ✓ Table 'checklist_templates' ready`);

    // Case Reports
    await connection.query(`
      CREATE TABLE IF NOT EXISTS case_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT DEFAULT NULL,
        subcategory_id INT NOT NULL,
        customer_name VARCHAR(150) NOT NULL,
        agent_name VARCHAR(150) NOT NULL,
        ticket_id VARCHAR(50) NOT NULL,
        status VARCHAR(50) DEFAULT 'resolved',
        started_at TIMESTAMP NULL,
        resolved_at TIMESTAMP NULL,
        duration_seconds INT DEFAULT 0,
        csat_score INT DEFAULT 5,
        csat_comment TEXT,
        solution_summary TEXT,
        redundant_checks_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_subcategory (subcategory_id),
        INDEX idx_agent (agent_name)
      );
    `);
    console.log(`   ✓ Table 'case_reports' ready`);

    // Case Report Items
    await connection.query(`
      CREATE TABLE IF NOT EXISTS case_report_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        case_report_id INT NOT NULL,
        task_name TEXT NOT NULL,
        is_checked BOOLEAN DEFAULT TRUE,
        selected_choice VARCHAR(255) DEFAULT NULL,
        note TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log(`   ✓ Table 'case_report_items' ready`);

    // CS Reports (AI Cases)
    await connection.query(`
      CREATE TABLE IF NOT EXISTS cs_reports (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT DEFAULT NULL,
        reporter_name VARCHAR(100) DEFAULT 'Rekan CS',
        platform VARCHAR(100) NOT NULL,
        issue_title VARCHAR(255) NOT NULL,
        error_log TEXT,
        generated_prompt TEXT,
        gemini_solution TEXT,
        status VARCHAR(50) DEFAULT 'open',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_status (status),
        INDEX idx_platform (platform)
      );
    `);
    console.log(`   ✓ Table 'cs_reports' ready`);

    // Tutorials
    await connection.query(`
      CREATE TABLE IF NOT EXISTS tutorials (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) UNIQUE NOT NULL,
        category VARCHAR(100) NOT NULL,
        url VARCHAR(500) NOT NULL,
        excerpt TEXT NOT NULL,
        content LONGTEXT,
        tags JSON,
        reading_time INT DEFAULT 3,
        is_popular BOOLEAN DEFAULT FALSE,
        views_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_category (category),
        INDEX idx_popular (is_popular)
      );
    `);
    console.log(`   ✓ Table 'tutorials' ready`);

    // 2. SEED USERS (Admin + 16 Agents from Media Image)
    console.log(`\n2. Seeding Staff Accounts (Super Admin + 16 CS Agents)...`);
    const users = [
      { id: 1, username: 'admin', name: 'Super Admin', email: 'admin@jagoanhosting.com', pass: '230403', role: 'admin' },
      { id: 2, username: 'annisa', name: 'Annisa', email: 'annisa@jagoanhosting.com', pass: 'Annis@JH73', role: 'agent' },
      { id: 3, username: 'aulia', name: 'Aulia', email: 'aulia@jagoanhosting.com', pass: 'Auli@JH29', role: 'agent' },
      { id: 4, username: 'bima', name: 'Bima', email: 'bima@jagoanhosting.com', pass: 'Bim@JH81', role: 'agent' },
      { id: 5, username: 'devita', name: 'Devita', email: 'devita@jagoanhosting.com', pass: 'Devit@JH45', role: 'agent' },
      { id: 6, username: 'ebik', name: 'Ebik', email: 'ebik@jagoanhosting.com', pass: 'Ebik#JH62', role: 'agent' },
      { id: 7, username: 'efril', name: 'Efril', email: 'efril@jagoanhosting.com', pass: 'Efril#JH38', role: 'agent' },
      { id: 8, username: 'farras', name: 'Farras', email: 'farras@jagoanhosting.com', pass: 'Farr@sJH91', role: 'agent' },
      { id: 9, username: 'fikry', name: 'Fikry', email: 'fikry@jagoanhosting.com', pass: 'Fikry#JH17', role: 'agent' },
      { id: 10, username: 'henry', name: 'Henry', email: 'henry@jagoanhosting.com', pass: 'Henry#JH54', role: 'agent' },
      { id: 11, username: 'hildan', name: 'Hildan', email: 'hildan@jagoanhosting.com', pass: 'Hild@nJH83', role: 'agent' },
      { id: 12, username: 'rompis', name: 'Rompis', email: 'rompis@jagoanhosting.com', pass: 'Rompis#JH26', role: 'agent' },
      { id: 13, username: 'shinta', name: 'Shinta', email: 'shinta@jagoanhosting.com', pass: 'Shint@JH67', role: 'agent' },
      { id: 14, username: 'sielo', name: 'Sielo', email: 'sielo@jagoanhosting.com', pass: 'Sielo#JH92', role: 'agent' },
      { id: 15, username: 'syamsul', name: 'Syamsul', email: 'syamsul@jagoanhosting.com', pass: 'Sy@msulJH48', role: 'agent' },
      { id: 16, username: 'yogi', name: 'Yogi', email: 'yogi@jagoanhosting.com', pass: 'Yogi#JH35', role: 'agent' },
      { id: 17, username: 'yusuf', name: 'Yusuf', email: 'yusuf@jagoanhosting.com', pass: 'Yusuf#JH76', role: 'agent' },
    ];

    for (const u of users) {
      await connection.query(`
        INSERT INTO users (id, username, name, email, password, role)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          username = VALUES(username),
          name = VALUES(name),
          role = VALUES(role),
          password = VALUES(password)
      `, [u.id, u.username, u.name, u.email, u.pass, u.role]);
    }
    console.log(`   ✓ 17 Staf accounts seeded (Super Admin + 16 CS Agents)`);

    // 3. SEED CATEGORIES & SUBCATEGORIES
    console.log(`\n3. Seeding Categories & Decision Tree Subcategories...`);
    const categories = [
      { id: 1, name: 'WordPress' },
      { id: 2, name: 'Laravel' },
      { id: 3, name: 'Node.js' },
      { id: 4, name: 'Email Service' },
      { id: 5, name: 'cPanel & Server' },
      { id: 6, name: 'Database / MySQL' },
    ];
    for (const cat of categories) {
      await connection.query(`
        INSERT INTO categories (id, name)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE name = VALUES(name)
      `, [cat.id, cat.name]);
    }

    const subcategories = [
      { id: 1, category_id: 1, title: 'Critical Error (WSOD / Fatal Error)' },
      { id: 2, category_id: 2, title: 'Deployment & HTTP 500 Server Error' },
      { id: 3, category_id: 3, title: 'Deployment, Build & PM2 Service Down' },
      { id: 4, category_id: 4, title: 'Yahoo Mail Bounce & Sender Authentication (SPF/DKIM)' },
      { id: 5, category_id: 5, title: 'Disk Space Full & Inode Exhausted' },
      { id: 6, category_id: 6, title: 'MySQL 1040 Too Many Connections' },
    ];
    for (const sub of subcategories) {
      await connection.query(`
        INSERT INTO subcategories (id, category_id, title)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE category_id = VALUES(category_id), title = VALUES(title)
      `, [sub.id, sub.category_id, sub.title]);
    }
    console.log(`   ✓ 6 Categories and 6 Subcategories seeded`);

    // 4. SEED ALL 1,854 TUTORIALS IN FAST BATCHES
    console.log(`\n4. Seeding 1,854 Jagoan Hosting Knowledge Base Tutorials...`);
    const tutPath = path.resolve(__dirname, '../src/lib/tutorials_data.json');
    if (fs.existsSync(tutPath)) {
      const tutData = JSON.parse(fs.readFileSync(tutPath, 'utf8'));
      console.log(`   Loaded ${tutData.length} tutorials from ${tutPath}. Inserting into TiDB...`);
      
      const BATCH_SIZE = 150;
      let totalInserted = 0;

      for (let i = 0; i < tutData.length; i += BATCH_SIZE) {
        const batch = tutData.slice(i, i + BATCH_SIZE);
        const values = [];
        const placeholders = [];

        for (const item of batch) {
          placeholders.push('(?, ?, ?, ?, ?, ?, ?, ?)');
          values.push(
            item.title,
            item.slug,
            item.category,
            item.url,
            item.excerpt,
            JSON.stringify(item.tags || ['tutorial']),
            Boolean(item.is_popular),
            item.views_count || Math.floor(Math.random() * 2000) + 150
          );
        }

        const sql = `
          INSERT INTO tutorials (title, slug, category, url, excerpt, tags, is_popular, views_count)
          VALUES ${placeholders.join(', ')}
          ON DUPLICATE KEY UPDATE
            title = VALUES(title),
            category = VALUES(category),
            url = VALUES(url),
            excerpt = VALUES(excerpt),
            tags = VALUES(tags)
        `;

        await connection.query(sql, values);
        totalInserted += batch.length;
        process.stdout.write(`   ✓ Processed ${totalInserted} / ${tutData.length} tutorials...\r`);
      }
      console.log(`\n   ✓ All ${tutData.length} tutorials successfully indexed in TiDB Cloud!`);
    }

    // 5. SEED INITIAL AUDIT LOGS (TUTORIAL VIEWS BY AGENTS)
    console.log(`\n5. Seeding Initial Audit Logs (Tutorial Views by CS Agents)...`);
    const sampleLogs = [
      { tutorial_id: 1, title: 'Mengatasi Error Max Input Vars 1000 Di cPanel', url: 'https://www.jagoanhosting.com/tutorial/tips/mengatasi-error-max-input-vars-1000-di-cpanel', user: 'annisa', role: 'agent', source: 'web' },
      { tutorial_id: 2, title: 'PHP Fatal Error Allowed Memory Size Exhausted', url: 'https://www.jagoanhosting.com/tutorial/tips/php-fatal-error-allowed-memory-size-exhausted', user: 'devita', role: 'agent', source: 'extension' },
      { tutorial_id: 3, title: 'Panduan Add Record DNS Di Plesk Panel', url: 'https://www.jagoanhosting.com/tutorial/reseller-hosting-plesk/panduan-untuk-add-record-dns', user: 'bima', role: 'agent', source: 'web' },
      { tutorial_id: 4, title: 'Cara Setting DMARC Record Pada cPanel', url: 'https://www.jagoanhosting.com/tutorial/cpanel/cara-setting-dmarc-record-pada-cpanel', user: 'annisa', role: 'agent', source: 'extension' },
      { tutorial_id: 5, title: 'Mengatasi Kendala 500 Internal Server Error', url: 'https://www.jagoanhosting.com/tutorial/cpanel/mengatasi-kendala-500-internal-server-error', user: 'aulia', role: 'agent', source: 'web' },
      { tutorial_id: 6, title: 'Panduan File Manager cPanel', url: 'https://www.jagoanhosting.com/tutorial/cpanel/panduan-file-manager-cpanel', user: 'farras', role: 'agent', source: 'extension' },
      { tutorial_id: 7, title: 'Panduan Mengaktifkan 2FA Di cPanel', url: 'https://www.jagoanhosting.com/tutorial/cpanel/panduan-mengaktifkan-2fa-di-cpanel', user: 'fikry', role: 'agent', source: 'web' },
      { tutorial_id: 8, title: 'Cara Install SSL Let\'s Encrypt Di aaPanel', url: 'https://www.jagoanhosting.com/tutorial/vps/cara-install-ssl-lets-encrypt-di-aapanel', user: 'henry', role: 'agent', source: 'extension' },
      { tutorial_id: 9, title: 'Cara Cek Penggunaan Inode Dan Disk Space Di cPanel', url: 'https://www.jagoanhosting.com/tutorial/cpanel/cara-cek-penggunaan-inode', user: 'devita', role: 'agent', source: 'web' },
      { tutorial_id: 10, title: 'Setting SPF Dan DKIM Untuk Yahoo Dan Gmail', url: 'https://www.jagoanhosting.com/tutorial/email/setting-spf-dkim-yahoo-gmail', user: 'annisa', role: 'agent', source: 'web' },
    ];

    for (const log of sampleLogs) {
      await connection.query(`
        INSERT INTO tutorial_views (tutorial_id, tutorial_title, tutorial_url, username, user_role, source)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [log.tutorial_id, log.title, log.url, log.user, log.role, log.source]);
    }
    console.log(`   ✓ 10 Initial tutorial view audit records seeded`);

    console.log(`\n======================================================`);
    console.log(`🎉 ALL DATABASE TABLES & 1,854 TUTORIALS READY IN TIDB!`);
    console.log(`======================================================\n`);
  } catch (err) {
    console.error(`❌ Error during seeding:`, err);
  } finally {
    await connection.end();
  }
}

seed();
