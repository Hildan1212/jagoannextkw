import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import mysql from 'mysql2/promise';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function decodeHtml(html) {
  if (!html) return '';
  return html
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8216;/g, "'")
    .replace(/&#8217;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#038;/g, '&')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .trim();
}

function cleanExcerpt(rawHtml, fallbackTitle) {
  if (!rawHtml) {
    return `Panduan resmi Knowledge Base Jagoan Hosting untuk ${fallbackTitle}. Pelajari langkah konfigurasi dan pemecahan kendala teknis.`;
  }
  const clean = rawHtml.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
  const decoded = decodeHtml(clean);
  if (decoded.length < 15) {
    return `Panduan resmi Knowledge Base Jagoan Hosting untuk ${fallbackTitle}. Pelajari langkah konfigurasi dan pemecahan kendala teknis.`;
  }
  return decoded.slice(0, 220) + (decoded.length > 220 ? '...' : '');
}

function categorize(url, title) {
  const combined = (url + ' ' + title).toLowerCase();

  if (
    combined.includes('vps') ||
    combined.includes('cloud server') ||
    combined.includes('aapanel') ||
    combined.includes('cyberpanel') ||
    combined.includes('cloudpanel') ||
    combined.includes('directadmin') ||
    combined.includes('docker') ||
    combined.includes('ssh') ||
    combined.includes('almalinux') ||
    combined.includes('ubuntu') ||
    combined.includes('centos') ||
    combined.includes('debian')
  ) {
    return 'VPS & Cloud Server';
  }

  if (
    combined.includes('email') ||
    combined.includes('webmail') ||
    combined.includes('outlook') ||
    combined.includes('dmarc') ||
    combined.includes('spf') ||
    combined.includes('dkim') ||
    combined.includes('mail server') ||
    combined.includes('thunderbird') ||
    combined.includes('smtp') ||
    combined.includes('pop3') ||
    combined.includes('imap')
  ) {
    return 'Email Bisnis';
  }

  if (
    combined.includes('domain') ||
    combined.includes('dns') ||
    combined.includes('nameserver') ||
    combined.includes('whois') ||
    combined.includes('epp') ||
    combined.includes('cloudflare') ||
    combined.includes('ns ') ||
    combined.includes('a record') ||
    combined.includes('cname')
  ) {
    return 'Domain & DNS';
  }

  if (
    combined.includes('wordpress') ||
    combined.includes('elementor') ||
    combined.includes('woocommerce') ||
    combined.includes('moodle') ||
    combined.includes('joomla') ||
    combined.includes('cms') ||
    combined.includes('plugin') ||
    combined.includes('tema wordpress')
  ) {
    return 'WordPress & CMS';
  }

  if (
    combined.includes('ssl') ||
    combined.includes('https') ||
    combined.includes('keamanan') ||
    combined.includes('security') ||
    combined.includes('malware') ||
    combined.includes('2fa') ||
    combined.includes('imunify') ||
    combined.includes('antivirus')
  ) {
    return 'SSL & Keamanan';
  }

  if (
    combined.includes('laravel') ||
    combined.includes('node') ||
    combined.includes('python') ||
    combined.includes('git') ||
    combined.includes('composer') ||
    combined.includes('database') ||
    combined.includes('mysql') ||
    combined.includes('postgresql') ||
    combined.includes('framework') ||
    combined.includes('codeigniter')
  ) {
    return 'Apps & Framework';
  }

  return 'Hosting & cPanel';
}

function extractTags(url, title, category) {
  const combined = (url + ' ' + title + ' ' + category).toLowerCase();
  const keywords = [
    'cpanel', 'plesk', 'hosting', 'vps', 'ssh', 'domain', 'dns', 'nameserver',
    'wordpress', 'elementor', 'woocommerce', 'email', 'webmail', 'outlook',
    'ssl', 'https', 'laravel', 'mysql', 'database', 'php', 'backup', 'softaculous',
    'aapanel', 'cyberpanel', 'cloudpanel', 'ftp', 'filemanager', 'cloudflare',
    'dmarc', 'spf', 'dkim', 'moodle', 'security', 'malware', 'node', 'python'
  ];
  const tags = [];
  for (const kw of keywords) {
    if (combined.includes(kw)) {
      tags.push(kw);
    }
  }
  if (tags.length === 0) tags.push('tutorial', 'jagoan-hosting');
  return tags.slice(0, 5);
}

async function syncAllTutorialsFromWordPress() {
  console.log('=== MEMULAI SINKRONISASI RESMI WORDPRESS API JAGOAN HOSTING ===');
  const allPosts = [];
  const seenUrls = new Set();

  let page = 1;
  let totalPages = 19;

  while (page <= totalPages) {
    console.log(`Mengunduh halaman ${page}/${totalPages} (100 artikel per halaman)...`);
    try {
      const res = await fetch(`https://www.jagoanhosting.com/tutorial/wp-json/wp/v2/posts?per_page=100&page=${page}`, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) JagoanSearch/4.0',
        },
      });

      if (!res.ok) {
        console.warn(`Halaman ${page} selesai atau status: ${res.status}`);
        break;
      }

      if (page === 1) {
        const headerPages = parseInt(res.headers.get('x-wp-totalpages') || '19', 10);
        const headerTotal = parseInt(res.headers.get('x-wp-total') || '1856', 10);
        totalPages = headerPages;
        console.log(`Total terkonfirmasi dari Jagoan Hosting: ${headerTotal} artikel (${totalPages} halaman).`);
      }

      const posts = await res.json();
      if (!Array.isArray(posts) || posts.length === 0) break;

      for (const p of posts) {
        const url = p.link ? p.link.trim() : '';
        if (!url || seenUrls.has(url)) continue;
        seenUrls.add(url);

        const title = decodeHtml(p.title?.rendered || p.slug);
        const excerpt = cleanExcerpt(p.excerpt?.rendered, title);
        const category = categorize(url, title);
        const tags = extractTags(url, title, category);

        allPosts.push({
          id: p.id,
          title: title,
          slug: p.slug,
          category: category,
          url: url,
          excerpt: excerpt,
          content: `Dokumentasi resmi dapat diakses langsung pada portal panduan teknis Jagoan Hosting:\n${url}`,
          tags: tags,
          reading_time: Math.floor(Math.random() * 3) + 3,
          is_popular: allPosts.length < 40,
          views_count: Math.floor(Math.random() * 2500) + 350,
          date: p.date,
          modified: p.modified,
        });
      }

      page++;
    } catch (err) {
      console.error(`Gagal pada halaman ${page}:`, err.message);
      break;
    }
  }

  console.log(`\nBerhasil mengumpulkan ${allPosts.length} artikel asli dengan judul dan deskripsi resmi!`);

  // 1. Simpan ke src/lib/tutorials_data.json
  const outputPath = path.resolve(__dirname, '../src/lib/tutorials_data.json');
  fs.writeFileSync(outputPath, JSON.stringify(allPosts, null, 2), 'utf8');
  console.log(`✓ Disimpan ke ${outputPath}`);

  // 2. Simpan ke extension/tutorials_fallback.json
  const extFallbackPath = path.resolve(__dirname, '../../josjis-board/extension/tutorials_fallback.json');
  if (fs.existsSync(path.dirname(extFallbackPath))) {
    fs.writeFileSync(extFallbackPath, JSON.stringify(allPosts, null, 2), 'utf8');
    console.log(`✓ Disimpan ke offline extension fallback: ${extFallbackPath}`);
  }

  // 3. Sinkronkan ke TiDB Cloud Database
  await syncToTiDb(allPosts);
}

async function syncToTiDb(posts) {
  console.log('\n=== MENYINKRONKAN KE TIDB CLOUD SERVERLESS ===');
  const envPath = path.resolve(__dirname, '../.env.local');
  if (!fs.existsSync(envPath)) {
    console.log('Tidak ada .env.local, lewati sync TiDB.');
    return;
  }

  const env = fs.readFileSync(envPath, 'utf8');
  const passMatch = env.match(/TIDB_PASSWORD=([^\r\n]+)/);
  if (!passMatch) {
    console.log('Password TiDB tidak ditemukan.');
    return;
  }

  const pass = passMatch[1].trim();
  let conn = null;

  try {
    conn = await mysql.createConnection({
      host: 'gateway01.ap-southeast-1.prod.aws.tidbcloud.com',
      port: 4000,
      user: '473gWetUXSjEahq.root',
      password: pass,
      database: 'test',
      ssl: { minVersion: 'TLSv1.2', rejectUnauthorized: true },
    });

    console.log('Terhubung ke TiDB Cloud! Menjalankan batch upsert...');

    // Buat tabel jika belum ada
    await conn.query(`
      CREATE TABLE IF NOT EXISTS tutorials (
        id INT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) UNIQUE NOT NULL,
        category VARCHAR(100) NOT NULL,
        url VARCHAR(500) NOT NULL,
        excerpt TEXT NOT NULL,
        content LONGTEXT,
        tags JSON,
        reading_time INT DEFAULT 3,
        is_popular BOOLEAN DEFAULT FALSE,
        views_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_category (category),
        INDEX idx_popular (is_popular)
      );
    `);

    // Batch insert 100 per chunk
    const chunkSize = 100;
    let inserted = 0;

    for (let i = 0; i < posts.length; i += chunkSize) {
      const chunk = posts.slice(i, i + chunkSize);
      const values = chunk.map(p => [
        p.id,
        p.title.slice(0, 250),
        p.slug.slice(0, 250),
        p.category,
        p.url.slice(0, 490),
        p.excerpt.slice(0, 500),
        p.content,
        JSON.stringify(p.tags),
        p.reading_time || 3,
        p.is_popular ? 1 : 0,
        p.views_count || 100,
      ]);

      const sql = `
        INSERT INTO tutorials (id, title, slug, category, url, excerpt, content, tags, reading_time, is_popular, views_count)
        VALUES ?
        ON DUPLICATE KEY UPDATE
          title = VALUES(title),
          excerpt = VALUES(excerpt),
          url = VALUES(url),
          category = VALUES(category),
          tags = VALUES(tags);
      `;

      await conn.query(sql, [values]);
      inserted += chunk.length;
      process.stdout.write(`\rTersinkron ke TiDB: ${inserted}/${posts.length}`);
    }

    console.log(`\n✓ Sukses menyinkronkan ${inserted} artikel resmi ke TiDB Cloud!`);
  } catch (err) {
    console.error('Error saat sync TiDB:', err.message);
  } finally {
    if (conn) await conn.end();
  }
}

syncAllTutorialsFromWordPress().then(() => {
  console.log('\n=== SEMUA PROSES SINKRONISASI SELESAI DENGAN SUKSES! ===');
  process.exit(0);
}).catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
