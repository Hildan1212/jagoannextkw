import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SITEMAP_URLS = [
  'https://www.jagoanhosting.com/tutorial/post-sitemap.xml',
  'https://www.jagoanhosting.com/tutorial/post-sitemap2.xml'
];

function cleanTitleFromSlug(slug, catSegment) {
  let title = slug.replace(/-/g, ' ').trim();
  
  // Replace acronyms and technical names with correct casing
  const replacements = [
    [/\bvps\b/gi, 'VPS'],
    [/\bdns\b/gi, 'DNS'],
    [/\bssl\b/gi, 'SSL'],
    [/\bssh\b/gi, 'SSH'],
    [/\bphp\b/gi, 'PHP'],
    [/\bcpanel\b/gi, 'cPanel'],
    [/\bplesk\b/gi, 'Plesk'],
    [/\baapanel\b/gi, 'aaPanel'],
    [/\bcyberpanel\b/gi, 'CyberPanel'],
    [/\bcloudpanel\b/gi, 'CloudPanel'],
    [/\bdirectadmin\b/gi, 'DirectAdmin'],
    [/\bwordpress\b/gi, 'WordPress'],
    [/\blaravel\b/gi, 'Laravel'],
    [/\bnodejs\b/gi, 'Node.js'],
    [/\bpython\b/gi, 'Python'],
    [/\bmysql\b/gi, 'MySQL'],
    [/\bftp\b/gi, 'FTP'],
    [/\bseo\b/gi, 'SEO'],
    [/\bapi\b/gi, 'API'],
    [/\bdkim\b/gi, 'DKIM'],
    [/\bspf\b/gi, 'SPF'],
    [/\bdmarc\b/gi, 'DMARC'],
    [/\bhttp\b/gi, 'HTTP'],
    [/\bhttps\b/gi, 'HTTPS'],
    [/\bip\b/gi, 'IP'],
    [/\bgit\b/gi, 'Git'],
    [/\bcms\b/gi, 'CMS'],
    [/\bwhm\b/gi, 'WHM'],
    [/\bwebmail\b/gi, 'Webmail'],
    [/\bcloudflare\b/gi, 'Cloudflare'],
    [/\belementor\b/gi, 'Elementor'],
    [/\bwoocommerce\b/gi, 'WooCommerce'],
    [/\bsoftaculous\b/gi, 'Softaculous'],
    [/\bnameserver\b/gi, 'Nameserver'],
    [/\baddon\b/gi, 'Addon'],
    [/\bsubdomain\b/gi, 'Subdomain'],
  ];

  for (const [pattern, replacement] of replacements) {
    title = title.replace(pattern, replacement);
  }

  // Capitalize remaining words
  return title.split(' ').map(word => {
    if (word.length === 0) return '';
    // If it's already mixed/uppercase acronym, keep it
    if (word.toUpperCase() === word && word.length > 1) return word;
    if (['cPanel', 'aaPanel', 'CyberPanel', 'CloudPanel', 'Node.js', 'DirectAdmin', 'WordPress', 'WooCommerce', 'Softaculous', 'Cloudflare'].includes(word)) return word;
    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
  }).join(' ');
}

function categorize(url, title, catSegment) {
  const combined = (url + ' ' + title + ' ' + catSegment).toLowerCase();

  if (
    combined.includes('vps') ||
    combined.includes('cloud server') ||
    combined.includes('aapanel') ||
    combined.includes('cyberpanel') ||
    combined.includes('cloudpanel') ||
    combined.includes('directadmin') ||
    combined.includes('docker') ||
    combined.includes('ssh') ||
    combined.includes('almalinux') ||
    combined.includes('ubuntu') ||
    combined.includes('centos') ||
    combined.includes('debian')
  ) {
    return 'VPS & Cloud Server';
  }

  if (
    combined.includes('email') ||
    combined.includes('webmail') ||
    combined.includes('outlook') ||
    combined.includes('dmarc') ||
    combined.includes('spf') ||
    combined.includes('dkim') ||
    combined.includes('mail server') ||
    combined.includes('thunderbird') ||
    combined.includes('smtp') ||
    combined.includes('pop3') ||
    combined.includes('imap')
  ) {
    return 'Email Bisnis';
  }

  if (
    combined.includes('domain') ||
    combined.includes('dns') ||
    combined.includes('nameserver') ||
    combined.includes('whois') ||
    combined.includes('epp') ||
    combined.includes('cloudflare') ||
    combined.includes('ns ') ||
    combined.includes('a record') ||
    combined.includes('cname')
  ) {
    return 'Domain & DNS';
  }

  if (
    combined.includes('wordpress') ||
    combined.includes('elementor') ||
    combined.includes('woocommerce') ||
    combined.includes('moodle') ||
    combined.includes('joomla') ||
    combined.includes('cms') ||
    combined.includes('plugin') ||
    combined.includes('tema wordpress')
  ) {
    return 'WordPress & CMS';
  }

  if (
    combined.includes('ssl') ||
    combined.includes('https') ||
    combined.includes('keamanan') ||
    combined.includes('security') ||
    combined.includes('malware') ||
    combined.includes('2fa') ||
    combined.includes('imunify') ||
    combined.includes('antivirus')
  ) {
    return 'SSL & Keamanan';
  }

  if (
    combined.includes('laravel') ||
    combined.includes('node') ||
    combined.includes('python') ||
    combined.includes('git') ||
    combined.includes('composer') ||
    combined.includes('database') ||
    combined.includes('mysql') ||
    combined.includes('postgresql') ||
    combined.includes('framework') ||
    combined.includes('codeigniter')
  ) {
    return 'Apps & Framework';
  }

  return 'Hosting & cPanel';
}

function extractTags(url, title, category) {
  const combined = (url + ' ' + title + ' ' + category).toLowerCase();
  const keywords = [
    'cpanel', 'plesk', 'hosting', 'vps', 'ssh', 'domain', 'dns', 'nameserver',
    'wordpress', 'elementor', 'woocommerce', 'email', 'webmail', 'outlook',
    'ssl', 'https', 'laravel', 'mysql', 'database', 'php', 'backup', 'softaculous',
    'aapanel', 'cyberpanel', 'cloudpanel', 'ftp', 'filemanager', 'cloudflare',
    'dmarc', 'spf', 'dkim', 'moodle', 'security', 'malware', 'node', 'python'
  ];
  const tags = [];
  for (const kw of keywords) {
    if (combined.includes(kw)) {
      tags.push(kw);
    }
  }
  if (tags.length === 0) tags.push('tutorial', 'jagoan-hosting');
  return tags.slice(0, 5);
}

export async function fetchAllTutorials() {
  console.log('Fetching sitemaps from Jagoan Hosting...');
  const allItems = [];
  const seenUrls = new Set();
  let idCounter = 1;

  for (const sitemapUrl of SITEMAP_URLS) {
    console.log(`Downloading: ${sitemapUrl}`);
    const res = await fetch(sitemapUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) JagoanSearch/3.0'
      }
    });
    const xml = await res.text();

    const matches = [...xml.matchAll(/<url>\s*<loc>([^<]+)<\/loc>(?:\s*<lastmod>([^<]*)<\/lastmod>)?/gi)];
    console.log(`Parsed ${matches.length} entries from ${sitemapUrl}`);

    for (const match of matches) {
      const url = match[1].trim();
      const lastmod = match[2] ? match[2].trim() : null;

      if (!url.includes('jagoanhosting.com/tutorial/') || seenUrls.has(url)) {
        continue;
      }
      seenUrls.add(url);

      const pathPart = new URL(url).pathname.replace(/^\/tutorial\/?/, '').replace(/\/$/, '');
      const segments = pathPart.split('/').filter(Boolean);

      if (segments.length === 0) continue;

      const slug = segments[segments.length - 1];
      const catSegment = segments.length > 1 ? segments[0] : 'hosting';

      // Ignore pure numbers or single characters if any
      if (!slug || /^\d+$/.test(slug)) {
        // e.g. 430
        continue;
      }

      const title = cleanTitleFromSlug(slug, catSegment);
      const category = categorize(url, title, catSegment);
      const tags = extractTags(url, title, category);

      allItems.push({
        id: idCounter++,
        title: title,
        slug: slug,
        category: category,
        url: url,
        excerpt: `Panduan resmi Knowledge Base Jagoan Hosting: ${title}. Pelajari langkah konfigurasi, verifikasi sistem, dan pemecahan kendala teknis.`,
        content: `Dokumentasi dan tutorial resmi dapat diakses langsung pada portal panduan teknis Jagoan Hosting:\n${url}`,
        tags: tags,
        reading_time: Math.floor(Math.random() * 4) + 3,
        is_popular: idCounter <= 35,
        views_count: Math.floor(Math.random() * 2000) + 150,
        lastmod: lastmod,
      });
    }
  }

  console.log(`Total valid, clean tutorials parsed: ${allItems.length}`);
  return allItems;
}

// If run directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  fetchAllTutorials().then(items => {
    const outputPath = path.resolve(__dirname, '../src/lib/tutorials_data.json');
    fs.writeFileSync(outputPath, JSON.stringify(items, null, 2), 'utf8');
    console.log(`✓ Saved ${items.length} tutorials to ${outputPath}`);
  }).catch(console.error);
}
