import mysql from 'mysql2/promise';
import fs from 'fs';

const env = fs.readFileSync('.env.local', 'utf8');
const passMatch = env.match(/TIDB_PASSWORD=(.*)/);
const pass = passMatch ? passMatch[1].trim() : 'EZ3EXSaF1bZ8u6lR';

async function run() {
  const conn = await mysql.createConnection({
    host: 'gateway01.ap-southeast-1.prod.aws.tidbcloud.com',
    port: 4000,
    user: '473gWetUXSjEahq.root',
    password: pass,
    database: 'test',
    ssl: { minVersion: 'TLSv1.2', rejectUnauthorized: true },
  });

  const [existing] = await conn.query('SELECT id FROM cs_reports WHERE issue_title LIKE ?', ['%IP Terblokir pada Imunify360%']);
  const solutionText = `Apabila ada kendala IP jaringan user terblokir pada server, silakan jalankan langkah-langkah berikut di teleport:

1. Cek Status Blokir IP
Lakukan pengecekan apakah IP terblokir atau tidak dengan menjalankan command berikut:
imunify360-agent ip-list local list --by-ip [ip-pelanggan]
(Contoh: imunify360-agent ip-list local list --by-ip 182.9.98.2)

2. Hapus Blokir (Unblock) IP
Jika hasil pengecekan menunjukkan IP terblokir dan pada keterangan purpose terdapat status "drop", gunakan command ini untuk menghapusnya:
imunify360-agent ip-list local delete --purpose drop [ip-pelanggan]

3. Verifikasi Ulang
Setelah eksekusi penghapusan, cek kembali menggunakan command pada langkah pertama untuk memastikan IP benar-benar sudah terhapus dari daftar blokir.`;

  if (existing.length === 0) {
    const [res] = await conn.query(
      `INSERT INTO cs_reports (user_id, reporter_name, platform, issue_title, error_log, generated_prompt, gemini_solution, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        1,
        'Rekan CS',
        'Imunify360 & Teleport',
        'IP Terblokir pada Imunify360',
        'IP jaringan user terblokir pada server (status drop)',
        'Langkah unblock IP di Teleport Imunify360',
        solutionText,
        'solved',
      ]
    );
    console.log('Inserted Imunify360 case into TiDB, ID:', res.insertId);
  } else {
    await conn.query('UPDATE cs_reports SET gemini_solution = ?, platform = ?, status = ? WHERE id = ?', [
      solutionText,
      'Imunify360 & Teleport',
      'solved',
      existing[0].id,
    ]);
    console.log('Updated Imunify360 case in TiDB, ID:', existing[0].id);
  }

  // Also ensure table cs_external_links exists in TiDB
  await conn.query(`
    CREATE TABLE IF NOT EXISTS cs_external_links (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      url VARCHAR(500) NOT NULL,
      category VARCHAR(100) DEFAULT 'Solusi CS',
      description TEXT,
      created_by_username VARCHAR(100) NOT NULL,
      created_by_name VARCHAR(100) NOT NULL,
      views_count INT DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_title (title)
    );
  `);
  console.log('Table cs_external_links verified/created in TiDB.');

  // Seed React JS deployment external link if not exists
  const [extLinks] = await conn.query('SELECT id FROM cs_external_links WHERE title LIKE ?', ['%Deploy React JS%']);
  if (extLinks.length === 0) {
    await conn.query(
      `INSERT INTO cs_external_links (title, url, category, description, created_by_username, created_by_name)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        'Cara Deploy React JS di Hosting cPanel',
        'https://www.jagoanhosting.com/tutorial/hosting/cara-deploy-react-js-di-cpanel',
        'Apps & Framework',
        'Panduan build React (npm run build), upload dist/build ke public_html cPanel, dan konfigurasi .htaccess fallback routing.',
        'farras',
        'Farras',
      ]
    );
    console.log('Sample CS External Link inserted.');
  }

  await conn.end();
}

run().catch(console.error);
