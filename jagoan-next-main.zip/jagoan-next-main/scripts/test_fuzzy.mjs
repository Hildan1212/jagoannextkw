import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tutorials = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../src/lib/tutorials_data.json'), 'utf8'));

export function calculateFuzzyScore(query, title, excerpt = '', tags = []) {
  const q = query.toLowerCase().trim();
  const t = title.toLowerCase();
  const e = (excerpt || '').toLowerCase();
  const tagStr = (tags || []).join(' ').toLowerCase();

  // 1. Exact match
  if (t === q) return 1000;
  if (t.includes(q)) return 500 + (q.length / t.length) * 100;
  if (e.includes(q)) return 300;
  if (tagStr.includes(q)) return 250;

  // 2. Tokenized words match
  const words = q.split(/\s+/).filter(w => w.length >= 2);
  let wordHits = 0;
  for (const w of words) {
    if (t.includes(w)) wordHits += 2;
    else if (e.includes(w)) wordHits += 1;
    else if (tagStr.includes(w)) wordHits += 1;
  }
  if (words.length > 0 && wordHits > 0) {
    return 100 + (wordHits / words.length) * 80;
  }

  // 3. Trigram similarity for typo tolerance
  if (q.length >= 3) {
    const qTrigrams = new Set();
    for (let i = 0; i <= q.length - 3; i++) {
      qTrigrams.add(q.slice(i, i + 3));
    }

    let matchCount = 0;
    for (let i = 0; i <= t.length - 3; i++) {
      if (qTrigrams.has(t.slice(i, i + 3))) {
        matchCount++;
      }
    }

    const similarity = matchCount / Math.max(1, qTrigrams.size);
    if (similarity > 0.25) {
      return 50 * similarity;
    }
  }

  // 4. Character overlap
  let charMatches = 0;
  const uniqueChars = new Set(q.replace(/\s+/g, ''));
  for (const ch of uniqueChars) {
    if (t.includes(ch)) charMatches++;
  }
  const ratio = charMatches / uniqueChars.size;
  if (ratio > 0.65) {
    return 10 * ratio;
  }

  return 0;
}

const testQueries = ['wordpres', 'eror 500', 'cpanl', 'sql conecktion', 'subdmain', 'dmarck', 'plesk mail'];

for (const q of testQueries) {
  const t0 = performance.now();
  const scored = tutorials
    .map(tut => ({
      title: tut.title,
      score: calculateFuzzyScore(q, tut.title, tut.excerpt, tut.tags),
      category: tut.category
    }))
    .filter(x => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);
  const dur = (performance.now() - t0).toFixed(2);
  console.log(`\nQuery: '${q}' (${dur}ms):`);
  scored.forEach((s, idx) => console.log(`   ${idx + 1}. [score ${s.score.toFixed(1)}] ${s.title} (${s.category})`));
}
