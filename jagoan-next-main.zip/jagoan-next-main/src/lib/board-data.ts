export interface Category {
  id: number;
  name: string;
}

export interface Subcategory {
  id: number;
  category_id: number;
  title: string;
}

export interface ChecklistTemplate {
  id: number;
  subcategory_id: number;
  parent_id?: number | null;
  trigger_condition?: string | null;
  task: string;
  command_snippet?: string | null;
  hint?: string | null;
  type: 'standard' | 'choice';
  options?: string[] | null;
  order: number;
}

export interface CaseReportItem {
  id?: number;
  case_report_id?: number;
  task_name: string;
  is_checked: boolean;
  selected_choice?: string | null;
  note?: string | null;
}

export interface CaseReport {
  id: number;
  user_id?: number;
  subcategory_id: number;
  customer_name: string;
  agent_name: string;
  ticket_id: string;
  status: string;
  started_at: string;
  resolved_at: string;
  duration_seconds: number;
  csat_score: number;
  csat_comment?: string;
  solution_summary?: string;
  redundant_checks_count?: number;
  created_at: string;
  items?: CaseReportItem[];
  subcategory_title?: string;
}

export interface CsReport {
  id: number;
  user_id?: number;
  reporter_name: string;
  platform: string;
  issue_title: string;
  error_log?: string | null;
  generated_prompt?: string | null;
  gemini_solution?: string | null;
  status: 'open' | 'solved';
  created_at: string;
}

export interface StaffUser {
  id: number;
  username: string;
  name: string;
  email?: string;
  role: 'admin' | 'agent';
  password?: string;
}

export const INITIAL_STAFF_USERS: StaffUser[] = [
  { id: 1, username: 'admin', name: 'Super Admin', email: 'admin@jagoanhosting.com', role: 'admin', password: '230403' },
  { id: 2, username: 'annisa', name: 'Annisa', email: 'annisa@jagoanhosting.com', role: 'agent', password: 'Annis@JH73' },
  { id: 3, username: 'aulia', name: 'Aulia', email: 'aulia@jagoanhosting.com', role: 'agent', password: 'Auli@JH29' },
  { id: 4, username: 'bima', name: 'Bima', email: 'bima@jagoanhosting.com', role: 'agent', password: 'Bim@JH81' },
  { id: 5, username: 'devita', name: 'Devita', email: 'devita@jagoanhosting.com', role: 'agent', password: 'Devit@JH45' },
  { id: 6, username: 'ebik', name: 'Ebik', email: 'ebik@jagoanhosting.com', role: 'agent', password: 'Ebik#JH62' },
  { id: 7, username: 'efril', name: 'Efril', email: 'efril@jagoanhosting.com', role: 'agent', password: 'Efril#JH38' },
  { id: 8, username: 'farras', name: 'Farras', email: 'farras@jagoanhosting.com', role: 'agent', password: 'Farr@sJH91' },
  { id: 9, username: 'fikry', name: 'Fikry', email: 'fikry@jagoanhosting.com', role: 'agent', password: 'Fikry#JH17' },
  { id: 10, username: 'henry', name: 'Henry', email: 'henry@jagoanhosting.com', role: 'agent', password: 'Henry#JH54' },
  { id: 11, username: 'hildan', name: 'Hildan', email: 'hildan@jagoanhosting.com', role: 'agent', password: 'Hild@nJH83' },
  { id: 12, username: 'rompis', name: 'Rompis', email: 'rompis@jagoanhosting.com', role: 'agent', password: 'Rompis#JH26' },
  { id: 13, username: 'shinta', name: 'Shinta', email: 'shinta@jagoanhosting.com', role: 'agent', password: 'Shint@JH67' },
  { id: 14, username: 'sielo', name: 'Sielo', email: 'sielo@jagoanhosting.com', role: 'agent', password: 'Sielo#JH92' },
  { id: 15, username: 'syamsul', name: 'Syamsul', email: 'syamsul@jagoanhosting.com', role: 'agent', password: 'Sy@msulJH48' },
  { id: 16, username: 'yogi', name: 'Yogi', email: 'yogi@jagoanhosting.com', role: 'agent', password: 'Yogi#JH35' },
  { id: 17, username: 'yusuf', name: 'Yusuf', email: 'yusuf@jagoanhosting.com', role: 'agent', password: 'Yusuf#JH76' },
];

export const INITIAL_CATEGORIES: Category[] = [
  { id: 1, name: 'WordPress' },
  { id: 2, name: 'Laravel' },
  { id: 3, name: 'Node.js' },
  { id: 4, name: 'Email Service' },
  { id: 5, name: 'cPanel & Server' },
  { id: 6, name: 'Database / MySQL' },
];

export const INITIAL_SUBCATEGORIES: Subcategory[] = [
  { id: 1, category_id: 1, title: 'Critical Error (WSOD / Fatal Error)' },
  { id: 2, category_id: 2, title: 'Deployment & HTTP 500 Server Error' },
  { id: 3, category_id: 3, title: 'Deployment, Build & PM2 Service Down' },
  { id: 4, category_id: 4, title: 'Yahoo Mail Bounce & Sender Authentication (SPF/DKIM)' },
  { id: 5, category_id: 5, title: 'Disk Space Full & Inode Exhausted' },
  { id: 6, category_id: 6, title: 'MySQL 1040 Too Many Connections' },
];

export const INITIAL_CHECKLIST_TEMPLATES: ChecklistTemplate[] = [
  // 1. WordPress (Critical Error)
  {
    id: 1,
    subcategory_id: 1,
    task: 'Tahap 1: Uji coba dengan tema default WordPress',
    command_snippet: 'wp theme activate twentytwentyfour --allow-root',
    hint: 'Langkah baku pertama: Switch sementara ke tema default untuk memastikan apakah crash dipicu oleh tema aktif.',
    type: 'choice',
    options: ['Normal (Tema Crash)', 'Masih Error'],
    order: 1,
  },
  {
    id: 2,
    subcategory_id: 1,
    parent_id: 1,
    trigger_condition: 'Normal (Tema Crash)',
    task: 'Akses wp-content/themes/ lalu rename folder tema aktif sebagai backup',
    command_snippet: 'mv wp-content/themes/[tema-aktif] wp-content/themes/[tema-aktif]-disabled',
    hint: 'Website sudah pulih dengan tema default. Amankan folder tema lama agar pelanggan bisa login.',
    type: 'standard',
    order: 1,
  },
  {
    id: 3,
    subcategory_id: 1,
    parent_id: 1,
    trigger_condition: 'Normal (Tema Crash)',
    task: 'Catat error pada file functions.php / template tema dan konfirmasi ke pelanggan',
    command_snippet: 'cat wp-content/debug.log | grep -i "functions.php"',
    hint: 'Beri rekomendasi update versi tema atau hubungi developer tema.',
    type: 'standard',
    order: 2,
  },
  {
    id: 4,
    subcategory_id: 1,
    parent_id: 1,
    trigger_condition: 'Masih Error',
    task: 'Tahap 2: Pengecekan Plugin (Cek debug.log & isolasi plugin)',
    command_snippet: 'tail -n 60 wp-content/debug.log | grep -i "Fatal error"',
    hint: 'Langkah baku kedua: Periksa error_log/debug.log untuk mengisolasi plugin penyebab Fatal Error.',
    type: 'choice',
    options: ['Plugin Crash Teridentifikasi', 'Bukan Masalah Plugin'],
    order: 2,
  },
  {
    id: 5,
    subcategory_id: 1,
    parent_id: 4,
    trigger_condition: 'Plugin Crash Teridentifikasi',
    task: 'Nonaktifkan plugin bermasalah via WP-CLI atau rename foldernya di wp-content/plugins/',
    command_snippet: 'wp plugin deactivate [nama-plugin] --allow-root',
    hint: 'Bila WP-CLI tidak tersedia, rename folder: mv wp-content/plugins/plugin-x wp-content/plugins/plugin-x_old',
    type: 'standard',
    order: 1,
  },
  {
    id: 6,
    subcategory_id: 1,
    parent_id: 4,
    trigger_condition: 'Plugin Crash Teridentifikasi',
    task: 'Buka kembali WP-Admin dan pastikan dashboard serta frontend normal kembali',
    command_snippet: 'curl -I https://domain-pelanggan.com',
    hint: 'Pastikan HTTP Response Code kembali 200 OK.',
    type: 'standard',
    order: 2,
  },
  {
    id: 7,
    subcategory_id: 1,
    parent_id: 4,
    trigger_condition: 'Bukan Masalah Plugin',
    task: 'Tahap 3: Pemeriksaan WordPress Core & Lingkungan PHP',
    command_snippet: 'wp core verify-checksums --allow-root',
    hint: 'Langkah baku ketiga: Verifikasi integritas core file (wp-includes & wp-admin) serta cek kompatibilitas PHP server.',
    type: 'choice',
    options: ['Core Reinstalled (Normal)', 'Masih Rusak / Data Korup'],
    order: 3,
  },
  {
    id: 8,
    subcategory_id: 1,
    parent_id: 7,
    trigger_condition: 'Core Reinstalled (Normal)',
    task: 'Download ulang core files yang hilang/korup tanpa menyentuh wp-content',
    command_snippet: 'wp core download --skip-content --force --allow-root',
    hint: 'Ganti wp-admin dan wp-includes baru untuk membersihkan file core rusak.',
    type: 'standard',
    order: 1,
  },
  {
    id: 9,
    subcategory_id: 1,
    parent_id: 7,
    trigger_condition: 'Core Reinstalled (Normal)',
    task: 'Sesuaikan versi PHP di cPanel / Server ke PHP 8.1 atau 8.2 yang stabil',
    hint: 'Banyak kasus critical error terjadi karena hosting beralih ke PHP 8.3/8.4 sebelum core WP terupdate.',
    type: 'standard',
    order: 2,
  },
  {
    id: 10,
    subcategory_id: 1,
    parent_id: 7,
    trigger_condition: 'Masih Rusak / Data Korup',
    task: 'Tahap 4: Langkah Terakhir - Restore Backup atau Eskalasi L2',
    hint: 'Langkah baku penutup: Restore dari snapshot backup terdekat atau eskalasi ke Level 2.',
    type: 'choice',
    options: ['Restore Backup Berhasil', 'Eskalasi ke Sysadmin L2'],
    order: 4,
  },
  {
    id: 11,
    subcategory_id: 1,
    parent_id: 10,
    trigger_condition: 'Restore Backup Berhasil',
    task: 'Pilih snapshot backup 24 jam terakhir dan lakukan restore penuh (Files & Database)',
    hint: 'Pastikan konfirmasi ke pelanggan bahwa data akan kembali ke snapshot sebelum error terjadi.',
    type: 'standard',
    order: 1,
  },
  {
    id: 12,
    subcategory_id: 1,
    parent_id: 10,
    trigger_condition: 'Eskalasi ke Sysadmin L2',
    task: 'Lampirkan ringkasan hasil uji Tahap 1-3 pada tiket eskalasi agar tidak dicek berulang oleh tim L2',
    hint: 'Dokumentasikan hasil tes tema, plugin, core, dan log error secara rapi.',
    type: 'standard',
    order: 2,
  },

  // 2. Laravel (Deployment & HTTP 500)
  {
    id: 13,
    subcategory_id: 2,
    task: 'Cek storage/logs/laravel.log dan jenis error 500',
    command_snippet: 'tail -n 50 storage/logs/laravel.log',
    hint: 'Periksa baris error terakhir di file log untuk mengetahui penyebab utama error 500.',
    type: 'choice',
    options: ['Permission / Symlink', 'Database / Migration', 'App Key & Config Cache'],
    order: 1,
  },
  {
    id: 14,
    subcategory_id: 2,
    parent_id: 13,
    trigger_condition: 'Permission / Symlink',
    task: 'Set permission 775 untuk storage dan bootstrap/cache',
    command_snippet: 'chmod -R 775 storage bootstrap/cache && chown -R www-data:www-data storage bootstrap/cache',
    type: 'standard',
    order: 1,
  },
  {
    id: 15,
    subcategory_id: 2,
    parent_id: 13,
    trigger_condition: 'Permission / Symlink',
    task: 'Buat ulang symlink public/storage ke storage/app/public',
    command_snippet: 'php artisan storage:link',
    type: 'standard',
    order: 2,
  },
  {
    id: 16,
    subcategory_id: 2,
    parent_id: 13,
    trigger_condition: 'Database / Migration',
    task: 'Verifikasi kredensial DB di file .env dan jalankan migrasi',
    command_snippet: 'php artisan migrate --force',
    type: 'standard',
    order: 1,
  },
  {
    id: 17,
    subcategory_id: 2,
    parent_id: 13,
    trigger_condition: 'App Key & Config Cache',
    task: 'Generate APP_KEY jika belum ada di file .env',
    command_snippet: 'php artisan key:generate',
    type: 'standard',
    order: 1,
  },
  {
    id: 18,
    subcategory_id: 2,
    parent_id: 13,
    trigger_condition: 'App Key & Config Cache',
    task: 'Clear dan optimize konfigurasi, routing, dan view',
    command_snippet: 'php artisan optimize:clear && php artisan config:cache',
    type: 'standard',
    order: 2,
  },

  // 3. Node.js (PM2 & Deployment)
  {
    id: 19,
    subcategory_id: 3,
    task: 'Periksa status proses aplikasi dan daemon supervisor',
    command_snippet: 'pm2 status && pm2 logs --lines 40 --err',
    hint: 'Cek apakah proses status errored / stopped atau ada port conflict.',
    type: 'choice',
    options: ['PM2 Crash Loop', 'Port Conflict / Nginx 502', 'Node Version Mismatch'],
    order: 1,
  },
  {
    id: 20,
    subcategory_id: 3,
    parent_id: 19,
    trigger_condition: 'PM2 Crash Loop',
    task: 'Re-install dependency dan jalankan build bundle',
    command_snippet: 'npm ci --omit=dev && npm run build',
    type: 'standard',
    order: 1,
  },
  {
    id: 21,
    subcategory_id: 3,
    parent_id: 19,
    trigger_condition: 'PM2 Crash Loop',
    task: 'Restart proses PM2 dan simpan state proses',
    command_snippet: 'pm2 restart all && pm2 save',
    type: 'standard',
    order: 2,
  },
  {
    id: 22,
    subcategory_id: 3,
    parent_id: 19,
    trigger_condition: 'Port Conflict / Nginx 502',
    task: 'Cek proses yang sedang memakai port aplikasi',
    command_snippet: 'netstat -tulnp | grep :3000',
    type: 'standard',
    order: 1,
  },
  {
    id: 23,
    subcategory_id: 3,
    parent_id: 19,
    trigger_condition: 'Port Conflict / Nginx 502',
    task: 'Uji konfigurasi proxy reverse Nginx dan reload service',
    command_snippet: 'nginx -t && systemctl reload nginx',
    type: 'standard',
    order: 2,
  },
  {
    id: 24,
    subcategory_id: 3,
    parent_id: 19,
    trigger_condition: 'Node Version Mismatch',
    task: 'Beralih ke versi Node.js LTS yang didukung menggunakan NVM',
    command_snippet: 'nvm use 20 || nvm install 20',
    type: 'standard',
    order: 1,
  },

  // 4. Email Service (Yahoo Bounce & SPF/DKIM)
  {
    id: 25,
    subcategory_id: 4,
    task: 'Analisa bounce code dari server mx.mail.yahoo.com',
    command_snippet: 'grep -i "yahoo" /var/log/maillog | tail -n 40',
    hint: 'Periksa apakah kode penolakan adalah 554 (DMARC fail), 421 (Rate limit), atau TLS error.',
    type: 'choice',
    options: ['DMARC / SPF Authentication Fail', 'IP Rate Limit / Blacklist (421)', 'Port & SSL Handshake'],
    order: 1,
  },
  {
    id: 26,
    subcategory_id: 4,
    parent_id: 25,
    trigger_condition: 'DMARC / SPF Authentication Fail',
    task: 'Validasi record SPF (v=spf1) dan pastikan IP server masuk dalam whitelist',
    command_snippet: 'dig TXT domain-pelanggan.com +short',
    type: 'standard',
    order: 1,
  },
  {
    id: 27,
    subcategory_id: 4,
    parent_id: 25,
    trigger_condition: 'DMARC / SPF Authentication Fail',
    task: 'Konfigurasi record DMARC dan DKIM 2048-bit sesuai panduan Yahoo Bulk Sender 2024',
    command_snippet: 'dig TXT default._domainkey.domain-pelanggan.com +short',
    type: 'standard',
    order: 2,
  },
  {
    id: 28,
    subcategory_id: 4,
    parent_id: 25,
    trigger_condition: 'IP Rate Limit / Blacklist (421)',
    task: 'Cek Reverse DNS (PTR Record) IP mail server',
    command_snippet: 'dig -x [IP-SERVER] +short',
    type: 'standard',
    order: 1,
  },
  {
    id: 29,
    subcategory_id: 4,
    parent_id: 25,
    trigger_condition: 'IP Rate Limit / Blacklist (421)',
    task: 'Flush antrean email spam dan atur rate limit throttling Postfix',
    command_snippet: 'postqueue -f && postsuper -d ALL deferred',
    type: 'standard',
    order: 2,
  },
  {
    id: 30,
    subcategory_id: 4,
    parent_id: 25,
    trigger_condition: 'Port & SSL Handshake',
    task: 'Uji konektivitas STARTTLS port 587 atau port 465 SSL ke Yahoo MX',
    command_snippet: 'openssl s_client -connect mx.mail.yahoo.com:25 -starttls smtp',
    type: 'standard',
    order: 1,
  },
];

export const INITIAL_CASE_REPORTS: CaseReport[] = [
  {
    id: 8812,
    user_id: 2,
    subcategory_id: 1,
    customer_name: 'PT Surya Digital (Bpk. Bambang)',
    agent_name: 'Fajar CS',
    ticket_id: '#TKT-8812',
    status: 'resolved',
    started_at: new Date(Date.now() - 1 * 86400000 - 780000).toISOString(),
    resolved_at: new Date(Date.now() - 1 * 86400000).toISOString(),
    duration_seconds: 780, // 13 menit
    csat_score: 5,
    csat_comment: 'Pelayanan sangat cepat dan solutif! Website pulih dalam sekejap.',
    solution_summary: 'Tema Crash teridentifikasi; switch sementara ke Twenty Twenty-Four dan amankan folder tema lama.',
    created_at: '1 hari yang lalu',
    subcategory_title: 'Critical Error (WSOD / Fatal Error)',
    items: [
      { task_name: 'Tahap 1: Uji coba dengan tema default WordPress', is_checked: true, selected_choice: 'Normal (Tema Crash)' },
      { task_name: 'Akses wp-content/themes/ lalu rename folder tema aktif sebagai backup', is_checked: true },
      { task_name: 'Catat error pada file functions.php / template tema dan konfirmasi ke pelanggan', is_checked: true },
    ],
  },
  {
    id: 8850,
    user_id: 3,
    subcategory_id: 2,
    customer_name: 'CV Makmur Sejahtera (Bpk. Rahmat)',
    agent_name: 'Sarah CS',
    ticket_id: '#TKT-8850',
    status: 'resolved',
    started_at: new Date(Date.now() - 2 * 86400000 - 840000).toISOString(),
    resolved_at: new Date(Date.now() - 2 * 86400000).toISOString(),
    duration_seconds: 840, // 14 menit
    csat_score: 5,
    csat_comment: 'Error 500 langsung beres setelah dicek permission log-nya. Mantap!',
    solution_summary: 'Perbaikan permission storage & bootstrap/cache 775 serta generate symlink public storage.',
    created_at: '2 hari yang lalu',
    subcategory_title: 'Deployment & HTTP 500 Server Error',
    items: [
      { task_name: 'Cek storage/logs/laravel.log dan jenis error 500', is_checked: true, selected_choice: 'Permission / Symlink' },
      { task_name: 'Set permission 775 untuk storage dan bootstrap/cache', is_checked: true },
      { task_name: 'Buat ulang symlink public/storage ke storage/app/public', is_checked: true },
    ],
  },
  {
    id: 8891,
    user_id: 4,
    subcategory_id: 1,
    customer_name: 'Toko Busana Cantika (Ibu Lina)',
    agent_name: 'Dimas CS',
    ticket_id: '#TKT-8891',
    status: 'resolved',
    started_at: new Date(Date.now() - 2 * 86400000 - 960000).toISOString(),
    resolved_at: new Date(Date.now() - 2 * 86400000).toISOString(),
    duration_seconds: 960, // 16 menit
    csat_score: 5,
    csat_comment: 'Sangat responsif, toko online saya bisa dipakai jualan lagi.',
    solution_summary: 'Isolasi plugin WooCommerce addon yang crash via debug.log dan rename folder plugin bermasalah.',
    created_at: '2 hari yang lalu',
    subcategory_title: 'Critical Error (WSOD / Fatal Error)',
    items: [
      { task_name: 'Tahap 1: Uji coba dengan tema default WordPress', is_checked: true, selected_choice: 'Masih Error' },
      { task_name: 'Tahap 2: Pengecekan Plugin (Cek debug.log & isolasi plugin)', is_checked: true, selected_choice: 'Plugin Crash Teridentifikasi' },
      { task_name: 'Nonaktifkan plugin bermasalah via WP-CLI atau rename foldernya di wp-content/plugins/', is_checked: true },
      { task_name: 'Buka kembali WP-Admin dan pastikan dashboard serta frontend normal kembali', is_checked: true },
    ],
  },
  {
    id: 8910,
    user_id: 5,
    subcategory_id: 4,
    customer_name: 'Nusantara Logistics (Bpk. Denny)',
    agent_name: 'Rian CS',
    ticket_id: '#TKT-8910',
    status: 'resolved',
    started_at: new Date(Date.now() - 3 * 86400000 - 720000).toISOString(),
    resolved_at: new Date(Date.now() - 3 * 86400000).toISOString(),
    duration_seconds: 720, // 12 menit
    csat_score: 5,
    csat_comment: 'Email penawaran ke Yahoo akhirnya tembus inbox tanpa bounce lagi.',
    solution_summary: 'Pemeriksaan SPF IP server dan set DMARC policy p=none sesuai aturan Yahoo Bulk Sender.',
    created_at: '3 hari yang lalu',
    subcategory_title: 'Yahoo Mail Bounce & Sender Authentication (SPF/DKIM)',
    items: [
      { task_name: 'Analisa bounce code dari server mx.mail.yahoo.com', is_checked: true, selected_choice: 'DMARC / SPF Authentication Fail' },
      { task_name: 'Validasi record SPF (v=spf1) dan pastikan IP server masuk dalam whitelist', is_checked: true },
      { task_name: 'Konfigurasi record DMARC dan DKIM 2048-bit sesuai panduan Yahoo Bulk Sender 2024', is_checked: true },
    ],
  },
  {
    id: 8945,
    user_id: 2,
    subcategory_id: 1,
    customer_name: 'Portal Berita Terkini (Mas Dimas)',
    agent_name: 'Fajar CS',
    ticket_id: '#TKT-8945',
    status: 'resolved',
    started_at: new Date(Date.now() - 4 * 86400000 - 660000).toISOString(),
    resolved_at: new Date(Date.now() - 4 * 86400000).toISOString(),
    duration_seconds: 660, // 11 menit
    csat_score: 5,
    csat_comment: 'Top markotop! Penanganan super kilat di jam malam.',
    solution_summary: 'WordPress core reinstalled via WP-CLI download force karena file wp-includes ada yang korup.',
    created_at: '4 hari yang lalu',
    subcategory_title: 'Critical Error (WSOD / Fatal Error)',
    items: [
      { task_name: 'Tahap 1: Uji coba dengan tema default WordPress', is_checked: true, selected_choice: 'Masih Error' },
      { task_name: 'Tahap 2: Pengecekan Plugin', is_checked: true, selected_choice: 'Bukan Masalah Plugin' },
      { task_name: 'Tahap 3: Pemeriksaan WordPress Core', is_checked: true, selected_choice: 'Core Reinstalled (Normal)' },
      { task_name: 'Download ulang core files yang hilang/korup tanpa menyentuh wp-content', is_checked: true },
      { task_name: 'Sesuaikan versi PHP di cPanel / Server ke PHP 8.1 atau 8.2 yang stabil', is_checked: true },
    ],
  },
  {
    id: 8980,
    user_id: 3,
    subcategory_id: 3,
    customer_name: 'Agensi Kreatif Sinar (Mba Dina)',
    agent_name: 'Sarah CS',
    ticket_id: '#TKT-8980',
    status: 'resolved',
    started_at: new Date(Date.now() - 5 * 86400000 - 900000).toISOString(),
    resolved_at: new Date(Date.now() - 5 * 86400000).toISOString(),
    duration_seconds: 900, // 15 menit
    csat_score: 5,
    csat_comment: 'Aplikasi Express API langsung online kembali di PM2.',
    solution_summary: 'Pemeriksaan port conflict port 3000, kill zombie process, dan PM2 restart all.',
    created_at: '5 hari yang lalu',
    subcategory_title: 'Deployment, Build & PM2 Service Down',
    items: [
      { task_name: 'Periksa status proses aplikasi dan daemon supervisor', is_checked: true, selected_choice: 'Port Conflict / Nginx 502' },
      { task_name: 'Cek proses yang sedang memakai port aplikasi', is_checked: true },
      { task_name: 'Uji konfigurasi proxy reverse Nginx dan reload service', is_checked: true },
    ],
  },
  {
    id: 9015,
    user_id: 4,
    subcategory_id: 4,
    customer_name: 'Klinik Sehat Utama (dr. Farida)',
    agent_name: 'Dimas CS',
    ticket_id: '#TKT-9015',
    status: 'resolved',
    started_at: new Date(Date.now() - 6 * 86400000 - 840000).toISOString(),
    resolved_at: new Date(Date.now() - 6 * 86400000).toISOString(),
    duration_seconds: 840, // 14 menit
    csat_score: 5,
    csat_comment: 'Penjelasan CS ramah dan solusinya langsung bekerja.',
    solution_summary: 'Validasi PTR reverse DNS dan penyesuaian throttling rate limit Postfix mail server.',
    created_at: '6 hari yang lalu',
    subcategory_title: 'Yahoo Mail Bounce & Sender Authentication (SPF/DKIM)',
    items: [
      { task_name: 'Analisa bounce code dari server mx.mail.yahoo.com', is_checked: true, selected_choice: 'IP Rate Limit / Blacklist (421)' },
      { task_name: 'Cek Reverse DNS (PTR Record) IP mail server', is_checked: true },
      { task_name: 'Flush antrean email spam dan atur rate limit throttling Postfix', is_checked: true },
    ],
  },
  {
    id: 9060,
    user_id: 5,
    subcategory_id: 2,
    customer_name: 'Startup Finova (Mas Kevin)',
    agent_name: 'Rian CS',
    ticket_id: '#TKT-9060',
    status: 'resolved',
    started_at: new Date(Date.now() - 7 * 86400000 - 780000).toISOString(),
    resolved_at: new Date(Date.now() - 7 * 86400000).toISOString(),
    duration_seconds: 780, // 13 menit
    csat_score: 5,
    csat_comment: 'Keren! Problem database migration di production langsung dibantu tuntas.',
    solution_summary: 'Pemeriksaan kredensial DB di file .env dan eksekusi php artisan migrate --force.',
    created_at: '7 hari yang lalu',
    subcategory_title: 'Deployment & HTTP 500 Server Error',
    items: [
      { task_name: 'Cek storage/logs/laravel.log dan jenis error 500', is_checked: true, selected_choice: 'Database / Migration' },
      { task_name: 'Verifikasi kredensial DB di file .env dan jalankan migrasi', is_checked: true },
    ],
  },
];

export const INITIAL_CS_REPORTS: CsReport[] = [
  {
    id: 101,
    user_id: 2,
    reporter_name: 'Fajar CS',
    platform: 'WordPress',
    issue_title: 'Fatal Error: Allowed memory size exhausted saat edit Elementor',
    error_log: 'Fatal error: Allowed memory size of 134217728 bytes exhausted (tried to allocate 20480 bytes) in /wp-includes/class-wp-hook.php on line 324',
    generated_prompt: 'Diagnosa masalah memory exhausted pada WordPress Elementor dan berikan langkah penyesuaian memory_limit.',
    gemini_solution: `🔍 AKAR MASALAH\nBatas alokasi memori PHP (memory_limit) server saat ini dibatasi pada 128M dan habis saat rendering modul Elementor.\n\n🛠️ LANGKAH PERBAIKAN\n1. Tambahkan baris ini di wp-config.php:\n   define('WP_MEMORY_LIMIT', '256M');\n   define('WP_MAX_MEMORY_LIMIT', '512M');\n2. Di cPanel MultiPHP INI Editor, ubah memory_limit menjadi 256M.\n3. Simpan dan reload dashboard WordPress pelanggan.`,
    status: 'solved',
    created_at: '3 jam yang lalu',
  },
  {
    id: 102,
    user_id: 3,
    reporter_name: 'Sarah CS',
    platform: 'Laravel',
    issue_title: 'Error 500: Vite manifest not found at build/manifest.json',
    error_log: 'Vite manifest not found at: /home/user/public_html/public/build/manifest.json in /vendor/laravel/framework/src/Illuminate/Foundation/Vite.php',
    generated_prompt: 'Analisis kendala Vite manifest not found di server produksi Laravel 11.',
    gemini_solution: `🔍 AKAR MASALAH\nAset frontend Vue/Tailwind belum di-compile ke folder public/build sebelum rilis deploy ke server.\n\n🛠️ LANGKAH PERBAIKAN\n1. Jalankan perintah di root project:\n   npm install && npm run build\n2. Jalankan clear cache:\n   php artisan optimize:clear\n3. Pastikan folder public/build memiliki izin baca (permission 755).`,
    status: 'solved',
    created_at: '6 jam yang lalu',
  },
  {
    id: 103,
    user_id: 4,
    reporter_name: 'Dimas CS',
    platform: 'Node.js',
    issue_title: 'PM2 Crash Loop: Error listen EADDRINUSE :::3000',
    error_log: 'Error: listen EADDRINUSE: address already in use :::3000 at Server.setupListenHandle [as _listen2]',
    generated_prompt: 'Investigasi PM2 crash loop akibat port 3000 sedang digunakan proses lain.',
    gemini_solution: `🔍 AKAR MASALAH\nPort 3000 masih dikunci oleh instance Node.js sebelumnya yang hang atau zombie process.\n\n🛠️ LANGKAH PERBAIKAN\n1. Identifikasi proses yang memegang port:\n   fuser 3000/tcp atau netstat -tulnp | grep :3000\n2. Hentikan proses tersebut:\n   fuser -k 3000/tcp\n3. Restart daemon PM2:\n   pm2 restart all && pm2 save`,
    status: 'solved',
    created_at: '12 jam yang lalu',
  },
  {
    id: 104,
    user_id: 5,
    reporter_name: 'Rian CS',
    platform: 'Email Service',
    issue_title: 'Yahoo Mail Bounce 554 5.7.9 Message not accepted due to DMARC policy',
    error_log: '554 5.7.9 Message not accepted for policy reasons. See https://senders.yahooinc.com/smtp-error-codes#579',
    generated_prompt: 'Konfigurasi DNS record DMARC dan SPF untuk mematuhi kebijakan Yahoo Mail 2024.',
    gemini_solution: `🔍 AKAR MASALAH\nYahoo mewajibkan autentikasi SPF dan DMARC valid untuk mencegah spam spoofing domain.\n\n🛠️ LANGKAH PERBAIKAN\n1. Tambahkan TXT Record SPF:\n   v=spf1 +a +mx +ip4:IP_SERVER ~all\n2. Tambahkan TXT Record DMARC:\n   Name: _dmarc.domainpelanggan.com\n   Value: v=DMARC1; p=none; sp=none; rua=mailto:admin@domainpelanggan.com\n3. Tunggu propagasi 10 menit lalu uji kirim ulang email.`,
    status: 'solved',
    created_at: '1 hari yang lalu',
  },
  {
    id: 105,
    user_id: 1,
    reporter_name: 'Super Admin',
    platform: 'Imunify360 & Teleport',
    issue_title: 'IP Terblokir pada Imunify360',
    error_log: 'IP jaringan user terblokir pada firewall server Imunify360 (Status/Purpose: drop)',
    generated_prompt: 'Panduan pengecekan dan unblock IP pelanggan yang terblokir Imunify360 via Teleport.',
    gemini_solution: `Apabila ada kendala IP jaringan user terblokir pada server, silakan jalankan langkah-langkah berikut di teleport:\n\n1. Cek Status Blokir IP\nLakukan pengecekan apakah IP terblokir atau tidak dengan menjalankan command berikut:\nimunify360-agent ip-list local list --by-ip [ip-pelanggan]\n(Contoh: imunify360-agent ip-list local list --by-ip 182.9.98.2)\n\n2. Hapus Blokir (Unblock) IP\nJika hasil pengecekan menunjukkan IP terblokir dan pada keterangan purpose terdapat status "drop", gunakan command ini untuk menghapusnya:\nimunify360-agent ip-list local delete --purpose drop [ip-pelanggan]\n\n3. Verifikasi Ulang\nSetelah eksekusi penghapusan, cek kembali menggunakan command pada langkah pertama untuk memastikan IP benar-benar sudah terhapus dari daftar blokir.`,
    status: 'solved',
    created_at: 'Baru saja',
  },
];

export interface CsExternalLink {
  id: number;
  title: string;
  url: string;
  category?: string;
  description?: string;
  created_by_username: string;
  created_by_name: string;
  views_count?: number;
  created_at?: string;
}

export const INITIAL_CS_EXTERNAL_LINKS: CsExternalLink[] = [
  {
    id: 1,
    title: 'Cara Deploy React JS di Hosting cPanel',
    url: 'https://www.jagoanhosting.com/tutorial/hosting/cara-deploy-react-js-di-cpanel',
    category: 'Apps & Framework',
    description: 'Panduan build React (npm run build), upload dist/build ke public_html cPanel, dan konfigurasi .htaccess fallback routing.',
    created_by_username: 'farras',
    created_by_name: 'Farras',
    created_at: '1 hari yang lalu',
  },
];

