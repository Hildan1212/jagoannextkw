import mysql from 'mysql2/promise';
import fallbackTutorials from './tutorials_data.json';
import {
  Category,
  Subcategory,
  ChecklistTemplate,
  CaseReport,
  CsReport,
  StaffUser,
  CsExternalLink,
  INITIAL_STAFF_USERS,
  INITIAL_CATEGORIES,
  INITIAL_SUBCATEGORIES,
  INITIAL_CHECKLIST_TEMPLATES,
  INITIAL_CASE_REPORTS,
  INITIAL_CS_REPORTS,
  INITIAL_CS_EXTERNAL_LINKS,
} from './board-data';
import { defaultAiCases } from './constants';

export { defaultAiCases };

let pool: mysql.Pool | null = null;
let schemaInitialized = false;

// In-Memory state for instant sub-millisecond responses and reliable fallback
let inMemoryCategories: Category[] = [...INITIAL_CATEGORIES];
let inMemorySubcategories: Subcategory[] = [...INITIAL_SUBCATEGORIES];
let inMemoryChecklists: ChecklistTemplate[] = [...INITIAL_CHECKLIST_TEMPLATES];
let inMemoryCaseReports: CaseReport[] = [...INITIAL_CASE_REPORTS];
let inMemoryCsReports: CsReport[] = [...INITIAL_CS_REPORTS];
let inMemoryStaffUsers: StaffUser[] = [...INITIAL_STAFF_USERS];
let inMemoryCsExternalLinks: CsExternalLink[] = [...INITIAL_CS_EXTERNAL_LINKS];

export function getTiDbPool(): mysql.Pool | null {
  if (pool) return pool;

  const dbUrl = process.env.DATABASE_URL;
  const password = process.env.TIDB_PASSWORD;

  if (!password && !dbUrl) {
    return null; // Local in-memory mode
  }

  try {
    if (password && password.trim() !== '') {
      pool = mysql.createPool({
        host: process.env.TIDB_HOST || 'gateway01.ap-southeast-1.prod.aws.tidbcloud.com',
        port: parseInt(process.env.TIDB_PORT || '4000', 10),
        user: process.env.TIDB_USER || '473gWetUXSjEahq.root',
        password: password,
        database: process.env.TIDB_DATABASE || 'test',
        ssl: {
          minVersion: 'TLSv1.2',
          rejectUnauthorized: true,
        },
        waitForConnections: true,
        connectionLimit: 5,
        queueLimit: 0,
        connectTimeout: 5000,
      });
    } else if (dbUrl) {
      pool = mysql.createPool(dbUrl);
    }
    return pool;
  } catch (err) {
    console.warn('Gagal menginisialisasi TiDB pool, beralih ke fallback:', err);
    return null;
  }
}

/**
 * Inisialisasi skema tabel otomatis di TiDB jika belum ada
 */
export async function initTiDbSchema(): Promise<boolean> {
  const p = getTiDbPool();
  if (!p || schemaInitialized) return schemaInitialized;

  try {
    const conn = await p.getConnection();
    try {
      // 1. Tabel Tutorials
      await conn.query(`
        CREATE TABLE IF NOT EXISTS tutorials (
          id INT AUTO_INCREMENT PRIMARY KEY,
          title VARCHAR(255) NOT NULL,
          slug VARCHAR(255) UNIQUE NOT NULL,
          category VARCHAR(100) NOT NULL,
          url VARCHAR(500) NOT NULL,
          excerpt TEXT NOT NULL,
          content LONGTEXT,
          tags JSON,
          reading_time INT DEFAULT 3,
          is_popular BOOLEAN DEFAULT FALSE,
          views_count INT DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_category (category),
          INDEX idx_popular (is_popular)
        );
      `);

      // 2. Tabel Categories
      await conn.query(`
        CREATE TABLE IF NOT EXISTS categories (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(100) UNIQUE NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `);

      // 3. Tabel Subcategories
      await conn.query(`
        CREATE TABLE IF NOT EXISTS subcategories (
          id INT AUTO_INCREMENT PRIMARY KEY,
          category_id INT NOT NULL,
          title VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `);

      // 4. Tabel Checklist Templates
      await conn.query(`
        CREATE TABLE IF NOT EXISTS checklist_templates (
          id INT AUTO_INCREMENT PRIMARY KEY,
          subcategory_id INT NOT NULL,
          parent_id INT DEFAULT NULL,
          trigger_condition VARCHAR(255) DEFAULT NULL,
          task TEXT NOT NULL,
          command_snippet TEXT DEFAULT NULL,
          hint TEXT DEFAULT NULL,
          type VARCHAR(50) DEFAULT 'standard',
          options JSON DEFAULT NULL,
          \`order\` INT DEFAULT 1,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `);

      // 5. Tabel Case Reports
      await conn.query(`
        CREATE TABLE IF NOT EXISTS case_reports (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT DEFAULT NULL,
          subcategory_id INT NOT NULL,
          customer_name VARCHAR(150) NOT NULL,
          agent_name VARCHAR(150) NOT NULL,
          ticket_id VARCHAR(50) NOT NULL,
          status VARCHAR(50) DEFAULT 'resolved',
          started_at TIMESTAMP NULL,
          resolved_at TIMESTAMP NULL,
          duration_seconds INT DEFAULT 0,
          csat_score INT DEFAULT 5,
          csat_comment TEXT,
          solution_summary TEXT,
          redundant_checks_count INT DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_subcategory (subcategory_id),
          INDEX idx_agent (agent_name)
        );
      `);

      // 6. Tabel Case Report Items
      await conn.query(`
        CREATE TABLE IF NOT EXISTS case_report_items (
          id INT AUTO_INCREMENT PRIMARY KEY,
          case_report_id INT NOT NULL,
          task_name TEXT NOT NULL,
          is_checked BOOLEAN DEFAULT TRUE,
          selected_choice VARCHAR(255) DEFAULT NULL,
          note TEXT DEFAULT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `);

      // 7. Tabel CS Reports (Kasus Solved by AI)
      await conn.query(`
        CREATE TABLE IF NOT EXISTS cs_reports (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT DEFAULT NULL,
          reporter_name VARCHAR(100) DEFAULT 'Rekan CS',
          platform VARCHAR(100) NOT NULL,
          issue_title VARCHAR(255) NOT NULL,
          error_log TEXT,
          generated_prompt TEXT,
          gemini_solution TEXT,
          status VARCHAR(50) DEFAULT 'open',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_status (status),
          INDEX idx_platform (platform)
        );
      `);

      // 8. Tabel Users (Staff & Admin)
      await conn.query(`
        CREATE TABLE IF NOT EXISTS users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          username VARCHAR(100) UNIQUE NOT NULL,
          name VARCHAR(100) NOT NULL,
          email VARCHAR(150) NULL,
          password VARCHAR(255) NOT NULL,
          role VARCHAR(50) DEFAULT 'agent',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
      `);

      // 9. Tabel Tutorial Views (Audit Log)
      await conn.query(`
        CREATE TABLE IF NOT EXISTS tutorial_views (
          id INT AUTO_INCREMENT PRIMARY KEY,
          tutorial_id INT NULL,
          tutorial_title VARCHAR(255) NOT NULL,
          tutorial_url VARCHAR(500) NOT NULL,
          username VARCHAR(100) NOT NULL,
          user_role VARCHAR(50) DEFAULT 'agent',
          source VARCHAR(50) DEFAULT 'web',
          viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_username (username),
          INDEX idx_viewed_at (viewed_at),
          INDEX idx_tutorial_id (tutorial_id)
        );
      `);

      // 10. Tabel CS External Links (Solusi / How-To by CS)
      await conn.query(`
        CREATE TABLE IF NOT EXISTS cs_external_links (
          id INT AUTO_INCREMENT PRIMARY KEY,
          title VARCHAR(255) NOT NULL,
          url VARCHAR(500) NOT NULL,
          category VARCHAR(100) DEFAULT 'Rekomendasi CS',
          description TEXT,
          created_by_username VARCHAR(100) NOT NULL,
          created_by_name VARCHAR(100) NOT NULL,
          views_count INT DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_title (title)
        );
      `);

      // Cek apakah tabel tutorials masih kosong, jika kosong isi data
      const [rows] = await conn.query('SELECT count(*) as count FROM tutorials');
      const count = (rows as any)[0]?.count || 0;

      if (count === 0 && Array.isArray(fallbackTutorials)) {
        for (const item of fallbackTutorials.slice(0, 100)) {
          const title = item.title || '';
          const url = item.url || '';
          const kw = item.kw || '';
          const slug = url.split('/').filter(Boolean).pop() || title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
          let category = 'Hosting & cPanel';
          const tLower = title.toLowerCase();

          if (tLower.includes('vps') || tLower.includes('aapanel') || tLower.includes('cyberpanel')) category = 'VPS & Cloud Server';
          else if (tLower.includes('wordpress') || tLower.includes('cms')) category = 'WordPress & CMS';
          else if (tLower.includes('email') || tLower.includes('dmarc') || tLower.includes('outlook')) category = 'Email Bisnis';
          else if (tLower.includes('domain') || tLower.includes('dns')) category = 'Domain & DNS';
          else if (tLower.includes('ssl')) category = 'SSL & Keamanan';

          await conn.query(`
            INSERT IGNORE INTO tutorials (title, slug, category, url, excerpt, tags, is_popular, views_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            title,
            slug,
            category,
            url,
            `Panduan resmi Knowledge Base Jagoan Hosting: ${title}. Pelajari alur konfigurasi & instruksi teknis.`,
            JSON.stringify([kw]),
            tLower.includes('cara') && Math.random() > 0.6,
            Math.floor(Math.random() * 3500) + 500
          ]);
        }
      }

      schemaInitialized = true;
      return true;
    } finally {
      conn.release();
    }
  } catch (err) {
    console.warn('Gagal koneksi TiDB Cloud, menggunakan fallback lokal:', err);
    return false;
  }
}

/**
 * Data Retrieval & Management Helpers (With TiDB and in-memory fallback)
 */
export async function getCategories(): Promise<Category[]> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [rows] = await p.query('SELECT id, name FROM categories ORDER BY id ASC');
      if (Array.isArray(rows) && rows.length > 0) {
        return rows as Category[];
      }
    } catch (e) {
      // fallback
    }
  }
  return inMemoryCategories;
}

export async function addCategory(name: string): Promise<Category> {
  const p = getTiDbPool();
  const trimmed = name.trim();
  if (p) {
    try {
      await initTiDbSchema();
      const [res]: any = await p.query('INSERT INTO categories (name) VALUES (?)', [trimmed]);
      const newCat = { id: res.insertId, name: trimmed };
      inMemoryCategories.push(newCat);
      return newCat;
    } catch (e) {
      // fallback
    }
  }
  const newCat: Category = { id: Date.now(), name: trimmed };
  inMemoryCategories.push(newCat);
  return newCat;
}

export async function getSubcategories(categoryId?: number): Promise<Subcategory[]> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      let query = 'SELECT id, category_id, title FROM subcategories';
      const params: any[] = [];
      if (categoryId) {
        query += ' WHERE category_id = ?';
        params.push(categoryId);
      }
      query += ' ORDER BY id ASC';
      const [rows] = await p.query(query, params);
      if (Array.isArray(rows) && rows.length > 0) {
        return rows as Subcategory[];
      }
    } catch (e) {
      // fallback
    }
  }
  if (categoryId) {
    return inMemorySubcategories.filter((s) => s.category_id === categoryId);
  }
  return inMemorySubcategories;
}

export async function addSubcategory(categoryId: number, title: string): Promise<Subcategory> {
  const p = getTiDbPool();
  const trimmed = title.trim();
  if (p) {
    try {
      await initTiDbSchema();
      const [res]: any = await p.query('INSERT INTO subcategories (category_id, title) VALUES (?, ?)', [categoryId, trimmed]);
      const newSub = { id: res.insertId, category_id: categoryId, title: trimmed };
      inMemorySubcategories.push(newSub);
      return newSub;
    } catch (e) {
      // fallback
    }
  }
  const newSub: Subcategory = { id: Date.now(), category_id: categoryId, title: trimmed };
  inMemorySubcategories.push(newSub);
  return newSub;
}

export async function getChecklists(subcategoryId: number): Promise<ChecklistTemplate[]> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [rows] = await p.query(
        'SELECT id, subcategory_id, parent_id, trigger_condition, task, command_snippet, hint, type, options, `order` FROM checklist_templates WHERE subcategory_id = ? ORDER BY `order` ASC',
        [subcategoryId]
      );
      if (Array.isArray(rows) && rows.length > 0) {
        return (rows as any[]).map((r) => ({
          ...r,
          options: typeof r.options === 'string' ? JSON.parse(r.options) : r.options,
        }));
      }
    } catch (e) {
      // fallback
    }
  }
  return inMemoryChecklists.filter((c) => c.subcategory_id === subcategoryId);
}

export async function addChecklistTemplate(item: Omit<ChecklistTemplate, 'id'>): Promise<ChecklistTemplate> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [res]: any = await p.query(
        'INSERT INTO checklist_templates (subcategory_id, parent_id, trigger_condition, task, command_snippet, hint, type, options, `order`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          item.subcategory_id,
          item.parent_id || null,
          item.trigger_condition || null,
          item.task,
          item.command_snippet || null,
          item.hint || null,
          item.type,
          item.options ? JSON.stringify(item.options) : null,
          item.order,
        ]
      );
      const created = { ...item, id: res.insertId };
      inMemoryChecklists.push(created);
      return created;
    } catch (e) {
      // fallback
    }
  }
  const created: ChecklistTemplate = { ...item, id: Date.now() };
  inMemoryChecklists.push(created);
  return created;
}

export async function deleteChecklistTemplate(id: number): Promise<boolean> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      await p.query('DELETE FROM checklist_templates WHERE id = ? OR parent_id = ?', [id, id]);
    } catch (e) {
      // fallback
    }
  }
  inMemoryChecklists = inMemoryChecklists.filter((c) => c.id !== id && c.parent_id !== id);
  return true;
}

export async function getCaseReports(): Promise<CaseReport[]> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [rows] = await p.query(`
        SELECT r.*, s.title as subcategory_title 
        FROM case_reports r
        LEFT JOIN subcategories s ON r.subcategory_id = s.id
        ORDER BY r.id DESC LIMIT 50
      `);
      if (Array.isArray(rows) && rows.length > 0) {
        return rows as CaseReport[];
      }
    } catch (e) {
      // fallback
    }
  }
  return inMemoryCaseReports;
}

export async function createCaseReport(report: Omit<CaseReport, 'id' | 'created_at'>): Promise<CaseReport> {
  const p = getTiDbPool();
  const newId = Math.floor(Math.random() * 8999) + 1000;
  const created: CaseReport = {
    ...report,
    id: newId,
    created_at: 'Baru saja',
  };

  if (p) {
    try {
      await initTiDbSchema();
      const [res]: any = await p.query(
        `INSERT INTO case_reports (user_id, subcategory_id, customer_name, agent_name, ticket_id, status, started_at, resolved_at, duration_seconds, csat_score, csat_comment, solution_summary)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          report.user_id || 1,
          report.subcategory_id,
          report.customer_name,
          report.agent_name,
          report.ticket_id,
          report.status,
          report.started_at,
          report.resolved_at,
          report.duration_seconds,
          report.csat_score,
          report.csat_comment || null,
          report.solution_summary || null,
        ]
      );
      created.id = res.insertId;

      if (report.items && report.items.length > 0) {
        for (const it of report.items) {
          await p.query(
            `INSERT INTO case_report_items (case_report_id, task_name, is_checked, selected_choice, note)
             VALUES (?, ?, ?, ?, ?)`,
            [created.id, it.task_name, it.is_checked, it.selected_choice || null, it.note || null]
          );
        }
      }
    } catch (e) {
      // fallback
    }
  }

  inMemoryCaseReports.unshift(created);
  return created;
}

export async function getCsReports(): Promise<CsReport[]> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [rows] = await p.query('SELECT * FROM cs_reports ORDER BY id DESC LIMIT 50');
      if (Array.isArray(rows) && rows.length > 0) {
        return rows as CsReport[];
      }
    } catch (e) {
      // fallback
    }
  }
  return inMemoryCsReports;
}

export async function createCsReport(report: Omit<CsReport, 'id' | 'created_at'>): Promise<CsReport> {
  const p = getTiDbPool();
  const newId = Date.now();
  const created: CsReport = {
    ...report,
    id: newId,
    created_at: 'Baru saja',
  };

  if (p) {
    try {
      await initTiDbSchema();
      const [res]: any = await p.query(
        `INSERT INTO cs_reports (user_id, reporter_name, platform, issue_title, error_log, generated_prompt, gemini_solution, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          report.user_id || 1,
          report.reporter_name,
          report.platform,
          report.issue_title,
          report.error_log || null,
          report.generated_prompt || null,
          report.gemini_solution || null,
          report.status,
        ]
      );
      created.id = res.insertId;
    } catch (e) {
      // fallback
    }
  }

  inMemoryCsReports.unshift(created);
  return created;
}

export async function updateCsReportSolution(id: number, solution: string): Promise<boolean> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      await p.query('UPDATE cs_reports SET gemini_solution = ?, status = ? WHERE id = ?', [solution, 'solved', id]);
    } catch (e) {
      // fallback
    }
  }
  const found = inMemoryCsReports.find((r) => r.id === id);
  if (found) {
    found.gemini_solution = solution;
    found.status = 'solved';
  }
  return true;
}

export function getStaffUsers(): StaffUser[] {
  return inMemoryStaffUsers;
}

export async function getAllStaffUsers(): Promise<StaffUser[]> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [rows] = await p.query('SELECT id, username, name, email, password, role, created_at FROM users ORDER BY id ASC');
      if (Array.isArray(rows) && rows.length > 0) {
        return rows as StaffUser[];
      }
    } catch (e) {
      console.warn('Error fetching users from TiDB, using fallback:', e);
    }
  }
  return inMemoryStaffUsers;
}

export async function createStaffUser(userData: {
  username: string;
  name: string;
  password?: string;
  role?: 'agent' | 'admin';
  email?: string;
}): Promise<{ success: boolean; user?: StaffUser; error?: string }> {
  const cleanUsername = userData.username.trim().toLowerCase().replace(/[^a-z0-9._-]/g, '');
  const cleanName = userData.name.trim();
  const cleanRole = userData.role === 'admin' ? 'admin' : 'agent';
  const cleanEmail = userData.email?.trim() || `${cleanUsername}@jagoanhosting.com`;

  if (!cleanUsername || cleanUsername.length < 3) {
    return { success: false, error: 'Username minimal 3 karakter (huruf/angka)' };
  }
  if (!cleanName || cleanName.length < 2) {
    return { success: false, error: 'Nama staf minimal 2 karakter' };
  }

  // Generate clean password if not provided
  const cleanPassword =
    userData.password?.trim() ||
    `Jg#${cleanUsername.slice(0, 4).charAt(0).toUpperCase() + cleanUsername.slice(1, 4)}${Math.floor(100 + Math.random() * 900)}`;

  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      // Check existing username
      const [existing]: any = await p.query('SELECT id FROM users WHERE LOWER(username) = ? LIMIT 1', [cleanUsername]);
      if (existing && existing.length > 0) {
        return { success: false, error: `Username "${cleanUsername}" sudah terdaftar.` };
      }

      const [res]: any = await p.query(
        'INSERT INTO users (username, name, email, password, role) VALUES (?, ?, ?, ?, ?)',
        [cleanUsername, cleanName, cleanEmail, cleanPassword, cleanRole]
      );

      const newUser: StaffUser = {
        id: res.insertId,
        username: cleanUsername,
        name: cleanName,
        email: cleanEmail,
        password: cleanPassword,
        role: cleanRole,
      };

      inMemoryStaffUsers.push(newUser);
      return { success: true, user: newUser };
    } catch (err: any) {
      console.error('TiDB create user error:', err);
      return { success: false, error: err.message || 'Gagal menyimpan akun ke database' };
    }
  }

  // Memory fallback
  const exists = inMemoryStaffUsers.some((u) => u.username.toLowerCase() === cleanUsername);
  if (exists) {
    return { success: false, error: `Username "${cleanUsername}" sudah terdaftar.` };
  }

  const newUser: StaffUser = {
    id: Date.now(),
    username: cleanUsername,
    name: cleanName,
    email: cleanEmail,
    password: cleanPassword,
    role: cleanRole,
  };
  inMemoryStaffUsers.push(newUser);
  return { success: true, user: newUser };
}

export async function deleteStaffUser(id: number): Promise<{ success: boolean; error?: string }> {
  if (id === 1) {
    return { success: false, error: 'Akun Super Admin utama (ID 1) tidak boleh dihapus demi keamanan sistem.' };
  }

  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      // Verify not admin
      const [check]: any = await p.query('SELECT id, username FROM users WHERE id = ?', [id]);
      if (!check || check.length === 0) {
        return { success: false, error: 'Akun tidak ditemukan di database.' };
      }
      if (check[0].username === 'admin') {
        return { success: false, error: 'Akun "admin" tidak dapat dihapus.' };
      }

      await p.query('DELETE FROM users WHERE id = ?', [id]);
    } catch (err: any) {
      console.error('TiDB delete user error:', err);
      return { success: false, error: err.message || 'Gagal menghapus user dari database.' };
    }
  }

  inMemoryStaffUsers = inMemoryStaffUsers.filter((u) => u.id !== id);
  return { success: true };
}

export async function updateStaffUserPassword(id: number, newPassword: string): Promise<{ success: boolean; error?: string }> {
  if (!newPassword || newPassword.trim().length < 4) {
    return { success: false, error: 'Password baru minimal 4 karakter.' };
  }

  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      await p.query('UPDATE users SET password = ? WHERE id = ?', [newPassword.trim(), id]);
    } catch (err: any) {
      return { success: false, error: err.message || 'Gagal memperbarui password di database.' };
    }
  }

  const found = inMemoryStaffUsers.find((u) => u.id === id);
  if (found) {
    found.password = newPassword.trim();
  }
  return { success: true };
}

export async function getAllCsExternalLinks(): Promise<CsExternalLink[]> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [rows] = await p.query(
        'SELECT id, title, url, category, description, created_by_username, created_by_name, views_count, created_at FROM cs_external_links ORDER BY id DESC'
      );
      if (Array.isArray(rows) && rows.length > 0) {
        return rows as CsExternalLink[];
      }
    } catch (e) {
      console.warn('Error fetching cs_external_links from TiDB:', e);
    }
  }
  return inMemoryCsExternalLinks;
}

export async function createCsExternalLink(data: {
  title: string;
  url: string;
  category?: string;
  description?: string;
  username: string;
  name: string;
}): Promise<CsExternalLink> {
  const newLink: CsExternalLink = {
    id: Date.now(),
    title: data.title.trim(),
    url: data.url.trim(),
    category: data.category?.trim() || 'Rekomendasi CS',
    description: data.description?.trim() || '',
    created_by_username: data.username || 'agent',
    created_by_name: data.name || 'Rekan CS',
    views_count: 0,
    created_at: new Date().toISOString(),
  };

  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      const [res]: any = await p.query(
        `INSERT INTO cs_external_links (title, url, category, description, created_by_username, created_by_name)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [newLink.title, newLink.url, newLink.category, newLink.description, newLink.created_by_username, newLink.created_by_name]
      );
      newLink.id = res.insertId;
    } catch (e) {
      console.warn('Error creating cs_external_link in TiDB:', e);
    }
  }

  inMemoryCsExternalLinks.unshift(newLink);
  return newLink;
}

export async function deleteCsExternalLink(id: number): Promise<{ success: boolean; error?: string }> {
  const p = getTiDbPool();
  if (p) {
    try {
      await initTiDbSchema();
      await p.query('DELETE FROM cs_external_links WHERE id = ?', [id]);
    } catch (err: any) {
      console.error('TiDB delete cs_external_link error:', err);
      return { success: false, error: err.message || 'Gagal menghapus link dari database.' };
    }
  }

  inMemoryCsExternalLinks = inMemoryCsExternalLinks.filter((l) => l.id !== id);
  return { success: true };
}
