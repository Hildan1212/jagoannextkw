// Default Solved AI cases snapshot (Client-safe constant)
export const defaultAiCases = [
  {
    id: 51,
    title: 'Error 500 Internal Server Error di WordPress aaPanel setelah update PHP',
    platform: 'WordPress & aaPanel',
    category: 'WordPress & CMS',
    category_color: 'bg-blue-50 text-blue-800 border-blue-200',
    solution: `🔍 AKAR MASALAH:\nEkstensi mysqli atau pdo_mysql belum tercentang di versi PHP baru di aaPanel.\n\n🛠️ LANGKAH PERBAIKAN:\n1. Masuk ke aaPanel Dashboard > App Store.\n2. Buka setelan PHP (misal PHP 8.2) > Extensions.\n3. Centang modul 'mysqli', 'pdo_mysql', 'curl', 'mbstring', dan 'fileinfo'.\n4. Restart PHP service melalui Service Manager di aaPanel.`,
    error_log: 'Fatal error: Uncaught Error: Call to undefined function mysqli_connect()',
    created_at: '2 jam yang lalu',
  },
  {
    id: 52,
    title: 'Yahoo Mail Bounce 554 5.7.9 Message not accepted due to DMARC policy',
    platform: 'Email Service',
    category: 'Email Bisnis',
    category_color: 'bg-amber-50 text-amber-800 border-amber-200',
    solution: `🔍 AKAR MASALAH:\nYahoo & Google mewajibkan autentikasi SPF dan DMARC valid untuk mencegah spam spoofing domain.\n\n🛠️ LANGKAH PERBAIKAN:\n1. Tambahkan TXT record DMARC di cPanel / Zone Editor:\n   Name: _dmarc.namadomain.com\n   Type: TXT\n   Record: v=DMARC1; p=none; sp=none; rua=mailto:dmarc@namadomain.com\n2. Verifikasi SPF record menyertakan IP mailserver hosting:\n   v=spf1 +a +mx +ip4:IP_SERVER ~all\n3. Tunggu propagasi DNS 15-30 menit dan lakukan tes kirim ulang.`,
    error_log: '554 5.7.9 Message not accepted due to domain DMARC policy',
    created_at: '1 hari yang lalu',
  },
  {
    id: 53,
    title: 'CyberPanel LiteSpeed Web Server Gagal Start (Port 80/443 Conflict)',
    platform: 'VPS & CyberPanel',
    category: 'VPS & Cloud Server',
    category_color: 'bg-purple-50 text-purple-800 border-purple-200',
    solution: `🔍 AKAR MASALAH:\nProses Apache atau Nginx bawaan OS berjalan bersamaan dengan OpenLiteSpeed.\n\n🛠️ LANGKAH PERBAIKAN:\n1. Login via SSH VPS.\n2. Matikan service conflicting:\n   systemctl stop httpd apache2 nginx\n   systemctl disable httpd apache2 nginx\n3. Restart OpenLiteSpeed:\n   systemctl restart lsws\n4. Verifikasi status dengan 'systemctl status lsws'.`,
    error_log: 'bind() to 0.0.0.0:80 failed (98: Address already in use)',
    created_at: '3 hari yang lalu',
  },
  {
    id: 54,
    title: 'IP Terblokir pada Imunify360',
    platform: 'Imunify360 & Teleport',
    category: 'SSL & Keamanan',
    category_color: 'bg-rose-50 text-rose-800 border-rose-200',
    solution: `Apabila ada kendala IP jaringan user terblokir pada server, silakan jalankan langkah-langkah berikut di teleport:

1. Cek Status Blokir IP
Lakukan pengecekan apakah IP terblokir atau tidak dengan menjalankan command berikut:
imunify360-agent ip-list local list --by-ip [ip-pelanggan]
(Contoh: imunify360-agent ip-list local list --by-ip 182.9.98.2)

2. Hapus Blokir (Unblock) IP
Jika hasil pengecekan menunjukkan IP terblokir dan pada keterangan purpose terdapat status "drop", gunakan command ini untuk menghapusnya:
imunify360-agent ip-list local delete --purpose drop [ip-pelanggan]

3. Verifikasi Ulang
Setelah eksekusi penghapusan, cek kembali menggunakan command pada langkah pertama untuk memastikan IP benar-benar sudah terhapus dari daftar blokir.`,
    error_log: 'IP jaringan pelanggan terblokir di Imunify360 server (Purpose: drop)',
    created_at: 'Baru saja',
  },
];
