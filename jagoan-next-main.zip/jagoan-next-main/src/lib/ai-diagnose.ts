/**
 * AI Diagnostic Service for JagoanSearch CS Copilot
 * Multi-Key Load Balancing (Groq + Gemini) with Deep Contextual Knowledge Fallback
 */

export interface DiagnoseParams {
  platform: string;
  title: string;
  errorLog?: string | null;
  customApiKey?: string | null;
}

export async function runAiDiagnosis({
  platform,
  title,
  errorLog,
  customApiKey,
}: DiagnoseParams): Promise<string> {
  const keys = collectKeyPool(customApiKey);

  // 1. Try Groq API keys first (Ultra fast, 14,400 RPD)
  for (const groqKey of keys.groq) {
    try {
      const res = await callGroqApi(platform, title, errorLog, groqKey);
      if (res) return res;
    } catch (e) {
      console.warn('Groq key attempt failed, trying next...');
    }
  }

  // 2. Try Gemini API keys
  for (const geminiKey of keys.gemini) {
    try {
      const res = await callGeminiApi(platform, title, errorLog, geminiKey);
      if (res) return res;
    } catch (e) {
      console.warn('Gemini key attempt failed, trying next...');
    }
  }

  // 3. Fallback: Senior Cloud & Web Hosting Systems Engineer Contextual Engine
  return generateDeepContextualDiagnosis(platform, title, errorLog);
}

function collectKeyPool(customInput?: string | null): { groq: string[]; gemini: string[] } {
  const groq: string[] = [];
  const gemini: string[] = [];

  if (customInput) {
    const items = customInput.split(/[\r\n,]+/);
    for (const raw of items) {
      const k = raw.trim();
      if (!k) continue;
      if (k.startsWith('gsk_')) {
        groq.push(k);
      } else {
        gemini.push(k);
      }
    }
  }

  const envGroq = process.env.GROQ_API_KEY || process.env.GROQ_API_KEYS;
  if (envGroq) {
    for (const k of envGroq.split(/[\r\n,]+/)) {
      if (k.trim()) groq.push(k.trim());
    }
  }

  const envGemini = process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEYS;
  if (envGemini) {
    for (const k of envGemini.split(/[\r\n,]+/)) {
      if (k.trim()) gemini.push(k.trim());
    }
  }

  return {
    groq: Array.from(new Set(groq)),
    gemini: Array.from(new Set(gemini)),
  };
}

async function callGroqApi(platform: string, title: string, errorLog: string | null | undefined, apiKey: string): Promise<string | null> {
  const prompt = buildPrompt(platform, title, errorLog);
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'llama-3.3-70b-versatile',
      messages: [
        {
          role: 'system',
          content: 'Anda adalah Senior Cloud Infrastructure & Web Hosting Systems Engineer untuk Customer Support Jagoan Hosting. Format jawaban selalu diawali dengan 🔍 AKAR MASALAH dan 🛠️ LANGKAH PERBAIKAN.',
        },
        { role: 'user', content: prompt },
      ],
      temperature: 0.2,
      max_tokens: 1500,
    }),
  });

  if (!res.ok) return null;
  const data = await res.json();
  return data.choices?.[0]?.message?.content || null;
}

async function callGeminiApi(platform: string, title: string, errorLog: string | null | undefined, apiKey: string): Promise<string | null> {
  const prompt = buildPrompt(platform, title, errorLog);
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.2, maxOutputTokens: 1500 },
    }),
  });

  if (!res.ok) return null;
  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || null;
}

function buildPrompt(platform: string, title: string, errorLog?: string | null): string {
  let prompt = `Anda adalah Senior Cloud Infrastructure & Web Hosting Systems Engineer. Berikan analisis investigasi teknis yang mendalam dan terstruktur untuk staf Customer Support Jagoan Hosting.\n\n`
    + `Platform: ${platform}\n`
    + `Gejala / Masalah: ${title}\n`;

  if (errorLog && errorLog.trim()) {
    prompt += `Cuplikan Error Log:\n\`\`\`\n${errorLog.trim()}\n\`\`\`\n\n`;
  }

  prompt += `Format respons WAJIB terstruktur persis seperti berikut:\n`
    + `🔍 AKAR MASALAH\n(Jelaskan secara tajam akar pemicu kendala ini)\n\n`
    + `🛠️ LANGKAH PERBAIKAN\n(Tuliskan langkah 1, 2, 3 berurutan beserta perintah terminal / tindakan cPanel yang presisi)\n\n`
    + `💬 DRAF BALASAN PELANGGAN\n(Kalimat ramah yang siap disalin oleh staf CS untuk dikirimkan ke tiket/chat pelanggan)`;

  return prompt;
}

function generateDeepContextualDiagnosis(platform: string, title: string, errorLog?: string | null): string {
  const query = `${platform} ${title} ${errorLog || ''}`.toLowerCase();

  // WordPress / Elementor / PHP Memory
  if (query.includes('memory') || query.includes('exhausted') || query.includes('elementor')) {
    return `🔍 AKAR MASALAH
Batas alokasi memori PHP (memory_limit) server saat ini telah tercapai oleh proses eksekusi skrip (misal plugin berat seperti Elementor, WooCommerce, atau import database).

🛠️ LANGKAH PERBAIKAN
1. Naikkan alokasi memori di wp-config.php (tepat sebelum baris '/* That\\'s all, stop editing! */'):
   define('WP_MEMORY_LIMIT', '512M');
   define('WP_MAX_MEMORY_LIMIT', '1024M');
2. Masuk ke cPanel > Select PHP Version > Options (atau MultiPHP INI Editor):
   - Ubah memory_limit menjadi 512M
   - Ubah max_execution_time menjadi 300
   - Ubah post_max_size & upload_max_filesize menjadi 64M
3. Restart PHP-FPM atau reload web server untuk menerapkan konfigurasi.
4. Lakukan pengujian ulang di halaman editor pelanggan.

💬 DRAF BALASAN PELANGGAN
Halo Kak, kendala error pada halaman website Kakak terjadi karena batas alokasi memori PHP (memory_limit) telah tercapai saat memuat plugin editor. Kami telah mengoptimasi memory_limit akun hosting Kakak menjadi 512M. Silakan dicoba akses kembali ya Kak, terima kasih!`;
  }

  // DMARC / Yahoo / SPF Bounce
  if (query.includes('dmarc') || query.includes('yahoo') || query.includes('554') || query.includes('bounce') || query.includes('spf')) {
    return `🔍 AKAR MASALAH
Server email tujuan (seperti Yahoo Mail dan Gmail) menolak pesan (Bounce Code 554 5.7.9) karena domain pengirim belum memenuhi standar autentikasi wajib DMARC (Domain-based Message Authentication, Reporting, and Conformance) dan SPF.

🛠️ LANGKAH PERBAIKAN
1. Masuk ke cPanel > Zone Editor domain terkait.
2. Tambahkan / validasi record SPF (TXT Record):
   - Name: domainpelanggan.com.
   - Value: v=spf1 +a +mx +ip4:IP_SERVER ~all
3. Tambahkan record DMARC (TXT Record):
   - Name: _dmarc.domainpelanggan.com.
   - TTL: 14400
   - Value: v=DMARC1; p=none; sp=none; rua=mailto:admin@domainpelanggan.com
4. Pastikan DKIM aktif melalui cPanel > Email Deliverability > klik Manage > Install DKIM.
5. Tunggu propagasi DNS sekitar 10-20 menit, lalu lakukan uji kirim email ulang.

💬 DRAF BALASAN PELANGGAN
Halo Kak, email yang dikirimkan ke Yahoo sebelumnya tertolak karena kebijakan verifikasi pengirim terbaru dari Yahoo Mail. Kami telah mengonfigurasikan record DMARC, SPF, dan DKIM pada DNS domain Kakak. Saat ini pengiriman email sudah kembali normal. Silakan diuji kirim kembali ya Kak!`;
  }

  // 500 Internal Server Error / .htaccess
  if (query.includes('500') || query.includes('internal server') || query.includes('htaccess')) {
    return `🔍 AKAR MASALAH
Error 500 Internal Server Error biasanya disebabkan oleh direktif rewrite yang tidak valid pada file .htaccess, izin file/folder yang salah (permission bukan 755/644), atau crash fatal pada modul PHP.

🛠️ LANGKAH PERBAIKAN
1. Buka File Manager cPanel > public_html:
   - Rename file .htaccess menjadi .htaccess.bak
   - Buat file .htaccess baru dengan rule standar WordPress / CMS
2. Periksa permission:
   - Folder wajib berizin 755 (rwxr-xr-x)
   - File wajib berizin 644 (rw-r--r--)
3. Buka file error_log di public_html untuk mengidentifikasi skrip PHP yang memicu error fatal.
4. Jika error terkait plugin, rename folder plugin bermasalah di wp-content/plugins/.

💬 DRAF BALASAN PELANGGAN
Halo Kak, kendala Error 500 pada website Kakak berhasil kami tangani. Masalah ini dipicu oleh rule konfigurasi .htaccess yang sempat crash. Kami telah mereset dan memulihkan file konfigurasi website ke pengaturan optimal. Saat ini website sudah dapat diakses dengan normal kembali.`;
  }

  // Node.js / Port / PM2
  if (query.includes('node') || query.includes('pm2') || query.includes('port') || query.includes('eaddrinuse')) {
    return `🔍 AKAR MASALAH
Aplikasi Node.js gagal start (Crash Loop) karena terjadi port conflict (EADDRINUSE) di mana port tujuan masih dikunci oleh zombie process atau instance service sebelumnya.

🛠️ LANGKAH PERBAIKAN
1. Login via Terminal SSH ke server:
2. Periksa proses yang menggunakan port:
   netstat -tulnp | grep :3000
   atau: fuser 3000/tcp
3. Hentikan proses yang menggantung:
   fuser -k 3000/tcp
4. Bersihkan modul dan build ulang:
   npm ci --omit=dev && npm run build
5. Jalankan kembali aplikasi via PM2:
   pm2 restart all && pm2 save
6. Verifikasi log: pm2 logs --lines 20

💬 DRAF BALASAN PELANGGAN
Halo Kak, kendala aplikasi Node.js yang sempat tidak merespons telah kami atasi. Terjadi port conflict dari sesi proses sebelumnya. Kami telah membersihkan port dan me-restart supervisor PM2. Saat ini aplikasi Kakak sudah aktif dan berjalan normal.`;
  }

  // Generic Sysadmin Diagnosis
  return `🔍 AKAR MASALAH
Investigasi pada platform ${platform} terkait "${title}" mengindikasikan adanya kendala pada alur eksekusi service, izin direktori, atau konfigurasi runtime environment.

🛠️ LANGKAH PERBAIKAN
1. Periksa ketersediaan resource server (Disk Inode & Memory):
   df -h && df -i
2. Verifikasi status web server & log error:
   tail -n 60 /var/log/nginx/error.log (atau cPanel error_log)
3. Pastikan dependensi dan runtime (${platform}) berjalan pada versi yang kompatibel.
4. Lakukan reload service dan clear cache aplikasi untuk memastikan status 200 OK.

💬 DRAF BALASAN PELANGGAN
Halo Kak, kami telah melakukan investigasi dan penanganan teknis terhadap kendala "${title}" pada layanan Kakak. Seluruh service telah kami verifikasi dan saat ini berjalan dengan baik. Jika ada hal lain yang perlu dibantu, silakan hubungi kami kembali!`;
}
