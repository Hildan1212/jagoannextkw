'use client';

import React, { useState } from 'react';

export default function ExtensionDownloadModal() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Hidden/Discreet Button in Footer */}
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 border border-stone-200 transition cursor-pointer group"
        title="Unduh dan pasang ekstensi browser Chrome/Edge secara mandiri"
      >
        <span className="group-hover:scale-110 transition">🧩</span>
        <span>Pasang Ekstensi</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-stone-200 text-stone-700">Alt+J</span>
      </button>

      {/* Modal Dialog */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          {/* Backdrop Blur */}
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsOpen(false)}
          />

          {/* Modal Container */}
          <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
            <div
              className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-2xl border border-stone-200"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="p-5 sm:p-6 border-b border-stone-100 flex items-start justify-between bg-stone-50/50">
                <div className="flex items-center space-x-3.5">
                  <img
                    src="/logo.png"
                    className="w-11 h-11 rounded-xl shadow-xs object-contain"
                    alt="JagoanSearch Logo"
                  />
                  <div>
                    <h3 className="text-base sm:text-lg font-bold text-stone-900 leading-tight">
                      Pasang Ekstensi JagoanSearch Browser
                    </h3>
                    <p className="text-xs text-stone-500 mt-0.5">
                      Akses cepat pencarian tutorial &amp; AI Copilot dari tab apa saja.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition cursor-pointer"
                  title="Tutup (Esc)"
                >
                  ✕
                </button>
              </div>

              {/* Body */}
              <div className="p-5 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
                {/* Download Action Card */}
                <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-sm text-blue-950">📦 jagoan-search-extension.zip</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-200/80 text-blue-800">
                        Siap Pasang
                      </span>
                    </div>
                    <p className="text-xs text-blue-700 mt-1">
                      Ukuran ringan ~66 KB &bull; Termasuk 236 panduan offline lokal &bull; Chrome &amp; Edge
                    </p>
                  </div>
                  <a
                    href="/downloads/jagoan-search-extension.zip"
                    download="jagoan-search-extension.zip"
                    className="inline-flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm transition shrink-0 group"
                  >
                    <svg
                      className="w-4 h-4 group-hover:-translate-y-0.5 transition"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                      />
                    </svg>
                    <span>Unduh File Ekstensi (.ZIP)</span>
                  </a>
                </div>

                {/* 4 Langkah Mudah */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center space-x-1.5">
                    <span>🛠️</span>
                    <span>Panduan Pasang Mandiri (Hanya 1 Menit)</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {/* Langkah 1 */}
                    <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-1.5">
                      <div className="flex items-center space-x-2">
                        <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-[10px] font-bold">
                          1
                        </span>
                        <span className="font-bold text-stone-900">Ekstrak File ZIP</span>
                      </div>
                      <p className="text-stone-600 text-[11.5px] leading-relaxed">
                        Setelah download selesai, klik kanan file ZIP lalu pilih <strong>&quot;Extract All&quot;</strong> ke folder laptop Anda (misal di folder Dokumen).
                      </p>
                    </div>

                    {/* Langkah 2 */}
                    <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-1.5">
                      <div className="flex items-center space-x-2">
                        <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-[10px] font-bold">
                          2
                        </span>
                        <span className="font-bold text-stone-900">Buka Halaman Ekstensi</span>
                      </div>
                      <p className="text-stone-600 text-[11.5px] leading-relaxed">
                        Buka tab baru di browser Anda dan ketik URL:
                        <br />
                        <code className="px-1.5 py-0.5 rounded bg-stone-200/80 font-mono text-[10.5px]">chrome://extensions</code> (Chrome)
                        <br />
                        <code className="px-1.5 py-0.5 rounded bg-stone-200/80 font-mono text-[10.5px]">edge://extensions</code> (Edge)
                      </p>
                    </div>

                    {/* Langkah 3 */}
                    <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-1.5">
                      <div className="flex items-center space-x-2">
                        <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-[10px] font-bold">
                          3
                        </span>
                        <span className="font-bold text-stone-900">Aktifkan Developer Mode</span>
                      </div>
                      <p className="text-stone-600 text-[11.5px] leading-relaxed">
                        Di pojok kanan atas halaman ekstensi, aktifkan toggle / saklar <strong>&quot;Developer mode&quot;</strong> (Mode pengembang).
                      </p>
                    </div>

                    {/* Langkah 4 */}
                    <div className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-1.5">
                      <div className="flex items-center space-x-2">
                        <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-[10px] font-bold">
                          4
                        </span>
                        <span className="font-bold text-stone-900">Muat Unpacked Folder</span>
                      </div>
                      <p className="text-stone-600 text-[11.5px] leading-relaxed">
                        Klik tombol <strong>&quot;Load unpacked&quot;</strong> (Muat yang belum dibongkar) di kiri atas, lalu pilih folder hasil ekstrak tadi. Selesai!
                      </p>
                    </div>
                  </div>
                </div>

                {/* Shortcut Guide Card */}
                <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs flex items-center justify-between gap-3">
                  <div className="flex items-center space-x-2.5">
                    <span className="text-base">⌨️</span>
                    <div>
                      <span className="font-bold text-amber-950">Shortcut Utama:</span>
                      <span className="text-amber-900 ml-1.5">
                        Tekan{' '}
                        <kbd className="px-1.5 py-0.5 rounded bg-white border border-amber-300 font-bold text-[10.5px]">Alt</kbd>{' '}
                        +{' '}
                        <kbd className="px-1.5 py-0.5 rounded bg-white border border-amber-300 font-bold text-[10.5px]">J</kbd>{' '}
                        kapan saja untuk mencari langsung.
                      </span>
                    </div>
                  </div>
                  <span className="hidden sm:inline text-[11px] text-amber-800 font-medium">
                    Bisa dari YouTube/tab apa pun
                  </span>
                </div>
              </div>

              {/* Footer Modal */}
              <div className="p-4 sm:px-6 border-t border-stone-100 bg-stone-50 flex items-center justify-between">
                <p className="text-[11px] text-stone-500">
                  Ekstensi otomatis tersinkron dengan database artikel saat server aktif.
                </p>
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-700 bg-white border border-stone-300 hover:bg-stone-100 transition cursor-pointer"
                >
                  Tutup Panduan
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
