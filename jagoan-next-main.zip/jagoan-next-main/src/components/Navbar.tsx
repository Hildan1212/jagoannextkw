'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';

export default function Navbar() {
  const pathname = usePathname();
  const { user, logout, isLoading } = useAuth();

  const isSearchActive = pathname === '/';
  const isBoardActive = pathname.startsWith('/board');
  const isAdminActive = pathname.startsWith('/admin');

  return (
    <header className="bg-white/90 backdrop-blur-md border-b border-[#E3E3DC] sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Title & Identity */}
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-3 group">
              <img
                src="/logo.png"
                className="w-8 h-8 rounded-xl shadow-xs group-hover:scale-105 transition object-contain"
                alt="JagoanSearch Logo"
              />
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm text-[#141517] tracking-tight group-hover:text-stone-700 transition">
                  Jagoan<span className="text-blue-600">Search</span>
                </span>
                <span className="text-[10px] text-[#71737B] font-medium -mt-0.5">
                  Knowledge Base Jagoan Hosting
                </span>
              </div>
            </Link>
          </div>

          {/* Right Action Navigation Links & User Controls */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            
            {/* If Logged In (Auth State) */}
            {user ? (
              <>
                {/* Nav Switcher (Clean Segmented Control) */}
                <nav className="flex items-center p-1 rounded-xl bg-stone-100 border border-[#E3E3DC] text-xs">
                  <Link
                    href="/"
                    className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center space-x-1.5 ${
                      isSearchActive ? 'bg-white text-[#141517] shadow-xs' : 'text-[#71737B] hover:text-[#141517]'
                    }`}
                  >
                    <svg
                      className={`w-3.5 h-3.5 ${isSearchActive ? 'text-blue-600' : 'text-[#71737B]'}`}
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <span>JagoanSearch</span>
                  </Link>

                  <Link
                    href="/board"
                    className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center space-x-1.5 ${
                      isBoardActive ? 'bg-white text-[#141517] shadow-xs' : 'text-[#71737B] hover:text-[#141517]'
                    }`}
                  >
                    <svg
                      className={`w-3.5 h-3.5 ${isBoardActive ? 'text-[#141517]' : 'text-[#71737B]'}`}
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" />
                      <rect x="9" y="3" width="6" height="4" rx="1" />
                    </svg>
                    <span>Board Kasus</span>
                  </Link>

                  {/* ONLY ADMIN sees Kelola Template */}
                  {user.role === 'admin' && (
                    <Link
                      href="/admin"
                      className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center space-x-1.5 ${
                        isAdminActive ? 'bg-white text-[#141517] shadow-xs' : 'text-[#71737B] hover:text-[#141517]'
                      }`}
                    >
                      <svg
                        className={`w-3.5 h-3.5 ${isAdminActive ? 'text-[#141517]' : 'text-[#71737B]'}`}
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                      <span>Kelola Template</span>
                    </Link>
                  )}
                </nav>

                {/* User Profile Badge & Logout */}
                <div className="flex items-center space-x-2.5 pl-3 border-l border-[#E3E3DC]">
                  <div className="flex items-center space-x-2">
                    <div
                      className={`w-8 h-8 rounded-full ${
                        user.role === 'admin' ? 'bg-indigo-700 text-white' : 'bg-stone-800 text-white'
                      } flex items-center justify-center text-xs font-bold font-display shadow-2xs`}
                    >
                      {user.name ? user.name[0].toUpperCase() : 'S'}
                    </div>
                    <div className="hidden md:flex flex-col text-left">
                      <span className="text-xs font-bold text-[#141517] leading-tight">{user.name}</span>
                      <div className="flex items-center space-x-1">
                        <span
                          className={`inline-block w-1.5 h-1.5 rounded-full ${
                            user.role === 'admin' ? 'bg-indigo-600' : 'bg-emerald-600'
                          }`}
                        ></span>
                        <span
                          className={`text-[10px] font-semibold uppercase tracking-wider ${
                            user.role === 'admin' ? 'text-indigo-700 font-bold' : 'text-stone-500'
                          }`}
                        >
                          {user.role === 'admin' ? 'ADMIN' : 'AGENT'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={logout}
                    title="Keluar dari akun"
                    className="p-2 sm:px-2.5 sm:py-1.5 rounded-lg text-xs font-medium text-[#71737B] hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition flex items-center space-x-1 cursor-pointer"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                      <polyline points="16 17 21 12 16 7" />
                      <line x1="21" y1="12" x2="9" y2="12" />
                    </svg>
                    <span className="hidden sm:inline">Keluar</span>
                  </button>
                </div>
              </>
            ) : (
              /* If Not Logged In: Show Clean 'Masuk Staf ➔' Button (Exact match with Laravel) */
              !isLoading && (
                <Link
                  href="/login"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#141517] text-white shadow-sm hover:bg-stone-800 transition flex items-center space-x-1.5 cursor-pointer"
                >
                  <span>Masuk Staf</span>
                  <span>➔</span>
                </Link>
              )
            )}

          </div>

        </div>
      </div>
    </header>
  );
}
