'use client';

import React, { useEffect } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';

export default function Gatekeeper({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const pathname = usePathname();
  const router = useRouter();

  const isLoginPage = pathname === '/login';

  useEffect(() => {
    if (!isLoading && !user && !isLoginPage) {
      router.replace('/login');
    }
  }, [user, isLoading, isLoginPage, router]);

  // If loading session, show clean minimal loading placeholder
  if (isLoading) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center space-y-3">
        <div className="w-6 h-6 border-2 border-stone-800 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs text-[#71737B] font-mono">Memverifikasi sesi staf...</p>
      </div>
    );
  }

  // If not logged in and not on login page, prevent showing protected content while redirecting
  if (!user && !isLoginPage) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center space-y-4 text-center max-w-sm mx-auto">
        <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-base">
          🔒
        </div>
        <div className="space-y-1">
          <h2 className="font-display font-bold text-sm text-[#141517]">Akses Terbatas Staf</h2>
          <p className="text-xs text-[#52545A]">Silakan masuk dengan akun staf Anda terlebih dahulu untuk membuka portal Jagoan Search.</p>
        </div>
        <button
          onClick={() => router.push('/login')}
          className="px-4 py-2 bg-stone-900 text-white rounded-xl text-xs font-semibold hover:bg-stone-800 transition"
        >
          Masuk ke Portal Staf ➔
        </button>
      </div>
    );
  }

  return <>{children}</>;
}
