'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { StaffUser, INITIAL_STAFF_USERS } from '@/lib/board-data';

interface AuthContextType {
  user: StaffUser | null;
  isLoading: boolean;
  login: (usernameOrEmail: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  loginAs: (staff: StaffUser) => void;
  logout: () => void;
  recentUsers: StaffUser[];
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  login: async () => ({ success: false }),
  loginAs: () => {},
  logout: () => {},
  recentUsers: [],
});

const STORAGE_KEY = 'jagoan_session_user';
const RECENT_KEY = 'jagoan_recent_logins';
const COOKIE_NAME = 'jagoan_session';

function setPersistentCookie(val: string) {
  if (typeof document !== 'undefined') {
    // 1 year expiration for permanent locked session
    const maxAge = 365 * 24 * 60 * 60;
    document.cookie = `${COOKIE_NAME}=${encodeURIComponent(val)}; path=/; max-age=${maxAge}; SameSite=Lax`;
  }
}

function clearPersistentCookie() {
  if (typeof document !== 'undefined') {
    document.cookie = `${COOKIE_NAME}=; path=/; max-age=0; SameSite=Lax`;
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<StaffUser | null>(null);
  const [recentUsers, setRecentUsers] = useState<StaffUser[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const router = useRouter();

  // Load persistent session and recent logins on mount
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (parsed && (parsed.username || parsed.name)) {
            setUser(parsed);
          }
        }

        const recent = localStorage.getItem(RECENT_KEY);
        if (recent) {
          const parsedRecent = JSON.parse(recent);
          if (Array.isArray(parsedRecent)) {
            setRecentUsers(parsedRecent);
          }
        }
      }
    } catch (e) {
      console.warn('Failed to parse persistent user session:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  function saveRecentUser(staff: StaffUser) {
    if (typeof window === 'undefined') return;
    try {
      const existing = recentUsers.filter(u => u.username !== staff.username);
      const updated = [staff, ...existing].slice(0, 5);
      setRecentUsers(updated);
      localStorage.setItem(RECENT_KEY, JSON.stringify(updated));
    } catch (e) {
      // ignore
    }
  }

  function loginAs(staff: StaffUser) {
    setUser(staff);
    saveRecentUser(staff);
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(staff));
      setPersistentCookie(JSON.stringify(staff));
      window.dispatchEvent(new CustomEvent('jagoan_auth_change', { detail: staff }));
    }
    router.push('/');
  }

  async function login(usernameOrEmail: string, pass: string): Promise<{ success: boolean; error?: string }> {
    const input = usernameOrEmail.trim().toLowerCase();
    const passInput = pass.trim();

    try {
      // Call backend API
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: input, password: passInput }),
      });

      const data = await res.json();
      if (data.success && data.user) {
        loginAs(data.user);
        return { success: true };
      } else {
        return { success: false, error: data.error || 'Login gagal' };
      }
    } catch (networkErr) {
      // Offline / Local fallback to INITIAL_STAFF_USERS
      const found = INITIAL_STAFF_USERS.find(
        (u) =>
          u.username.toLowerCase() === input ||
          u.name.toLowerCase() === input ||
          (u.email && u.email.toLowerCase() === input)
      );

      if (found) {
        if (!found.password || found.password === passInput) {
          loginAs(found);
          return { success: true };
        } else {
          return { success: false, error: 'Kata sandi tidak sesuai.' };
        }
      }

      return { success: false, error: 'Gagal terhubung ke server autentikasi.' };
    }
  }

  function logout() {
    setUser(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEY);
      clearPersistentCookie();
      window.dispatchEvent(new CustomEvent('jagoan_auth_change', { detail: null }));
    }
    router.push('/login');
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, loginAs, logout, recentUsers }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
