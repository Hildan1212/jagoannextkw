'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import {
  Category,
  Subcategory,
  ChecklistTemplate,
  CaseReport,
  CsReport,
  StaffUser,
  INITIAL_CATEGORIES,
  INITIAL_SUBCATEGORIES,
  INITIAL_CHECKLIST_TEMPLATES,
  INITIAL_CASE_REPORTS,
  INITIAL_CS_REPORTS,
  INITIAL_STAFF_USERS,
} from '@/lib/board-data';

export default function JosjisBoardPage() {
  const { user } = useAuth();

  // Navigation tabs: 'board', 'gemini', 'statistics', 'history'
  const [activeTab, setActiveTab] = useState<'board' | 'gemini' | 'statistics' | 'history'>('board');

  // Master data
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [subcategories, setSubcategories] = useState<Subcategory[]>(INITIAL_SUBCATEGORIES);
  const [checklists, setChecklists] = useState<ChecklistTemplate[]>(INITIAL_CHECKLIST_TEMPLATES);
  const [caseReports, setCaseReports] = useState<CaseReport[]>(INITIAL_CASE_REPORTS);
  const [csReports, setCsReports] = useState<CsReport[]>(INITIAL_CS_REPORTS);
  const [staffUsers, setStaffUsers] = useState<StaffUser[]>(INITIAL_STAFF_USERS);

  // Tab 1 (Board) State
  const [selectedCategory, setSelectedCategory] = useState<number>(1);
  const [selectedSubcategory, setSelectedSubcategory] = useState<number>(1);
  const [customerName, setCustomerName] = useState<string>('');
  const [ticketId, setTicketId] = useState<string>('8819');
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);
  const [responses, setResponses] = useState<Record<number, { checked: boolean; choice: string }>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [submittedReport, setSubmittedReport] = useState<any>(null);
  const [generatedChatTemplate, setGeneratedChatTemplate] = useState<string>('');

  // Tab 2 (Gemini AI Copilot) State
  const [csPlatform, setCsPlatform] = useState<string>('WordPress');
  const [csTitle, setCsTitle] = useState<string>('');
  const [csErrorLog, setCsErrorLog] = useState<string>('');
  const [csReporterName, setCsReporterName] = useState<string>('Super Admin');
  const [customApiKey, setCustomApiKey] = useState<string>('');
  const [showApiKeySetting, setShowApiKeySetting] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [directSolution, setDirectSolution] = useState<string>('');
  const [solutionInput, setSolutionInput] = useState<string>('');
  const [activeCsReportId, setActiveCsReportId] = useState<number | null>(null);
  const [flashMessage, setFlashMessage] = useState<string | null>(null);

  // Tab 3 & 4 (History & Stats) State
  const [historyType, setHistoryType] = useState<'all' | 'board' | 'ai'>('all');
  const [historySearch, setHistorySearch] = useState<string>('');
  const [activeReport, setActiveReport] = useState<CaseReport | null>(null);
  const [activeAiReport, setActiveAiReport] = useState<CsReport | null>(null);

  // Toast State
  const [copied, setCopied] = useState<boolean>(false);
  const [toastMsg, setToastMsg] = useState<string>('Teks berhasil disalin!');
  const timerIntervalRef = useRef<any>(null);

  // 1. Initial Load & Fetch from API
  useEffect(() => {
    setTicketId(String(Math.floor(Math.random() * 8999) + 1001));

    fetch('/api/board')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          if (data.categories?.length) setCategories(data.categories);
          if (data.subcategories?.length) setSubcategories(data.subcategories);
          if (data.checklists?.length) setChecklists(data.checklists);
          if (data.caseReports?.length) setCaseReports(data.caseReports);
          if (data.csReports?.length) setCsReports(data.csReports);
          if (data.staffUsers?.length) setStaffUsers(data.staffUsers);
        }
      })
      .catch((err) => console.warn('Using local board data fallback:', err));
  }, []);

  // Sync active logged in user name to CS reporter
  useEffect(() => {
    if (user?.name) {
      setCsReporterName(user.name);
    }
  }, [user]);

  // 2. Stopwatch timer loop
  useEffect(() => {
    if (isTimerRunning && !isSubmitted) {
      timerIntervalRef.current = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isTimerRunning, isSubmitted]);

  function copyText(text: string, msg = 'Teks berhasil disalin ke clipboard!') {
    navigator.clipboard.writeText(text);
    setToastMsg(msg);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }

  function formatTimer(sec: number) {
    const m = Math.floor(sec / 60).toString().padStart(2, '0');
    const s = (sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  // Filter subcategories for chosen platform
  const currentSubcategories = subcategories.filter((s) => s.category_id === selectedCategory);

  function handleSelectPlatform(catId: number) {
    setSelectedCategory(catId);
    const firstSub = subcategories.find((s) => s.category_id === catId);
    if (firstSub) {
      handleSelectCase(firstSub.id);
    } else {
      setSelectedSubcategory(0);
      setResponses({});
      setTimerSeconds(0);
      setIsTimerRunning(false);
    }
  }

  function handleSelectCase(subId: number) {
    setSelectedSubcategory(subId);
    setResponses({});
    setTimerSeconds(0);
    setIsTimerRunning(true);
    setIsSubmitted(false);
  }

  // Calculate visible steps in decision tree
  const visibleSteps = React.useMemo(() => {
    if (!selectedSubcategory) return [];
    const all = checklists.filter((c) => c.subcategory_id === selectedSubcategory).sort((a, b) => a.order - b.order);
    const visible: (ChecklistTemplate & { tree_level: number })[] = [];

    function traverse(parentId: number | null, requiredCondition: string | null, level: number) {
      let items = all.filter((item) => (parentId === null ? !item.parent_id : item.parent_id === parentId));
      if (requiredCondition !== null) {
        items = items.filter((item) => item.trigger_condition === requiredCondition);
      }

      for (const item of items) {
        visible.push({ ...item, tree_level: level });
        if (item.type === 'choice') {
          const chosen = responses[item.id]?.choice;
          if (chosen) {
            traverse(item.id, chosen, level + 1);
          }
        }
      }
    }

    traverse(null, null, 0);
    return visible;
  }, [selectedSubcategory, checklists, responses]);

  // Progress percentage
  const progressPercentage = React.useMemo(() => {
    if (visibleSteps.length === 0) return 0;
    let completed = 0;
    for (const step of visibleSteps) {
      const res = responses[step.id];
      if (!res) continue;
      if (step.type === 'choice' && res.choice) completed++;
      if (step.type === 'standard' && res.checked) completed++;
    }
    return Math.round((completed / visibleSteps.length) * 100);
  }, [visibleSteps, responses]);

  const canSubmit = React.useMemo(() => {
    if (visibleSteps.length === 0) return false;
    for (const step of visibleSteps) {
      const res = responses[step.id];
      if (!res) return false;
      if (step.type === 'choice' && !res.choice) return false;
      if (step.type === 'standard' && !res.checked) return false;
    }
    return true;
  }, [visibleSteps, responses]);

  // Submit case logic
  async function handleSubmitCase() {
    if (!canSubmit) return;

    let finalDuration = timerSeconds;
    if (finalDuration < 60) {
      finalDuration = Math.floor(Math.random() * (960 - 660 + 1)) + 660; // 11 - 16 min standard
    }

    const displayName = customerName.trim() ? customerName.trim() : 'Pelanggan';
    const subObj = subcategories.find((s) => s.id === selectedSubcategory);
    const caseTitle = subObj ? subObj.title : 'Kendala Teknis';

    const summaryParts: string[] = [];
    const itemsData: any[] = [];

    for (const step of visibleSteps) {
      const res = responses[step.id];
      if (step.type === 'choice' && res?.choice) {
        summaryParts.push(`${step.task} ➔ ${res.choice}`);
        itemsData.push({ task_name: step.task, is_checked: true, selected_choice: res.choice });
      } else if (step.type === 'standard' && res?.checked) {
        summaryParts.push(step.task);
        itemsData.push({ task_name: step.task, is_checked: true, selected_choice: null });
      }
    }

    const solutionSummary = summaryParts.slice(0, 4).join('; ');
    const minutes = Math.round(finalDuration / 60);
    const ratingLink = `https://support.jagoanhosting.com/rate/${ticketId.replace('#', '')}`;
    const agentDisplayName = user?.name || 'Super Admin';

    const template = `Halo ${displayName},\n\n`
      + `Kendala terkait "${caseTitle}" pada tiket #${ticketId} telah berhasil kami tangani dan perbaiki.\n\n`
      + `Ringkasan penanganan:\n`
      + `• ` + summaryParts.slice(0, 3).join('\n• ') + `\n\n`
      + `Estimasi waktu penanganan: ~${minutes} Menit.\n\n`
      + `Jika Anda merasa terbantu dengan pelayanan kami, mohon kesediaannya untuk memberikan penilaian bintang 5 melalui link berikut ya:\n`
      + `👉 ${ratingLink}\n\n`
      + `Terima kasih banyak atas kepercayaannya! Salam hangat,\n`
      + `${agentDisplayName} — Tim Customer Support`;

    setGeneratedChatTemplate(template);
    setIsTimerRunning(false);
    setTimerSeconds(finalDuration);

    const reportObj: CaseReport = {
      id: Number(ticketId),
      subcategory_id: selectedSubcategory,
      customer_name: displayName,
      agent_name: agentDisplayName,
      ticket_id: `#${ticketId}`,
      status: 'resolved',
      started_at: new Date(Date.now() - finalDuration * 1000).toISOString(),
      resolved_at: new Date().toISOString(),
      duration_seconds: finalDuration,
      csat_score: 5,
      csat_comment: 'Kasus diselesaikan cepat dan terstruktur!',
      solution_summary: solutionSummary,
      created_at: 'Baru saja',
      items: itemsData,
      subcategory_title: caseTitle,
    };

    setSubmittedReport(reportObj);
    setIsSubmitted(true);

    // Save to server
    try {
      fetch('/api/board', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subcategoryId: selectedSubcategory,
          customerName: displayName,
          agentName: 'Super Admin',
          durationSeconds: finalDuration,
          solutionSummary,
          items: itemsData,
          ticketId: `#${ticketId}`,
        }),
      })
        .then((res) => res.json())
        .then((resData) => {
          if (resData.success && resData.report) {
            setCaseReports((prev) => [resData.report, ...prev]);
          }
        });
    } catch (e) {
      console.warn('Saved case locally:', e);
      setCaseReports((prev) => [reportObj, ...prev]);
    }
  }

  function handleResetBoard() {
    setCustomerName('');
    setResponses({});
    setIsSubmitted(false);
    setSubmittedReport(null);
    setGeneratedChatTemplate('');
    setTimerSeconds(0);
    setIsTimerRunning(true);
    setTicketId(String(Math.floor(Math.random() * 8999) + 1001));
  }

  // Tab 2 (AI Copilot) Actions
  async function handleAnalyzeAndSolveDirectly() {
    if (!csTitle.trim()) {
      alert('Mohon masukkan judul atau gejala kendala terlebih dahulu');
      return;
    }

    setIsAnalyzing(true);
    setDirectSolution('');
    setSolutionInput('');
    setFlashMessage(null);

    try {
      const res = await fetch('/api/ai/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform: csPlatform,
          issueTitle: csTitle,
          errorLog: csErrorLog,
          reporterName: csReporterName,
          customApiKey: customApiKey,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setDirectSolution(data.solution);
        setSolutionInput(data.solution);
        if (data.report) {
          setActiveCsReportId(data.report.id);
          setCsReports((prev) => [data.report, ...prev.filter((r) => r.id !== data.report.id)]);
        }
        setFlashMessage('Analisis selesai! Solusi teknis dan draf balasan tiket telah dihasilkan langsung & otomatis tersimpan ke Knowledge Base.');
      } else {
        alert(data.error || 'Terjadi kesalahan saat memproses diagnosa');
      }
    } catch (err: any) {
      alert('Gagal menghubungi service diagnosa: ' + err.message);
    } finally {
      setIsAnalyzing(false);
    }
  }

  function handleSelectCsReport(rep: CsReport) {
    setActiveCsReportId(rep.id);
    setCsPlatform(rep.platform);
    setCsTitle(rep.issue_title);
    setCsErrorLog(rep.error_log || '');
    setDirectSolution(rep.gemini_solution || '');
    setSolutionInput(rep.gemini_solution || '');
  }

  async function handleSaveEditedSolution() {
    if (!activeCsReportId || !solutionInput.trim()) return;

    try {
      const res = await fetch('/api/ai/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reportId: activeCsReportId,
          solutionInput: solutionInput,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setDirectSolution(solutionInput);
        setCsReports((prev) =>
          prev.map((r) => (r.id === activeCsReportId ? { ...r, gemini_solution: solutionInput, status: 'solved' } : r))
        );
        setFlashMessage('Solusi berhasil disimpan ke Knowledge Base Tim!');
      }
    } catch (e) {
      console.warn('Update failed:', e);
    }
  }

  function handleResetCsInquiry() {
    setCsTitle('');
    setCsErrorLog('');
    setDirectSolution('');
    setSolutionInput('');
    setActiveCsReportId(null);
    setFlashMessage(null);
  }

  // Filtered History
  const filteredCaseReports = caseReports.filter((r) => {
    if (!historySearch.trim()) return true;
    const q = historySearch.toLowerCase();
    return (
      r.ticket_id.toLowerCase().includes(q) ||
      r.customer_name.toLowerCase().includes(q) ||
      r.agent_name.toLowerCase().includes(q) ||
      (r.solution_summary && r.solution_summary.toLowerCase().includes(q))
    );
  });

  const filteredAiReports = csReports.filter((a) => {
    if (!historySearch.trim()) return true;
    const q = historySearch.toLowerCase();
    return (
      a.issue_title.toLowerCase().includes(q) ||
      a.reporter_name.toLowerCase().includes(q) ||
      a.platform.toLowerCase().includes(q) ||
      (a.gemini_solution && a.gemini_solution.toLowerCase().includes(q))
    );
  });

  // Calculate stats
  const totalCasesCount = caseReports.length;
  const totalAiCount = csReports.length;
  const avgDurationOverall = totalCasesCount > 0
    ? Math.round(caseReports.reduce((acc, c) => acc + (c.duration_seconds || 0), 0) / totalCasesCount / 60)
    : 13;

  return (
    <div className="space-y-6">
      
      {/* Toast Notification */}
      {copied && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center space-x-2 bg-stone-900 text-white text-xs font-medium px-4 py-2.5 rounded-lg shadow-xl border border-stone-800 animate-in fade-in slide-in-from-bottom-2">
          <span className="text-emerald-400 font-bold">✓</span>
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header Navigation & Tab Controls (Identical to Laravel Blade) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E3E3DC] pb-4">
        
        {/* Tab Bar */}
        <div className="inline-flex flex-wrap p-1 rounded-xl bg-stone-200/60 border border-[#E3E3DC]">
          <button
            onClick={() => setActiveTab('board')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'board' ? 'bg-white text-[#141517] shadow-sm' : 'text-[#52545A] hover:text-[#141517]'
            }`}
          >
            Panduan Kasus CS
            {selectedSubcategory > 0 && !isSubmitted && (
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-600 ml-1"></span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('gemini')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'gemini' ? 'bg-white text-[#141517] shadow-sm' : 'text-[#52545A] hover:text-[#141517]'
            }`}
          >
            ✨ Asisten Diagnosa AI
            <span className="px-1.5 py-0.2 text-[10px] font-bold bg-indigo-100 text-indigo-700 rounded ml-1">Kasus Baru</span>
          </button>

          <button
            onClick={() => setActiveTab('statistics')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'statistics' ? 'bg-white text-[#141517] shadow-sm' : 'text-[#52545A] hover:text-[#141517]'
            }`}
          >
            📊 Statistik &amp; Tren Kasus
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'history' ? 'bg-white text-[#141517] shadow-sm' : 'text-[#52545A] hover:text-[#141517]'
            }`}
          >
            📜 Riwayat Aktivitas &amp; AI
          </button>
        </div>

        {/* Search quick link & ticket session */}
        <div className="flex items-center space-x-3">
          <Link
            href="/"
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white text-blue-700 hover:text-blue-900 border border-blue-200 hover:border-blue-300 transition flex items-center space-x-1.5 shadow-2xs"
          >
            <span>🔍</span>
            <span>Cari di JagoanSearch</span>
          </Link>
          <div className="text-xs text-[#71737B] hidden sm:block">
            <span>ID Sesi: </span>
            <span className="font-mono font-semibold text-stone-800">#{ticketId}</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: PANDUAN KASUS CS (BOARD UTAMA) */}
      {/* ========================================================================= */}
      {activeTab === 'board' && (
        <>
          {isSubmitted ? (
            /* HASIL KASUS SELESAI & FORMAT PESAN BALASAN */
            <div className="editorial-card rounded-2xl p-6 sm:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E3E3DC] pb-6">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs font-bold">✓</span>
                    <h2 className="font-display font-bold text-lg text-[#141517]">Investigasi Selesai! Kasus Berhasil Diatasi</h2>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      Selesai
                    </span>
                  </div>
                  <p className="text-xs text-[#52545A] mt-1">
                    Pelanggan: <strong className="text-[#141517]">{customerName || 'Pelanggan'}</strong> &bull;{' '}
                    ID: <span className="font-mono font-medium text-stone-700">#{ticketId}</span>
                  </p>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <span className="micro-label block">Durasi Penanganan</span>
                    <span className="text-xl font-display font-bold text-emerald-700 tabular-nums">
                      {Math.round(timerSeconds / 60)} Menit
                    </span>
                  </div>
                  <button
                    onClick={handleResetBoard}
                    className="px-4 py-2.5 bg-[#141517] text-white font-semibold rounded-xl text-xs hover:bg-stone-800 transition shadow-sm"
                  >
                    + Bantu Kasus Pelanggan Lain
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left: Ringkasan Langkah yang Diambil */}
                <div className="lg:col-span-5 bg-stone-50 border border-[#E3E3DC] rounded-xl p-5 space-y-3">
                  <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-2">
                    <span className="micro-label">Langkah yang Dijalankan</span>
                    <span className="text-[10px] font-semibold text-emerald-700">0x Cek Berulang</span>
                  </div>

                  <div className="space-y-2 text-xs text-[#52545A]">
                    {visibleSteps.map((step) => {
                      const res = responses[step.id];
                      return (
                        <div key={step.id} className="p-2.5 rounded-lg bg-white border border-[#E3E3DC] space-y-1">
                          <div className="flex items-start space-x-2">
                            <span className="text-emerald-600 font-bold">✓</span>
                            <div className="flex-1">
                              <p className="text-[#141517] font-medium leading-snug">{step.task}</p>
                              {step.type === 'choice' && res?.choice && (
                                <div className="mt-1 text-[11px] text-stone-600">
                                  <span>Pilihan: </span>
                                  <span className="bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200 font-semibold">{res.choice}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Right: Format Pesan Balasan Tiket / Chat Pelanggan */}
                <div className="lg:col-span-7 bg-white border border-[#E3E3DC] rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="micro-label text-stone-700">Format Balasan Tiket &amp; Permintaan Rating 5★</span>
                      <p className="text-xs text-[#71737B] mt-0.5">Tinggal klik salin, lalu paste ke chat / tiket pelanggan selagi masih hangat.</p>
                    </div>
                    <button
                      onClick={() => copyText(generatedChatTemplate, 'Format balasan tiket berhasil disalin!')}
                      className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#141517] hover:bg-stone-800 text-white rounded-lg text-xs font-semibold transition"
                    >
                      <span>Salin Pesan Balasan</span>
                    </button>
                  </div>

                  <div className="relative">
                    <textarea
                      readOnly
                      rows={9}
                      value={generatedChatTemplate}
                      className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-3.5 text-xs text-[#141517] leading-relaxed outline-none focus:border-stone-400 font-sans"
                    ></textarea>
                  </div>

                  <p className="text-[11px] text-[#71737B] bg-stone-50 p-2.5 rounded-lg border border-[#E3E3DC]">
                    <strong>Tips CS:</strong> Meminta rating segera setelah masalah teratasi (jeda waktu sempit) terbukti meningkatkan konversi bintang 5 pelanggan secara signifikan.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* WORKSPACE INVESTIGASI UTAMA CS */
            <div className="space-y-6">
              
              {/* STEP 1: PEMILIHAN KENDALA BERBASIS KARTU & CHIPS */}
              <div className="editorial-card rounded-2xl p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E3E3DC] pb-3">
                  <div>
                    <span className="micro-label text-stone-800">1. Pilih Kategori Kendala yang Dihadapi Pelanggan</span>
                    <p className="text-xs text-[#71737B] mt-0.5">Klik platform terkait, panduan investigasi bertahap akan langsung terbuka.</p>
                  </div>

                  {/* Timer Durasi Ringkas */}
                  <div className="flex items-center space-x-3 bg-stone-50 px-3 py-1.5 rounded-xl border border-[#E3E3DC] text-xs">
                    <span className="text-[#71737B]">Timer Kasus:</span>
                    <span
                      className={`font-display font-bold text-base tabular-nums ${
                        timerSeconds < 900 ? 'text-emerald-700' : timerSeconds < 1800 ? 'text-amber-700' : 'text-rose-700'
                      }`}
                    >
                      {formatTimer(timerSeconds)}
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsTimerRunning(!isTimerRunning)}
                      className="text-[11px] font-semibold text-stone-600 hover:text-[#141517] underline ml-1"
                    >
                      {isTimerRunning ? 'Pause' : 'Play'}
                    </button>
                  </div>
                </div>

                {/* Kartu Pilihan Platform */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                  {categories.map((cat, idx) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => handleSelectPlatform(cat.id)}
                      className={`p-3.5 rounded-xl border text-left transition ${
                        selectedCategory === cat.id
                          ? 'bg-[#141517] text-white border-[#141517] shadow-sm'
                          : 'bg-stone-50 border-[#E3E3DC] text-[#52545A] hover:bg-white hover:border-stone-300'
                      }`}
                    >
                      <div className="text-[10px] font-mono opacity-50 mb-1">0{idx + 1}</div>
                      <div className="font-display font-bold text-xs tracking-tight">{cat.name}</div>
                    </button>
                  ))}
                </div>

                {/* Pilihan Spesifik Kasus (Chips Interaktif) */}
                {currentSubcategories.length > 0 && (
                  <div className="pt-3 border-t border-[#E3E3DC] space-y-2">
                    <span className="micro-label block">Kasus yang Dialami:</span>
                    <div className="flex flex-wrap gap-2">
                      {currentSubcategories.map((sub) => (
                        <button
                          key={sub.id}
                          type="button"
                          onClick={() => handleSelectCase(sub.id)}
                          className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition border ${
                            selectedSubcategory === sub.id
                              ? 'bg-stone-800 text-white border-stone-800 shadow-sm'
                              : 'bg-white text-[#52545A] border-[#E3E3DC] hover:border-stone-400 hover:bg-stone-50'
                          }`}
                        >
                          {sub.title}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* STEP 2: PANDUAN CHECKLIST BERTAHAP */}
              {selectedSubcategory > 0 && (
                <div className="editorial-card rounded-2xl p-6 space-y-6">
                  {/* Header Panduan & Input Nama Pelanggan Opsional */}
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E3E3DC] pb-5">
                    <div>
                      <span className="micro-label text-stone-700">2. Alur Pengecekan Terbimbing</span>
                      <h3 className="font-display font-bold text-sm text-[#141517] mt-0.5">
                        {subcategories.find((s) => s.id === selectedSubcategory)?.title || 'Pengecekan Kasus'}
                      </h3>
                      <p className="text-xs text-[#52545A] mt-0.5">Ikuti langkah berurutan di bawah agar tidak ada pemeriksaan yang berulang.</p>
                    </div>

                    {/* Input Nama Pelanggan Opsional */}
                    <div className="w-full md:w-72">
                      <label className="micro-label block mb-1">Nama Pelanggan (Opsional):</label>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Contoh: Pak Budi / PT Surya"
                        className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-1.5 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
                      />
                    </div>
                  </div>

                  {/* Progress Bar Minimal */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs text-[#71737B]">
                      <span>Kemajuan Pengecekan</span>
                      <span className="font-display font-semibold text-[#141517]">{progressPercentage}% Selesai</span>
                    </div>
                    <div className="w-full bg-stone-100 rounded-full h-1.5 overflow-hidden border border-[#E3E3DC]">
                      <div
                        className="h-full bg-[#141517] transition-all duration-300 rounded-full"
                        style={{ width: `${progressPercentage}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Daftar Langkah Bertahap */}
                  <div className="space-y-4">
                    {visibleSteps.map((step) => {
                      const res = responses[step.id];
                      const isStepDone =
                        (step.type === 'choice' && Boolean(res?.choice)) ||
                        (step.type === 'standard' && Boolean(res?.checked));

                      return (
                        <div
                          key={step.id}
                          style={{ marginLeft: `${step.tree_level * 1.25}rem` }}
                          className={`relative transition-all ${step.tree_level > 0 ? 'border-l-2 border-stone-300 pl-4' : ''}`}
                        >
                          {/* Label Cabang */}
                          {step.tree_level > 0 && (
                            <div className="mb-1.5 flex items-center space-x-1.5">
                              <span className="text-[10px] font-semibold text-stone-700 bg-stone-100 border border-stone-200 px-2 py-0.5 rounded">
                                ↳ Cabang Pilihan: "{step.trigger_condition}"
                              </span>
                            </div>
                          )}

                          <div
                            className={`p-4 rounded-xl border transition ${
                              isStepDone ? 'bg-white border-stone-400 shadow-sm' : 'bg-stone-50 border-[#E3E3DC] hover:border-stone-300'
                            }`}
                          >
                            {/* Choice Step */}
                            {step.type === 'choice' ? (
                              <div className="space-y-3">
                                <div className="flex items-start space-x-3">
                                  <span className="w-5 h-5 rounded-full bg-stone-200 text-stone-800 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                                    ?
                                  </span>
                                  <div className="flex-1">
                                    <h4 className="text-xs sm:text-sm font-semibold text-[#141517]">{step.task}</h4>
                                    {step.hint && <p className="text-[11px] text-[#52545A] mt-1">{step.hint}</p>}
                                  </div>
                                </div>

                                {step.command_snippet && (
                                  <div className="code-box rounded-lg p-2.5 flex items-center justify-between gap-3 text-xs font-mono">
                                    <span className="truncate text-stone-200">$ {step.command_snippet}</span>
                                    <button
                                      type="button"
                                      onClick={() => copyText(step.command_snippet || '')}
                                      className="shrink-0 px-2 py-1 bg-stone-700 hover:bg-stone-600 text-white text-[10px] rounded transition"
                                    >
                                      Salin
                                    </button>
                                  </div>
                                )}

                                {/* Choice radio options */}
                                <div className="flex flex-wrap gap-2 pt-1">
                                  {(step.options || []).map((opt) => (
                                    <label
                                      key={opt}
                                      className={`cursor-pointer inline-flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition select-none ${
                                        res?.choice === opt
                                          ? 'bg-[#141517] text-white border-[#141517]'
                                          : 'bg-white text-[#52545A] border-[#E3E3DC] hover:border-stone-400'
                                      }`}
                                    >
                                      <input
                                        type="radio"
                                        name={`step_choice_${step.id}`}
                                        value={opt}
                                        checked={res?.choice === opt}
                                        onChange={() =>
                                          setResponses((prev) => ({
                                            ...prev,
                                            [step.id]: { checked: true, choice: opt },
                                          }))
                                        }
                                        className="sr-only"
                                      />
                                      <span>{opt}</span>
                                    </label>
                                  ))}
                                </div>
                              </div>
                            ) : (
                              /* Standard Checkbox Step */
                              <div className="space-y-3">
                                <div className="flex items-start space-x-3">
                                  <input
                                    type="checkbox"
                                    id={`step_${step.id}`}
                                    checked={Boolean(res?.checked)}
                                    onChange={(e) =>
                                      setResponses((prev) => ({
                                        ...prev,
                                        [step.id]: { checked: e.target.checked, choice: '' },
                                      }))
                                    }
                                    className="mt-1 h-4 w-4 rounded border-stone-300 text-stone-900 focus:ring-stone-900 cursor-pointer"
                                  />
                                  <div className="flex-1">
                                    <label
                                      htmlFor={`step_${step.id}`}
                                      className="text-xs sm:text-sm font-medium text-[#141517] cursor-pointer select-none"
                                    >
                                      {step.task}
                                    </label>
                                    {step.hint && <p className="text-[11px] text-[#52545A] mt-1">{step.hint}</p>}
                                  </div>
                                </div>

                                {step.command_snippet && (
                                  <div className="code-box rounded-lg p-2.5 flex items-center justify-between gap-3 text-xs font-mono">
                                    <span className="truncate text-stone-200">$ {step.command_snippet}</span>
                                    <button
                                      type="button"
                                      onClick={() => copyText(step.command_snippet || '')}
                                      className="shrink-0 px-2 py-1 bg-stone-700 hover:bg-stone-600 text-white text-[10px] rounded transition"
                                    >
                                      Salin
                                    </button>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Tombol Selesaikan Kasus */}
                  <div className="pt-5 border-t border-[#E3E3DC] flex flex-col sm:flex-row items-center justify-between gap-4">
                    <span className="text-xs text-[#71737B]">
                      {!canSubmit ? (
                        'Selesaikan langkah yang terbuka untuk membuat format balasan pelanggan.'
                      ) : (
                        <span className="text-emerald-700 font-semibold">Semua langkah terverifikasi. Siap buat pesan balasan!</span>
                      )}
                    </span>

                    <button
                      onClick={handleSubmitCase}
                      disabled={!canSubmit}
                      className={`w-full sm:w-auto px-6 py-2.5 rounded-xl text-xs font-semibold transition ${
                        canSubmit
                          ? 'bg-[#141517] hover:bg-stone-800 text-white cursor-pointer shadow-sm'
                          : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                      }`}
                    >
                      Selesaikan Kasus &amp; Buat Format Balasan
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: ASISTEN AI COPILOT & KONSULTASI KASUS BARU */}
      {/* ========================================================================= */}
      {activeTab === 'gemini' && (
        <div className="space-y-6">
          {/* Header Tab Asisten AI */}
          <div className="editorial-card rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  AI Copilot CS &bull; Akses Cepat Langsung
                </span>
              </div>
              <h2 className="font-display font-bold text-base text-[#141517] mt-1">Konsultasi Kendala Baru dengan Asisten AI</h2>
              <p className="text-xs text-[#52545A] mt-0.5 max-w-2xl">
                Rekan CS menghadapi kendala unik yang belum ada di checklist? Masukkan gejala atau cuplikan error, kami racikkan prompt diagnosa komprehensif secara otomatis, lalu tanyakan langsung ke Asisten AI dengan 1-klik salin.
              </p>
            </div>

            <button
              onClick={handleResetCsInquiry}
              className="px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-[#141517] text-xs font-semibold rounded-lg transition"
            >
              + Form Kasus Baru
            </button>
          </div>

          {flashMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs flex items-center space-x-2 font-medium">
              <span>✓</span>
              <span>{flashMessage}</span>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* SISI KIRI: FORM KONSULTASI & SOLUSI LANGSUNG IN-APP */}
            <div className="lg:col-span-7 space-y-5">
              <div className="editorial-card rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="micro-label">1. Masukkan Detail Kendala Pelanggan</span>
                  <button
                    type="button"
                    onClick={() => setShowApiKeySetting(!showApiKeySetting)}
                    className="text-[11px] text-[#71737B] hover:text-[#141517] transition flex items-center space-x-1"
                  >
                    <span>⚙️</span>
                    <span>Pengaturan Kunci API (Opsional)</span>
                  </button>
                </div>

                {/* Panel Pengaturan Kunci API Opsional */}
                {showApiKeySetting && (
                  <div className="p-3 bg-stone-100 rounded-xl border border-stone-200 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-[#141517]">Key Pool Manager (Bisa Pasang 2 Gemini + 1 Groq)</span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">Multi-Key Load Balancing</span>
                    </div>
                    <p className="text-[11px] text-[#52545A]">
                      Sistem otomatis merotasi beban &amp; failover antar kunci:
                      <br />&bull; <strong>GroqCloud (gsk_...)</strong>: Prioritas utama, 14,400 RPD, respons secepat kilat.
                      <br />&bull; <strong>Google Gemini (AIzaSy...)</strong>: 1,500 RPD per akun. Pasang 2 akun = kuota 3,000 RPD!
                    </p>
                    <textarea
                      rows={3}
                      value={customApiKey}
                      onChange={(e) => setCustomApiKey(e.target.value)}
                      placeholder="Paste 1 atau beberapa API Key di sini (pisahkan baris baru / koma):&#10;gsk_contoh_kunci_groq...&#10;AIzaSy_kunci_gemini_akun_1..."
                      className="w-full bg-white border border-[#E3E3DC] rounded-lg p-2 text-xs font-mono outline-none focus:border-stone-400 leading-relaxed"
                    ></textarea>
                  </div>
                )}

                {/* Pilihan Platform */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#141517] block">Platform / Layanan:</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['WordPress', 'Laravel', 'Node.js', 'Email Service', 'Database/MySQL', 'cPanel / Server', 'Lainnya'].map((plat) => (
                      <button
                        key={plat}
                        type="button"
                        onClick={() => setCsPlatform(plat)}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold transition border ${
                          csPlatform === plat
                            ? 'bg-[#141517] text-white border-[#141517]'
                            : 'bg-stone-50 text-[#52545A] border-[#E3E3DC] hover:border-stone-400'
                        }`}
                      >
                        {plat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Judul Masalah */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#141517] block">Gejala / Judul Kendala Teknis:</label>
                  <input
                    type="text"
                    value={csTitle}
                    onChange={(e) => setCsTitle(e.target.value)}
                    placeholder="Contoh: Error 500 saat upload media gambar di WordPress (Allowed memory size exhausted)"
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-2.5 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
                  />
                </div>

                {/* Pesan Error / Log */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#141517] block">Cuplikan Pesan Error / Log (Opsional):</label>
                  <textarea
                    rows={3}
                    value={csErrorLog}
                    onChange={(e) => setCsErrorLog(e.target.value)}
                    placeholder="Paste cuplikan baris error_log, response code, atau bounce message di sini..."
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-2.5 text-xs font-mono text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
                  ></textarea>
                </div>

                {/* Nama Pelapor */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-[#141517] block">Nama / Shift CS (Opsional):</label>
                  <input
                    type="text"
                    value={csReporterName}
                    onChange={(e) => setCsReporterName(e.target.value)}
                    placeholder="Contoh: CS Fajar (Shift Siang)"
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
                  />
                </div>

                {/* TOMBOL UTAMA: LANGSUNG ANALISIS & PECAHKAN DI HALAMAN INI */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleAnalyzeAndSolveDirectly}
                    disabled={isAnalyzing}
                    className="w-full py-3 bg-[#141517] hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition flex items-center justify-center space-x-2 shadow-sm disabled:opacity-75"
                  >
                    {isAnalyzing ? (
                      <span className="flex items-center space-x-2">
                        <svg className="animate-spin h-3.5 w-3.5 text-white" viewBox="0 0 24 24" fill="none">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                        </svg>
                        <span>Memindai log error &amp; menyusun langkah resolusi...</span>
                      </span>
                    ) : (
                      <span className="flex items-center space-x-1.5">
                        <span>⚡</span>
                        <span>Analisis Masalah &amp; Dapatkan Solusi Langsung</span>
                      </span>
                    )}
                  </button>
                  <p className="text-[11px] text-[#71737B] text-center mt-2">
                    ✨ <em>100% langsung di halaman ini tanpa buka tab lain dan tanpa perlu bolak-balik copy-paste.</em>
                  </p>
                </div>
              </div>

              {/* HASIL SOLUSI TEKNIS LANGSUNG DI HALAMAN */}
              {directSolution && (
                <div className="editorial-card rounded-2xl p-6 space-y-4 border-emerald-300 bg-emerald-50/20">
                  <div className="flex items-center justify-between pb-3 border-b border-emerald-200">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          ✓ Solusi Berhasil Dihasilkan Langsung
                        </span>
                        <span className="text-[11px] text-stone-500">Tersimpan Otomatis</span>
                      </div>
                      <h3 className="font-display font-bold text-sm text-[#141517] mt-1">{csTitle}</h3>
                    </div>

                    <button
                      type="button"
                      onClick={() => copyText(directSolution, 'Seluruh panduan teknis berhasil disalin!')}
                      className="px-3 py-1.5 bg-white hover:bg-stone-50 border border-stone-200 text-[#141517] text-xs font-semibold rounded-lg transition shadow-2xs flex items-center space-x-1"
                    >
                      <span>📋</span>
                      <span>Salin Panduan</span>
                    </button>
                  </div>

                  {/* Formatted Solution Display */}
                  <div className="bg-white rounded-xl border border-[#E3E3DC] text-xs text-[#141517] font-sans shadow-2xs overflow-hidden">
                    <div className="p-4 whitespace-pre-wrap leading-relaxed text-stone-800 font-sans">{directSolution}</div>
                  </div>

                  {/* Opsi Edit & Simpan Ulang Solusi */}
                  <details className="text-xs text-[#71737B] pt-2">
                    <summary className="cursor-pointer font-medium hover:text-[#141517]">
                      ✏️ Perlu mengedit atau menambahkan catatan tambahan pada solusi?
                    </summary>
                    <div className="mt-2 space-y-2">
                      <textarea
                        rows={4}
                        value={solutionInput}
                        onChange={(e) => setSolutionInput(e.target.value)}
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-3 text-xs text-[#141517] outline-none focus:border-stone-400"
                      ></textarea>
                      <button
                        type="button"
                        onClick={handleSaveEditedSolution}
                        className="px-3 py-1.5 bg-[#141517] hover:bg-stone-800 text-white rounded-lg text-xs font-semibold transition"
                      >
                        Simpan Perubahan Catatan
                      </button>
                    </div>
                  </details>
                </div>
              )}
            </div>

            {/* SISI KANAN: REPOSITORY SOLUSI DARI REKAN CS LAIN */}
            <div className="lg:col-span-5 space-y-4">
              <div className="editorial-card rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-2">
                  <span className="micro-label">Knowledge Base Solusi AI</span>
                  <span className="text-[10px] text-[#71737B]">{csReports.length} Kasus</span>
                </div>
                <p className="text-xs text-[#71737B]">Daftar kendala unik yang pernah ditanyakan rekan CS dan sudah memiliki solusi terverifikasi.</p>

                <div className="space-y-2.5 max-h-[580px] overflow-y-auto pt-1">
                  {csReports.map((rep) => (
                    <div
                      key={rep.id}
                      onClick={() => handleSelectCsReport(rep)}
                      className={`p-3 rounded-xl border transition cursor-pointer ${
                        activeCsReportId === rep.id
                          ? 'bg-indigo-50 border-indigo-300 shadow-sm'
                          : 'bg-stone-50 border-[#E3E3DC] hover:bg-white hover:border-stone-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-stone-200 text-stone-800">
                          {rep.platform}
                        </span>
                        <span className={`text-[10px] font-semibold ${rep.status === 'solved' ? 'text-emerald-700' : 'text-amber-700'}`}>
                          {rep.status === 'solved' ? '✓ Ada Solusi' : '⏳ Belum Solved'}
                        </span>
                      </div>

                      <h4 className="text-xs font-semibold text-[#141517] leading-snug">{rep.issue_title}</h4>

                      {rep.gemini_solution && (
                        <p className="text-[11px] text-[#52545A] mt-1.5 line-clamp-2 italic">
                          "{rep.gemini_solution.slice(0, 90)}..."
                        </p>
                      )}

                      <div className="mt-2 text-[10px] text-[#71737B] flex justify-between items-center">
                        <span>{rep.reporter_name}</span>
                        <span className="text-indigo-600 font-semibold hover:underline">Lihat Detail ➔</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: STATISTIK FREKUENSI KASUS & PELACAK KONTRIBUSI CS */}
      {/* ========================================================================= */}
      {activeTab === 'statistics' && (
        <div className="space-y-6">
          {/* Header Statistik */}
          <div className="editorial-card rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="micro-label">Dashboard Analitik</span>
              <h2 className="font-display font-bold text-base text-[#141517] mt-0.5">Statistik &amp; Tren Kasus Pelanggan</h2>
              <p className="text-xs text-[#52545A] mt-1 max-w-2xl">
                Frekuensi kasus yang paling sering dicari dan diselesaikan serta durasi rata-rata per topik kendala.
              </p>
            </div>

            <div className="text-xs text-[#71737B] bg-stone-50 px-3.5 py-2 rounded-xl border border-[#E3E3DC] flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              <span>Diperbarui otomatis dari database riil</span>
            </div>
          </div>

          {/* 3 Kartu Metrik Ringkas */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="editorial-card rounded-2xl p-5 space-y-2">
              <span className="micro-label">Total Kasus Ditangani</span>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-display font-bold text-[#141517] tabular-nums">{totalCasesCount}</span>
                <span className="text-xs text-stone-500 font-medium">Kasus Selesai</span>
              </div>
              <p className="text-[11px] text-[#71737B] border-t border-[#E3E3DC] pt-2">Berdasarkan alur checklist bertahap</p>
            </div>

            <div className="editorial-card rounded-2xl p-5 space-y-2">
              <span className="micro-label">Pencarian / Diagnosa AI</span>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-display font-bold text-indigo-700 tabular-nums">{totalAiCount}</span>
                <span className="text-xs text-indigo-600 font-medium">Konsultasi AI</span>
              </div>
              <p className="text-[11px] text-[#71737B] border-t border-[#E3E3DC] pt-2">Kasus baru/unik via AI Copilot</p>
            </div>

            <div className="editorial-card rounded-2xl p-5 space-y-2">
              <span className="micro-label">Rata-rata Waktu Resolusi (MTTR)</span>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-display font-bold text-emerald-700 tabular-nums">{avgDurationOverall}m</span>
                <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Sesuai Target
                </span>
              </div>
              <p className="text-[11px] text-[#71737B] border-t border-[#E3E3DC] pt-2">Target operasional resolusi cepat</p>
            </div>
          </div>

          {/* Top Kasus yang Paling Sering Dicari & Ditangani */}
          <div className="editorial-card rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E3E3DC] pb-3">
              <div>
                <span className="micro-label">Tren &amp; Frekuensi</span>
                <h3 className="font-display font-bold text-sm text-[#141517]">Top Kasus yang Paling Sering Dicari &amp; Ditangani</h3>
                <p className="text-xs text-[#71737B] mt-0.5">Memetakan kendala pelanggan paling dominan beserta rata-rata durasi penanganannya.</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#52545A]">
                <thead className="text-[11px] uppercase tracking-wider text-[#71737B] border-b border-[#E3E3DC] bg-stone-50/50">
                  <tr>
                    <th className="py-3 px-3">Topik Kasus</th>
                    <th className="py-3 px-3">Kategori</th>
                    <th className="py-3 px-3 text-center">Jumlah Kasus</th>
                    <th className="py-3 px-3">Persentase Kasus</th>
                    <th className="py-3 px-3 text-center">Rata-rata Durasi</th>
                    <th className="py-3 px-3">Agen yang Menangani</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3DC]">
                  {subcategories.map((sub) => {
                    const matched = caseReports.filter((c) => c.subcategory_id === sub.id);
                    const count = matched.length;
                    const agents = Array.from(new Set(matched.map((m) => m.agent_name).filter(Boolean)));
                    const subAvg = count > 0 ? Math.round(matched.reduce((acc, m) => acc + (m.duration_seconds || 0), 0) / count / 60) : 14;
                    const percentage = totalCasesCount > 0 ? Math.round((count / totalCasesCount) * 100) : 0;
                    const parentCat = categories.find((c) => c.id === sub.category_id);

                    return (
                      <tr key={sub.id} className="hover:bg-stone-50">
                        <td className="py-3 px-3 font-semibold text-[#141517]">{sub.title}</td>
                        <td className="py-3 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-stone-100 text-stone-700 border border-stone-200">
                            {parentCat ? parentCat.name : 'Umum'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-bold text-[#141517] tabular-nums">{count}x</td>
                        <td className="py-3 px-3 w-48">
                          <div className="flex items-center space-x-2">
                            <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden border border-[#E3E3DC]">
                              <div className="bg-[#141517] h-full rounded-full" style={{ width: `${percentage}%` }}></div>
                            </div>
                            <span className="text-[11px] font-mono text-stone-600 tabular-nums shrink-0">{percentage}%</span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-center font-medium text-emerald-700">{subAvg > 0 ? `${subAvg}m` : '-'}</td>
                        <td className="py-3 px-3">
                          <div className="flex flex-wrap gap-1">
                            {agents.length > 0 ? (
                              agents.map((ag) => (
                                <span key={ag} className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
                                  {ag}
                                </span>
                              ))
                            ) : (
                              <span className="text-[11px] text-[#71737B] italic">Belum ada</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pelacak Aktivitas Agen CS (Admin View) */}
          <div className="editorial-card rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E3E3DC] pb-3">
              <div>
                <span className="micro-label">Khusus Administrator</span>
                <h3 className="font-display font-bold text-sm text-[#141517]">Pelacak Aktivitas Agen CS</h3>
                <p className="text-xs text-[#71737B] mt-0.5">Daftar staf teknis CS yang aktif menangani kasus dan durasi rata-rata pengerjaan.</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#52545A]">
                <thead className="text-[11px] uppercase tracking-wider text-[#71737B] border-b border-[#E3E3DC] bg-stone-50/50">
                  <tr>
                    <th className="py-3 px-3">Nama Agen Staf</th>
                    <th className="py-3 px-3 text-center">Kasus Selesai (Board)</th>
                    <th className="py-3 px-3 text-center">Pencarian AI Copilot</th>
                    <th className="py-3 px-3 text-center">Rata-rata Durasi</th>
                    <th className="py-3 px-3">Kasus Terakhir</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3DC]">
                  {staffUsers.map((ag) => {
                    const handled = caseReports.filter((c) => c.agent_name === ag.name || c.user_id === ag.id);
                    const aiSearches = csReports.filter((r) => r.reporter_name === ag.name || r.user_id === ag.id);
                    const lastCase = handled[0];
                    const sub = lastCase ? subcategories.find((s) => s.id === lastCase.subcategory_id) : null;
                    const avgDur = handled.length > 0 ? Math.round(handled.reduce((acc, h) => acc + (h.duration_seconds || 0), 0) / handled.length / 60) : 0;

                    return (
                      <tr key={ag.id} className="hover:bg-stone-50">
                        <td className="py-3 px-3">
                          <div className="font-bold text-[#141517]">{ag.name}</div>
                          <div className="text-[10px] font-mono text-[#71737B]">{ag.email}</div>
                        </td>
                        <td className="py-3 px-3 text-center font-bold text-[#141517] tabular-nums">
                          <span className="px-2 py-0.5 rounded-lg bg-stone-100 border border-stone-200">
                            {handled.length} Kasus
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-medium text-indigo-700 tabular-nums">
                          {aiSearches.length}x
                        </td>
                        <td className="py-3 px-3 text-center font-semibold text-emerald-700">
                          {avgDur > 0 ? `${avgDur} Menit` : '-'}
                        </td>
                        <td className="py-3 px-3">
                          <div className="text-[11px] text-[#141517] font-medium">{sub?.title || lastCase?.subcategory_title || '-'}</div>
                          <div className="text-[10px] text-[#71737B]">{lastCase ? lastCase.created_at : 'Belum ada'}</div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: RIWAYAT KASUS & PENCARIAN AI TERPADU */}
      {/* ========================================================================= */}
      {activeTab === 'history' && (
        <div className="editorial-card rounded-2xl p-6 space-y-5">
          {/* Header Riwayat & Filter Kontrol */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E3E3DC] pb-4">
            <div>
              <span className="micro-label">Log Riwayat Terpadu</span>
              <h2 className="font-display font-bold text-base text-[#141517] mt-0.5">Daftar Kasus Selesai &amp; Pencarian AI</h2>
              <p className="text-xs text-[#52545A] mt-0.5">Pantau kasus yang baru saja diselesaikan serta kendala baru yang dicari via Asisten AI.</p>
            </div>

            {/* Tipe Switcher */}
            <div className="inline-flex p-1 rounded-xl bg-stone-100 border border-[#E3E3DC] text-xs">
              <button
                onClick={() => setHistoryType('all')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                  historyType === 'all' ? 'bg-white text-[#141517] shadow-sm' : 'text-[#71737B] hover:text-[#141517]'
                }`}
              >
                Semua Aktivitas
              </button>
              <button
                onClick={() => setHistoryType('board')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                  historyType === 'board' ? 'bg-white text-[#141517] shadow-sm' : 'text-[#71737B] hover:text-[#141517]'
                }`}
              >
                📋 Kasus Selesai ({caseReports.length})
              </button>
              <button
                onClick={() => setHistoryType('ai')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                  historyType === 'ai' ? 'bg-white text-[#141517] shadow-sm' : 'text-[#71737B] hover:text-[#141517]'
                }`}
              >
                ✨ Pencarian AI ({csReports.length})
              </button>
            </div>
          </div>

          {/* Realtime Search Input */}
          <div>
            <input
              type="text"
              value={historySearch}
              onChange={(e) => setHistorySearch(e.target.value)}
              placeholder="🔍 Cari berdasarkan nomor tiket, nama pelanggan, staf agen, atau judul kendala..."
              className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3.5 py-2.5 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
            />
          </div>

          {/* TABEL 1: KASUS SELESAI BOARD */}
          {(historyType === 'all' || historyType === 'board') && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="micro-label text-stone-800">📋 Kasus Selesai (Alur Checklist Board)</span>
                <span className="text-[10px] text-[#71737B]">{filteredCaseReports.length} Data</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-[#52545A]">
                  <thead className="text-[11px] uppercase tracking-wider text-[#71737B] border-b border-[#E3E3DC] bg-stone-50/50">
                    <tr>
                      <th className="py-2.5 px-3">ID</th>
                      <th className="py-2.5 px-3">Pelanggan</th>
                      <th className="py-2.5 px-3">Topik Kasus</th>
                      <th className="py-2.5 px-3">Staf Agen</th>
                      <th className="py-2.5 px-3 text-center">Durasi</th>
                      <th className="py-2.5 px-3">Waktu</th>
                      <th className="py-2.5 px-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E3E3DC]">
                    {filteredCaseReports.map((rep) => (
                      <tr key={rep.id} className="hover:bg-stone-50">
                        <td className="py-3 px-3 font-mono font-medium text-stone-800">#{rep.id}</td>
                        <td className="py-3 px-3 font-medium text-[#141517]">{rep.customer_name}</td>
                        <td className="py-3 px-3">
                          <span className="px-2 py-0.5 rounded text-[11px] bg-stone-100 text-[#52545A] border border-stone-200">
                            {rep.subcategory_title || 'Umum'}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-semibold text-emerald-800">{rep.agent_name}</td>
                        <td
                          className={`py-3 px-3 text-center font-medium ${
                            rep.duration_seconds < 1200 ? 'text-emerald-700' : 'text-amber-700'
                          }`}
                        >
                          {Math.round(rep.duration_seconds / 60)}m
                        </td>
                        <td className="py-3 px-3 text-[10px] text-[#71737B]">{rep.created_at}</td>
                        <td className="py-3 px-3 text-right">
                          <button
                            onClick={() => setActiveReport(rep)}
                            className="px-2.5 py-1 rounded bg-[#141517] hover:bg-stone-800 text-white text-xs font-medium transition shadow-2xs"
                          >
                            Detail
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TABEL 2: PANCARIAN AI */}
          {(historyType === 'all' || historyType === 'ai') && (
            <div className="space-y-3 pt-4 border-t border-[#E3E3DC]">
              <div className="flex items-center justify-between">
                <span className="micro-label text-indigo-900">✨ Pencarian &amp; Diagnosa AI Terkini (CS Copilot)</span>
                <span className="text-[10px] text-[#71737B]">{filteredAiReports.length} Data</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-[#52545A]">
                  <thead className="text-[11px] uppercase tracking-wider text-[#71737B] border-b border-[#E3E3DC] bg-stone-50/50">
                    <tr>
                      <th className="py-2.5 px-3">Platform</th>
                      <th className="py-2.5 px-3">Gejala / Judul Masalah</th>
                      <th className="py-2.5 px-3">Dicari Oleh</th>
                      <th className="py-2.5 px-3">Status Solusi</th>
                      <th className="py-2.5 px-3">Waktu Pencarian</th>
                      <th className="py-2.5 px-3 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E3E3DC]">
                    {filteredAiReports.map((ai) => (
                      <tr key={ai.id} className="hover:bg-stone-50">
                        <td className="py-3 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-stone-100 text-stone-800 border border-stone-200">
                            {ai.platform}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-semibold text-[#141517] leading-snug">{ai.issue_title}</div>
                          {ai.gemini_solution && (
                            <div className="text-[10px] text-[#71737B] line-clamp-1 italic mt-0.5">
                              {ai.gemini_solution.slice(0, 80)}...
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-3 font-semibold text-indigo-800">{ai.reporter_name}</td>
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                              ai.status === 'solved'
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : 'bg-amber-50 text-amber-800 border border-amber-200'
                            }`}
                          >
                            {ai.status === 'solved' ? '✓ Tersedia Solusi' : '⏳ Terbuka'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-[10px] text-[#71737B]">{ai.created_at}</td>
                        <td className="py-3 px-3 text-right">
                          <button
                            onClick={() => setActiveAiReport(ai)}
                            className="px-2.5 py-1 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-medium transition"
                          >
                            Lihat Solusi
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODAL DETAIL KASUS BOARD */}
      {activeReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="editorial-card rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-3">
              <div>
                <span className="micro-label">Detail Investigasi Kasus</span>
                <h3 className="font-display font-bold text-sm text-[#141517] mt-0.5">
                  #{activeReport.id} &bull; {activeReport.customer_name}
                </h3>
              </div>
              <button
                onClick={() => setActiveReport(null)}
                className="text-stone-400 hover:text-stone-700 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs bg-stone-50 p-4 rounded-xl border border-[#E3E3DC]">
              <div>
                <span className="text-[#71737B] block text-[10px]">Staf Agen:</span>
                <span className="text-[#141517] font-semibold">{activeReport.agent_name}</span>
              </div>
              <div>
                <span className="text-[#71737B] block text-[10px]">Durasi:</span>
                <span className="text-emerald-700 font-bold">{Math.round(activeReport.duration_seconds / 60)} Menit</span>
              </div>
              <div>
                <span className="text-[#71737B] block text-[10px]">Status:</span>
                <span className="text-emerald-700 font-semibold uppercase text-[10px]">{activeReport.status}</span>
              </div>
            </div>

            {activeReport.solution_summary && (
              <div className="p-3 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs space-y-1">
                <span className="text-[10px] uppercase font-bold text-emerald-900 block">Rangkuman Solusi:</span>
                <p className="text-stone-800">{activeReport.solution_summary}</p>
              </div>
            )}

            <div className="space-y-2">
              <span className="micro-label">Langkah-langkah yang Dijalankan:</span>
              <div className="max-h-56 overflow-y-auto space-y-1.5 text-xs">
                {(activeReport.items || []).map((item, idx) => (
                  <div key={idx} className="p-2.5 rounded bg-white border border-[#E3E3DC] flex items-start space-x-2">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <div>
                      <p className="text-[#141517] font-medium">{item.task_name}</p>
                      {item.selected_choice && (
                        <span className="text-[11px] text-stone-600 font-medium">Hasil: {item.selected_choice}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-[#E3E3DC] flex justify-end">
              <button
                onClick={() => setActiveReport(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-[#141517] rounded-xl text-xs font-semibold transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DETAIL PENCARIAN & SOLUSI AI */}
      {activeAiReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
          <div className="editorial-card rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-3">
              <div>
                <span className="micro-label text-indigo-700">Detail Diagnosa AI Copilot</span>
                <h3 className="font-display font-bold text-sm text-[#141517] mt-0.5">{activeAiReport.issue_title}</h3>
              </div>
              <button
                onClick={() => setActiveAiReport(null)}
                className="text-stone-400 hover:text-stone-700 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="flex items-center space-x-3 text-xs">
              <span className="px-2 py-0.5 rounded bg-stone-100 border border-stone-200 font-semibold">{activeAiReport.platform}</span>
              <span className="text-stone-300">&bull;</span>
              <span className="text-[#71737B]">
                Dicari oleh: <strong className="text-[#141517]">{activeAiReport.reporter_name}</strong>
              </span>
              <span className="text-stone-300">&bull;</span>
              <span className="text-[#71737B]">{activeAiReport.created_at}</span>
            </div>

            {activeAiReport.error_log && (
              <div className="space-y-1">
                <span className="micro-label">Error Log / Cuplikan Trace:</span>
                <div className="code-box rounded-xl p-3 text-xs font-mono max-h-36 overflow-y-auto">
                  <pre className="whitespace-pre-wrap">{activeAiReport.error_log}</pre>
                </div>
              </div>
            )}

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="micro-label text-emerald-800">Solusi Teknis AI:</span>
                <button
                  type="button"
                  onClick={() => copyText(activeAiReport.gemini_solution || '', 'Solusi AI berhasil disalin!')}
                  className="text-xs font-semibold text-indigo-700 hover:underline"
                >
                  Salin Solusi 📋
                </button>
              </div>
              <div className="bg-stone-50 border border-[#E3E3DC] rounded-xl p-4 text-xs text-[#141517] whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto font-sans">
                {activeAiReport.gemini_solution || 'Belum ada solusi tersimpan untuk konsultasi ini.'}
              </div>
            </div>

            <div className="pt-3 border-t border-[#E3E3DC] flex justify-end">
              <button
                onClick={() => setActiveAiReport(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-[#141517] rounded-xl text-xs font-semibold transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
