'use client';

import React, { useState } from 'react';
import { BarChart2, TrendingUp, CheckCircle, Clock, BookOpen } from 'lucide-react';
import { defaultAiCases } from '@/lib/constants';

export default function StatsPage() {
  const [selectedCase, setSelectedCase] = useState<any | null>(null);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      
      {/* HEADER */}
      <div>
        <h1 className="text-2xl font-extrabold text-[#141517] tracking-tight flex items-center space-x-2">
          <span>📊</span>
          <span>Statistik Tren & Histori Kasus Tim Support</span>
        </h1>
        <p className="text-xs text-stone-500 mt-1">
          Pemantauan performa resolusi teknis dan arsip pencarian solusi AI tim Customer Support.
        </p>
      </div>

      {/* METRIC CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Total Kasus Masuk</div>
          <div className="text-2xl font-extrabold text-[#141517]">128</div>
          <div className="text-[10px] text-emerald-600 font-semibold flex items-center space-x-0.5">
            <TrendingUp className="w-3 h-3" />
            <span>+14% minggu ini</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Solved by AI</div>
          <div className="text-2xl font-extrabold text-purple-700">84</div>
          <div className="text-[10px] text-purple-600 font-semibold">65.6% rasio otomatisasi</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Rata-rata Waktu</div>
          <div className="text-2xl font-extrabold text-blue-600">4.2 mnt</div>
          <div className="text-[10px] text-blue-600 font-semibold flex items-center space-x-0.5">
            <Clock className="w-3 h-3" />
            <span>SLA Efisien</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-1">
          <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Keberhasilan Resolusi</div>
          <div className="text-2xl font-extrabold text-emerald-600">98.4%</div>
          <div className="text-[10px] text-emerald-600 font-semibold flex items-center space-x-0.5">
            <CheckCircle className="w-3 h-3" />
            <span>Tinggi</span>
          </div>
        </div>
      </div>

      {/* PLATFORM DISTRIBUTION BREAKDOWN */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <h2 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
          Distribusi Kategori Kendala Pelanggan
        </h2>
        
        <div className="space-y-3 text-xs">
          <div>
            <div className="flex justify-between font-semibold mb-1">
              <span>WordPress & CMS (Error 500, Plugin, DB Connection)</span>
              <span>42% (54 kasus)</span>
            </div>
            <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
              <div className="h-full bg-blue-600 rounded-full" style={{ width: '42%' }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between font-semibold mb-1">
              <span>VPS & Cloud Server (aaPanel, CyberPanel, Nginx)</span>
              <span>28% (36 kasus)</span>
            </div>
            <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
              <div className="h-full bg-purple-600 rounded-full" style={{ width: '28%' }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between font-semibold mb-1">
              <span>Email Bisnis (554 DMARC, Port SSL, SPF)</span>
              <span>18% (23 kasus)</span>
            </div>
            <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
              <div className="h-full bg-amber-500 rounded-full" style={{ width: '18%' }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between font-semibold mb-1">
              <span>Domain & SSL (Propagasi DNS, Let&apos;s Encrypt Expired)</span>
              <span>12% (15 kasus)</span>
            </div>
            <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: '12%' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* HISTORY TABLE */}
      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-2xs">
        <div className="p-4 border-b border-stone-200 flex items-center justify-between">
          <h2 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
            Riwayat Diagnosa AI & Kasus Selesai
          </h2>
          <span className="text-[11px] text-stone-400">Database TiDB Cloud</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-bold">
              <tr>
                <th className="p-3 pl-4">Platform</th>
                <th className="p-3">Judul Kasus / Gejala</th>
                <th className="p-3">Status</th>
                <th className="p-3">Waktu</th>
                <th className="p-3 pr-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 text-stone-700">
              {defaultAiCases.map((item) => (
                <tr key={item.id} className="hover:bg-stone-50 transition">
                  <td className="p-3 pl-4 font-semibold text-purple-700">
                    {item.platform}
                  </td>
                  <td className="p-3 font-medium max-w-xs truncate">
                    {item.title}
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      Solved by AI
                    </span>
                  </td>
                  <td className="p-3 text-stone-400 text-[11px]">
                    {item.created_at}
                  </td>
                  <td className="p-3 pr-4 text-right">
                    <button
                      onClick={() => setSelectedCase(item)}
                      className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 font-semibold rounded-lg text-[11px] transition inline-flex items-center space-x-1"
                    >
                      <BookOpen className="w-3 h-3" />
                      <span>Detail</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DETAIL MODAL */}
      {selectedCase && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-purple-100 text-purple-800">
                {selectedCase.platform}
              </span>
              <button onClick={() => setSelectedCase(null)} className="text-stone-400 hover:text-stone-700 font-bold">
                ✕
              </button>
            </div>

            <h3 className="font-bold text-sm text-[#141517]">{selectedCase.title}</h3>

            <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 font-mono text-xs text-stone-800 whitespace-pre-wrap leading-relaxed max-h-[300px] overflow-y-auto">
              {selectedCase.solution}
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setSelectedCase(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
