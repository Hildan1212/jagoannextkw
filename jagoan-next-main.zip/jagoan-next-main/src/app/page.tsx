'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Search, Sparkles, Copy, ExternalLink, Check, RefreshCw, Dices } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { defaultAiCases } from '@/lib/constants';

// Initial Popular Tutorials (Exact matches with Laravel Josjis Board)
const POPULAR_TUTORIALS = [
  {
    id: 104,
    title: 'Cara Setting DNS Email Bisnis di cPanel',
    category: 'Email Bisnis',
    category_color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    views_count: 4798,
    url: 'https://www.jagoanhosting.com/tutorial/email/cara-setting-dns-email-bisnis-di-cpanel',
    excerpt: 'Panduan resmi Knowledge Base Jagoan Hosting: Cara Setting DNS Email Bisnis di cPanel. Pelajari alur konfigurasi, instruksi teknis, dan verifikasi di server atau layanan Anda.',
    reading_time: 4,
    slug: 'cara-setting-dns-email-bisnis-di-cpanel',
    tags: ['cpanel', 'email', 'dns', 'mx-record'],
  },
  {
    id: 181,
    title: 'Cara Install SSL pada Laravel di VPS Ubuntu',
    category: 'VPS & Cloud Server',
    category_color: 'bg-purple-50 text-purple-800 border-purple-200',
    views_count: 4606,
    url: 'https://www.jagoanhosting.com/tutorial/laravel/cara-install-ssl-pada-laravel-di-vps-ubuntu',
    excerpt: 'Panduan resmi Knowledge Base Jagoan Hosting: Cara Install SSL pada Laravel di VPS Ubuntu. Pelajari alur konfigurasi, instruksi teknis, dan verifikasi di server atau layanan Anda.',
    reading_time: 5,
    slug: 'cara-install-ssl-pada-laravel-di-vps-ubuntu',
    tags: ['laravel', 'ssl', 'vps', 'certbot'],
  },
  {
    id: 116,
    title: 'Menghubungkan Email Hosting ke Aplikasi Outlook Android',
    category: 'Email Bisnis',
    category_color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    views_count: 4604,
    url: 'https://www.jagoanhosting.com/tutorial/email/menghubungkan-email-hosting-ke-aplikasi-outlook-android',
    excerpt: 'Panduan resmi Knowledge Base Jagoan Hosting: Menghubungkan Email Hosting ke Aplikasi Outlook Android. Pelajari alur konfigurasi, instruksi teknis, dan verifikasi di server atau layanan Anda.',
    reading_time: 4,
    slug: 'menghubungkan-email-hosting-ke-aplikasi-outlook-android',
    tags: ['outlook', 'email', 'android', 'imap'],
  },
  {
    id: 189,
    title: 'Cara Install Laravel di FastPanel',
    category: 'Apps & Framework',
    category_color: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    views_count: 4584,
    url: 'https://www.jagoanhosting.com/tutorial/fastpanel/cara-install-laravel-di-fastpanel',
    excerpt: 'Panduan resmi Knowledge Base Jagoan Hosting: Cara Install Laravel di FastPanel. Pelajari alur konfigurasi, instruksi teknis, dan verifikasi di server atau layanan Anda.',
    reading_time: 5,
    slug: 'cara-install-laravel-di-fastpanel',
    tags: ['laravel', 'fastpanel', 'php', 'composer'],
  },
  {
    id: 24,
    title: 'Cara Membuat Database di Cyberpanel',
    category: 'VPS & Cloud Server',
    category_color: 'bg-purple-50 text-purple-800 border-purple-200',
    views_count: 4477,
    url: 'https://www.jagoanhosting.com/tutorial/cyberpanel/cara-membuat-database-di-cyberpanel',
    excerpt: 'Panduan resmi Knowledge Base Jagoan Hosting: Cara Membuat Database di Cyberpanel. Pelajari alur konfigurasi, instruksi teknis, dan verifikasi di server atau layanan Anda.',
    reading_time: 3,
    slug: 'cara-membuat-database-di-cyberpanel',
    tags: ['cyberpanel', 'database', 'mysql', 'phpmyadmin'],
  },
  {
    id: 66,
    title: 'Cara Merubah Password Akun Email Pada Directadmin',
    category: 'VPS & Cloud Server',
    category_color: 'bg-purple-50 text-purple-800 border-purple-200',
    views_count: 4450,
    url: 'https://www.jagoanhosting.com/tutorial/directadmin/cara-merubah-password-akun-email-pada-directadmin',
    excerpt: 'Panduan resmi Knowledge Base Jagoan Hosting: Cara Merubah Password Akun Email Pada Directadmin. Pelajari alur konfigurasi, instruksi teknis, dan verifikasi di server atau layanan Anda.',
    reading_time: 3,
    slug: 'cara-merubah-password-akun-email-pada-directadmin',
    tags: ['directadmin', 'email', 'password', 'hosting'],
  },
];

// Categories with Counts (Live 1,856 Official Knowledge Base Tutorials)
const CATEGORIES_DATA: Record<string, number> = {
  'Semua': 1856,
  'SSL & Keamanan': 771,
  'VPS & Cloud Server': 445,
  'WordPress & CMS': 373,
  'Email Bisnis': 139,
  'Domain & DNS': 128,
};

export default function HomePage() {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('Semua');
  const [includeAi, setIncludeAi] = useState(true);
  const [results, setResults] = useState<any[]>([]);
  const [totalMatches, setTotalMatches] = useState(0);
  const [resultLimit, setResultLimit] = useState(25);
  const [searchMessage, setSearchMessage] = useState<string | null>(null);
  const [isFuzzy, setIsFuzzy] = useState(false);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [latency, setLatency] = useState(0);
  const [copiedId, setCopiedId] = useState<string | number | null>(null);
  const [activeModalAi, setActiveModalAi] = useState<any | null>(null);
  const [indexingMessage, setIndexingMessage] = useState<string | null>(null);

  // CS External Link Submission Modal State
  const [showAddLinkModal, setShowAddLinkModal] = useState(false);
  const [newLinkTitle, setNewLinkTitle] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('');
  const [newLinkCategory, setNewLinkCategory] = useState('Apps & Framework');
  const [newLinkDesc, setNewLinkDesc] = useState('');
  const [submittingLink, setSubmittingLink] = useState(false);
  const [linkError, setLinkError] = useState<string | null>(null);
  const [deletingLinkId, setDeletingLinkId] = useState<number | null>(null);

  const isSearching = Boolean(query.trim() || category !== 'Semua');

  // Debounced live search when query or category or includeAi changes (reset limit to 25)
  useEffect(() => {
    if (!isSearching) {
      setResults([]);
      setTotalMatches(0);
      setSearchMessage(null);
      setIsFuzzy(false);
      return;
    }

    setResultLimit(25);
    const timer = setTimeout(() => {
      fetchResults(query, category, includeAi, 25);
    }, 200);

    return () => clearTimeout(timer);
  }, [query, category, includeAi, isSearching]);

  async function fetchResults(q: string, cat: string, ai: boolean, limitToFetch: number = 25) {
    setLoading(true);
    const start = performance.now();
    try {
      const roleParam = user?.role || 'agent';
      const url = `/api/search?q=${encodeURIComponent(q)}&category=${encodeURIComponent(cat)}&include_ai=${ai ? '1' : '0'}&limit=${limitToFetch}&role=${encodeURIComponent(roleParam)}`;
      const res = await fetch(url);
      const data = await res.json();
      setResults(data.results || []);
      setTotalMatches(data.total_matches ?? (data.results || []).length);
      setSearchMessage(data.message || null);
      setIsFuzzy(Boolean(data.is_fuzzy));
      setLatency(Math.round(performance.now() - start));
    } catch (e) {
      console.error('Fetch error:', e);
    } finally {
      setLoading(false);
    }
  }

  function handleLoadMore() {
    const nextLimit = resultLimit + 25;
    setResultLimit(nextLimit);
    fetchResults(query, category, includeAi, nextLimit);
  }

  async function handleSubmitLink(e?: React.FormEvent) {
    if (e) e.preventDefault();
    if (!newLinkTitle.trim()) {
      setLinkError('Judul panduan / solusi wajib diisi.');
      return;
    }
    if (!newLinkUrl.trim() || !newLinkUrl.startsWith('http')) {
      setLinkError('Link URL wajib diawali http:// atau https://');
      return;
    }

    setSubmittingLink(true);
    setLinkError(null);
    try {
      const res = await fetch('/api/cs-links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newLinkTitle.trim(),
          url: newLinkUrl.trim(),
          category: newLinkCategory,
          description: newLinkDesc.trim(),
          username: user?.username || 'cs',
          name: user?.name || 'Rekan CS',
        }),
      });
      const data = await res.json();
      if (data.success) {
        setNewLinkTitle('');
        setNewLinkUrl('');
        setNewLinkDesc('');
        setShowAddLinkModal(false);
        setIndexingMessage('⚡ Panduan berhasil disimpan! Ditampilkan di pencarian dengan tag (by CS).');
        setTimeout(() => setIndexingMessage(null), 6000);
        // re-fetch search
        if (isSearching) {
          fetchResults(query, category, includeAi, resultLimit);
        }
      } else {
        setLinkError(data.error || 'Gagal menyimpan link panduan.');
      }
    } catch (err: any) {
      setLinkError(err.message || 'Gagal menghubungi server');
    } finally {
      setSubmittingLink(false);
    }
  }

  async function handleDeleteCsLink(id: number, title: string) {
    if (!confirm(`Hapus link "${title}" dari database?`)) return;
    setDeletingLinkId(id);
    try {
      const res = await fetch(`/api/cs-links?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setResults((prev) => prev.filter((r) => r.id !== id || r.type !== 'cs_link'));
        setIndexingMessage('✓ Link solusi berhasil dihapus.');
        setTimeout(() => setIndexingMessage(null), 4000);
      } else {
        alert(data.error || 'Gagal menghapus link');
      }
    } catch (e) {
      alert('Gagal menghubungi server');
    } finally {
      setDeletingLinkId(null);
    }
  }

  function trackTutorialView(tut: any) {
    if (!tut) return;
    try {
      fetch('/api/analytics/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tutorial_id: tut.id,
          tutorial_title: tut.title,
          tutorial_url: tut.url,
          username: user?.name || user?.username || 'agent',
          user_role: user?.role || 'agent',
          source: 'web',
        }),
      }).catch(() => {});
    } catch (e) {
      // ignore
    }
  }

  function handleCopy(text: string, id: string | number) {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  }

  function handleFeelingLucky() {
    const pool = isSearching && results.length > 0 ? results : POPULAR_TUTORIALS;
    const randomItem = pool[Math.floor(Math.random() * pool.length)];
    if (randomItem.type === 'ai_case') {
      setActiveModalAi(randomItem);
    } else if (randomItem.url) {
      window.open(randomItem.url, '_blank');
    }
  }

  async function handleSyncSitemap() {
    if (syncing) return;
    setSyncing(true);
    setIndexingMessage('⏳ Menghubungi API resmi Jagoan Hosting untuk memeriksa tutorial terbaru...');
    try {
      const res = await fetch('/api/tutorials/sync', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        if (data.inserted > 0) {
          setIndexingMessage(`⚡ Berhasil sinkronisasi! Ditemukan ${data.inserted} tutorial baru. Total artikel sekarang: ${data.total_in_db}. Artikel terbaru: "${data.newest_title}"`);
        } else {
          setIndexingMessage(`⚡ Database mutakhir! Semua ${data.total_in_db || 1856} tutorial resmi Jagoan Hosting sudah tersinkronisasi. Artikel terbaru: "${data.newest_title}" (${data.newest_date ? new Date(data.newest_date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) : ''})`);
        }
      } else {
        setIndexingMessage(`⚠️ Sinkronisasi selesai: ${data.message || 'Data indeks aman'}`);
      }
    } catch (err) {
      setIndexingMessage('⚠️ Gagal menghubungi server sinkronisasi, menggunakan cache lokal.');
    } finally {
      setSyncing(false);
      setTimeout(() => setIndexingMessage(null), 8000);
    }
  }

  const aiResultsCount = results.filter((r) => r.type === 'ai_case').length;
  const tutResultsCount = results.filter((r) => r.type !== 'ai_case').length;

  return (
    <div className="space-y-8">
      
      {/* Feedback Notifikasi Indexing */}
      {indexingMessage && (
        <div className="editorial-card rounded-2xl p-4 bg-emerald-50 border-emerald-200 text-emerald-900 flex items-center justify-between shadow-xs transition">
          <div className="flex items-center space-x-2 text-xs font-medium">
            <svg className="w-4 h-4 text-emerald-600 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
            <span>{indexingMessage}</span>
          </div>
          <button onClick={() => setIndexingMessage(null)} className="text-xs text-emerald-700 hover:text-emerald-900 font-bold px-2">
            ✕
          </button>
        </div>
      )}

      {/* HERO SEARCH SECTION (Google-Style Centerpiece) */}
      <div className="text-center pt-4 pb-2 space-y-6">
        
        {/* Logo JagoanSearch */}
        <div
          className="inline-flex flex-col items-center group cursor-pointer"
          onClick={() => {
            setQuery('');
            setCategory('Semua');
          }}
        >
          <div className="flex items-center space-x-2">
            <span className="font-display font-extrabold text-4xl sm:text-5xl tracking-tight text-[#141517]">
              Jagoan<span className="text-blue-600">S</span><span className="text-rose-600">e</span><span className="text-amber-500">a</span><span className="text-blue-600">r</span><span className="text-emerald-600">c</span><span className="text-rose-600">h</span>
            </span>
            <span className="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-blue-200">
              Jagoan Hosting
            </span>
          </div>

          <div className="flex items-center justify-center flex-wrap gap-2 mt-1">
            <p className="text-xs text-[#71737B] font-medium">
              Mesin Pencari Panduan, Error Fix, dan Tutorial Resmi Jagoan Hosting
            </p>
            <span
              className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-stone-100 text-stone-600 border border-stone-200"
              title="Tersedia ekstensi browser Chrome/Edge! Tekan Alt+J di halaman web mana pun untuk pencarian instan"
            >
              <span>⚡ Ekstensi:</span>
              <kbd className="px-1.5 py-0.5 bg-white rounded border border-stone-300 font-mono text-[9px] shadow-2xs font-bold text-stone-800">
                Alt+J
              </kbd>
            </span>
          </div>
        </div>

        {/* Google-style Search Bar Container */}
        <div className="max-w-2xl mx-auto px-2">
          <div className="relative flex items-center bg-white rounded-full border-2 border-[#E3E3DC] hover:border-stone-400 focus-within:border-blue-600 focus-within:ring-4 focus-within:ring-blue-100 transition shadow-sm">
            
            {/* Search Icon */}
            <div className="pl-4 text-[#71737B]">
              <Search className="w-5 h-5" />
            </div>

            {/* Search Input */}
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ketik kendala atau tutorial... (misal: 'php version', 'fatal error', 'aapanel', 'nameserver')"
              className="w-full py-3.5 px-3 text-sm text-[#141517] bg-transparent outline-none placeholder-[#8C8E96]"
              autoFocus
            />

            {/* Loading Spinner */}
            {loading && (
              <div className="pr-3 text-blue-600">
                <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            )}

            {/* Clear Button */}
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                title="Hapus pencarian"
                className="pr-4 text-[#8C8E96] hover:text-[#141517] transition text-sm font-semibold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Action Buttons (Google-style) */}
          <div className="flex items-center justify-center flex-wrap gap-2 pt-4">
            
            {/* TOGGLE INCLUDE AI */}
            <button
              type="button"
              onClick={() => setIncludeAi(!includeAi)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition border flex items-center space-x-2.5 shadow-2xs ${
                includeAi
                  ? 'bg-purple-50 border-purple-300 text-purple-900 ring-2 ring-purple-100'
                  : 'bg-stone-50 border-[#E3E3DC] text-stone-500 hover:text-stone-800 hover:bg-stone-100'
              }`}
              title="Sertakan studi kasus yang diselesaikan oleh asisten AI di Board Kasus ke dalam hasil pencarian"
            >
              <span className={`w-8 h-4.5 rounded-full transition-colors relative inline-flex items-center p-0.5 ${includeAi ? 'bg-purple-600' : 'bg-stone-300'}`}>
                <span className={`w-3.5 h-3.5 rounded-full bg-white transition-transform shadow-xs ${includeAi ? 'translate-x-3.5' : 'translate-x-0'}`}></span>
              </span>
              <span className="flex items-center space-x-1.5">
                <span>🤖 Include AI</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${includeAi ? 'bg-purple-200 text-purple-800' : 'bg-stone-200 text-stone-600'}`}>
                  +4 case
                </span>
              </span>
            </button>

            {/* Cari di Jagoan Hosting Link */}
            <a
              href={`https://www.jagoanhosting.com/tutorial/?s=${encodeURIComponent(query)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 border border-[#E3E3DC] rounded-xl text-xs font-semibold text-[#141517] transition shadow-2xs flex items-center space-x-1.5"
              title="Cari kata kunci ini langsung di situs resmi Jagoan Hosting"
            >
              <span>🔍</span>
              <span>Cari di Jagoan Hosting</span>
              <span className="text-stone-400 text-[10px]">↗</span>
            </a>

            {/* Saya Lagi Beruntung Button */}
            <button
              type="button"
              onClick={handleFeelingLucky}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 border border-[#E3E3DC] rounded-xl text-xs font-semibold text-[#141517] transition shadow-2xs flex items-center space-x-1.5"
            >
              <span>🎲</span>
              <span>Saya Lagi Beruntung</span>
            </button>

            {/* Sinkronkan Tutorial Button */}
            <button
              type="button"
              onClick={handleSyncSitemap}
              disabled={syncing}
              title="Tarik dan sinkronkan artikel baru langsung dari WordPress REST API resmi Jagoan Hosting"
              className="px-4 py-2 bg-stone-50 hover:bg-stone-100 border border-stone-200 hover:border-stone-300 rounded-xl text-xs font-medium text-stone-700 transition flex items-center space-x-1.5 disabled:opacity-50"
            >
              {syncing ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-stone-600 border-t-transparent rounded-full animate-spin"></div>
                  <span>Menyinkronkan...</span>
                </>
              ) : (
                <>
                  <span>⚡</span>
                  <span>Sinkronkan Tutorial</span>
                </>
              )}
            </button>

            {/* Tambah Link Panduan CS (by CS) Button */}
            <button
              type="button"
              onClick={() => {
                setShowAddLinkModal(true);
                setLinkError(null);
              }}
              title="Bagikan tutorial luar atau dokumentasi how-to yang berguna untuk tim CS (dilengkapi label (by CS))"
              className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-xl text-xs font-bold text-emerald-900 transition shadow-2xs flex items-center space-x-1.5"
            >
              <span>🔗</span>
              <span>+ Bagikan Solusi / Link</span>
              <span className="text-[10px] bg-emerald-200 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold">by CS</span>
            </button>
          </div>
        </div>

        {/* Quick Category / Platform Filter Chips */}
        <div className="max-w-4xl mx-auto px-2 pt-3">
          <div className="flex items-center justify-center flex-wrap gap-1.5 text-xs">
            {Object.entries(CATEGORIES_DATA).map(([catName, count]) => {
              const isActive = category === catName;
              return (
                <button
                  key={catName}
                  type="button"
                  onClick={() => setCategory(catName)}
                  className={`px-3 py-1.5 rounded-full font-medium transition flex items-center space-x-1.5 ${
                    isActive
                      ? 'bg-[#141517] text-white shadow-xs font-semibold'
                      : 'bg-white text-stone-700 border border-[#E3E3DC] hover:border-stone-400 hover:bg-stone-50'
                  }`}
                >
                  <span>{catName}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                      isActive ? 'bg-stone-700 text-stone-200' : 'bg-stone-100 text-[#71737B]'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

      </div>

      {/* STATS BAR (When searching) */}
      {isSearching && (
        <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-3 text-xs text-[#71737B]">
          <div className="flex items-center space-x-2 flex-wrap gap-y-1">
            <span>
              Menemukan <span className="font-bold text-[#141517]">{totalMatches || results.length}</span> hasil resmi{' '}
              {results.length < totalMatches && (
                <span className="text-blue-700 font-semibold">(menampilkan {results.length} pertama) </span>
              )}
              {includeAi && aiResultsCount > 0 && tutResultsCount > 0 && (
                <span>
                  (<span className="font-semibold text-blue-700">{tutResultsCount} tutorial</span> +{' '}
                  <span className="font-semibold text-purple-700">{aiResultsCount} kasus Solved by AI</span>)
                </span>
              )}
              {includeAi && aiResultsCount > 0 && tutResultsCount === 0 && (
                <span className="font-semibold text-purple-700">({aiResultsCount} kasus Solved by AI)</span>
              )}
              {query && (
                <span>
                  untuk kata kunci &quot;<span className="font-bold text-[#141517]">{query}</span>&quot;
                </span>
              )}
              {category !== 'Semua' && (
                <span>
                  dalam kategori <span className="font-semibold text-blue-700">{category}</span>
                </span>
              )}
              <span className="text-stone-400 font-mono ml-1">({latency} ms)</span>
            </span>
          </div>

          <div className="flex items-center space-x-3 text-[11px] shrink-0">
            <button
              type="button"
              onClick={() => setIncludeAi(!includeAi)}
              className={`font-semibold flex items-center space-x-1.5 transition ${
                includeAi ? 'text-purple-700 hover:text-purple-900' : 'text-stone-500 hover:text-stone-700'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${includeAi ? 'bg-purple-600' : 'bg-stone-300'}`}></span>
              <span>{includeAi ? 'Include AI: Aktif' : 'Include AI: Nonaktif'}</span>
            </button>
            <span className="text-stone-400 hidden sm:inline">&bull; ⚡ Sub-milidetik</span>
          </div>
        </div>
      )}

      {/* RESULTS STREAM OR DEFAULT POPULAR GUIDES */}
      <div className="space-y-4">
        {isSearching ? (
          /* SEARCH RESULTS LIST */
          results.length === 0 && !loading ? (
            <div className="editorial-card rounded-2xl p-10 text-center space-y-4">
              <div className="w-12 h-12 mx-auto rounded-full bg-stone-100 flex items-center justify-center text-xl">
                🔍
              </div>
              <div className="space-y-1">
                <h3 className="font-display font-bold text-base text-[#141517]">
                  Belum Menemukan Hasil yang Cocok
                </h3>
                <p className="text-xs text-[#71737B] max-w-md mx-auto">
                  Tidak ditemukan tutorial resmi maupun kasus Solved by AI untuk kata kunci &quot;
                  <span className="font-semibold text-stone-900">{query}</span>&quot;.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-center flex-wrap gap-2">
                <a
                  href={`https://www.jagoanhosting.com/tutorial/?s=${encodeURIComponent(query)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-xs font-semibold rounded-xl text-[#141517] transition border border-[#E3E3DC] flex items-center space-x-1"
                >
                  <span>Buka di Web Jagoan Hosting</span>
                  <span className="text-stone-400">↗</span>
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setQuery('');
                    setCategory('Semua');
                  }}
                  className="px-4 py-2 bg-white hover:bg-stone-50 text-xs font-medium rounded-xl text-stone-700 transition border border-[#E3E3DC]"
                >
                  Reset Pencarian
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {searchMessage && (
                <div className="editorial-card rounded-2xl p-4 bg-amber-50/90 border border-amber-200 text-amber-950 flex items-start space-x-3 text-xs font-medium animate-in fade-in">
                  <span className="text-amber-600 text-base leading-none">🔍</span>
                  <div className="space-y-0.5">
                    <p className="font-semibold text-amber-950">{searchMessage}</p>
                    <p className="text-[11px] text-amber-800/80">Sistem otomatis mencocokkan artikel dengan toleransi typo dan kemiripan karakter teknis.</p>
                  </div>
                </div>
              )}
              {results.map((item) => {
                if (item.type === 'cs_link') {
                  const isAdmin = user?.role === 'admin';
                  return (
                    <div
                      key={`cslink-${item.id}`}
                      className="editorial-card rounded-2xl p-5 hover:border-emerald-400 transition space-y-2.5 group border-l-4 border-l-emerald-500 bg-white"
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                          <span className="px-2 py-0.5 rounded-md font-bold text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center space-x-1 shadow-2xs">
                            <span>⚡</span>
                            <span>(by CS)</span>
                          </span>
                          <span className="font-semibold text-emerald-800 text-[11px]">Panduan &amp; Link How-To Rekan CS</span>
                          <span className="text-stone-300">&bull;</span>
                          <span className="text-stone-400 font-mono text-[10px]">{item.created_at || 'Baru saja'}</span>

                          {/* Jika Admin: Tampilkan siapa pembuat aslinya secara transparan */}
                          {isAdmin && item.created_by_name && (
                            <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-800 text-[10px] font-mono border border-rose-200" title="Informasi identitas hanya terlihat oleh Super Admin">
                              👑 Dibuat oleh: {item.created_by_name} (@{item.created_by_username || 'cs'})
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md border shrink-0 bg-emerald-50 text-emerald-800 border-emerald-200">
                          {item.category || 'Rekomendasi CS'}
                        </span>
                      </div>

                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group/title block"
                      >
                        <h2 className="text-base font-bold text-emerald-800 group-hover:text-emerald-950 group-hover:underline transition flex items-center space-x-1.5">
                          <span>{item.title}</span>
                          <span className="text-xs text-emerald-500 group-hover:text-emerald-700 font-normal no-underline">
                            ↗
                          </span>
                        </h2>
                      </a>

                      {item.excerpt && (
                        <p className="text-xs text-stone-600 leading-relaxed font-sans">{item.excerpt}</p>
                      )}

                      <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-[#EDEDE8]">
                        <div className="flex items-center space-x-1 text-stone-500 font-mono text-[11px] truncate max-w-sm">
                          <span>🌐 Link:</span>
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-emerald-700 hover:underline truncate"
                          >
                            {item.url}
                          </a>
                        </div>
                        <div className="flex items-center space-x-2">
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold rounded-xl transition shadow-2xs flex items-center space-x-1"
                          >
                            <span>Buka Panduan Luar</span>
                            <span className="text-xs">↗</span>
                          </a>
                          <button
                            type="button"
                            onClick={() => handleCopy(item.url, `copy-cslink-${item.id}`)}
                            className="p-1 px-2.5 text-[11px] text-stone-600 hover:text-stone-900 rounded-xl hover:bg-stone-100 border border-transparent hover:border-stone-200 transition"
                          >
                            {copiedId === `copy-cslink-${item.id}` ? (
                              <span className="text-emerald-600 font-bold">✓ Tersalin!</span>
                            ) : (
                              <span>🔗 Salin Link</span>
                            )}
                          </button>
                          {/* Hapus button for Admin */}
                          {isAdmin && (
                            <button
                              type="button"
                              onClick={() => handleDeleteCsLink(item.id, item.title)}
                              disabled={deletingLinkId === item.id}
                              className="px-2.5 py-1 text-[11px] font-semibold text-rose-700 hover:bg-rose-50 rounded-xl border border-rose-200 transition disabled:opacity-50"
                              title="Hapus link ini (Privilege Admin)"
                            >
                              {deletingLinkId === item.id ? 'Menghapus...' : '🗑️ Hapus'}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                }

                const isAi = item.type === 'ai_case';
                if (isAi) {
                  return (
                    <div
                      key={`ai-${item.id}`}
                      className="editorial-card rounded-2xl p-5 hover:border-purple-300 transition space-y-2.5 group border-l-4 border-l-purple-500"
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <div className="flex items-center space-x-2">
                          <span className="px-2 py-0.5 rounded-md font-bold text-[10px] bg-purple-100 text-purple-800 border border-purple-200 flex items-center space-x-1">
                            <span>🤖</span>
                            <span>Solved by AI</span>
                          </span>
                          <span className="font-semibold text-stone-500 font-mono">Board Kasus</span>
                          <span className="text-stone-300">&bull;</span>
                          <span className="text-stone-400 font-mono text-[10px]">
                            {item.created_at || 'Baru saja'}
                          </span>
                        </div>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md border shrink-0 bg-purple-50 text-purple-800 border-purple-200">
                          {item.platform || 'Kasus Teknis'}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => setActiveModalAi(item)}
                        className="text-left group/title block w-full"
                      >
                        <h2 className="text-base font-bold text-purple-950 group-hover/title:text-purple-700 transition flex items-center space-x-1.5">
                          <span>{item.title}</span>
                          <span className="text-xs text-purple-400 group-hover/title:text-purple-600 font-normal">🔍</span>
                        </h2>
                      </button>

                      {item.solution && (
                        <div className="bg-purple-50/40 rounded-xl p-3 border border-purple-100 text-xs text-stone-700 font-mono leading-relaxed line-clamp-3">
                          {item.solution}
                        </div>
                      )}

                      <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-[#EDEDE8]">
                        <div className="text-[11px] text-stone-500">
                          {item.error_log && (
                            <span className="text-[10px] px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 font-mono">
                              ⚠️ Log Error Tersedia
                            </span>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            type="button"
                            onClick={() => setActiveModalAi(item)}
                            className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-[11px] font-semibold rounded-xl transition shadow-2xs flex items-center space-x-1"
                          >
                            <span>📖 Buka Solusi AI</span>
                          </button>
                          <Link
                            href="/board"
                            className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-[#141517] text-[11px] font-semibold rounded-xl transition border border-[#E3E3DC] flex items-center space-x-1"
                          >
                            <span>Buka di Board</span>
                            <span className="text-xs text-stone-400">↗</span>
                          </Link>
                          {item.solution && (
                            <button
                              type="button"
                              onClick={() => handleCopy(item.solution, `copy-ai-${item.id}`)}
                              className="p-1 px-2.5 text-[11px] text-stone-600 hover:text-stone-900 rounded-xl hover:bg-stone-100 border border-transparent hover:border-stone-200 transition"
                            >
                              {copiedId === `copy-ai-${item.id}` ? (
                                <span className="text-emerald-600 font-bold">✓ Tersalin!</span>
                              ) : (
                                <span>📋 Salin</span>
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={`tut-${item.id}`}
                    className="editorial-card rounded-2xl p-5 hover:border-stone-400 transition space-y-2 group"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => trackTutorialView(item)}
                        className="flex items-center space-x-1.5 text-stone-500 font-mono truncate max-w-xl hover:text-emerald-700 transition"
                      >
                        <span className="text-emerald-700 font-semibold">jagoanhosting.com</span>
                        <span>›</span>
                        <span>tutorial</span>
                        <span>›</span>
                        <span className="text-stone-600 truncate hover:underline">{item.slug || 'panduan'}</span>
                        <span className="text-[10px] text-stone-400">↗</span>
                      </a>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border shrink-0 ${
                          item.category_color || 'bg-blue-50 text-blue-800 border-blue-200'
                        }`}
                      >
                        {item.category || 'Tutorial'}
                      </span>
                    </div>

                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => trackTutorialView(item)}
                      className="group/title block"
                    >
                      <h2 className="text-base font-bold text-blue-700 group-hover/title:text-blue-900 group-hover/title:underline transition flex items-center space-x-1.5">
                        <span>{item.title}</span>
                        <span className="text-xs text-blue-400 group-hover/title:text-blue-600 font-normal no-underline">
                          ↗
                        </span>
                      </h2>
                    </a>

                    <p className="text-xs text-stone-600 leading-relaxed">{item.excerpt}</p>

                    <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-[#EDEDE8]">
                      <div className="flex items-center space-x-1">
                        <span className="text-[10px] text-stone-400 font-mono">
                          ⏱ {item.reading_time || 4} mnt baca
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => trackTutorialView(item)}
                          className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold rounded-xl transition shadow-2xs flex items-center space-x-1"
                        >
                          <span>Buka Tutorial Asli</span>
                          <span className="text-xs">↗</span>
                        </a>
                        <button
                          type="button"
                          onClick={() => handleCopy(item.url, `copy-tut-${item.id}`)}
                          className="p-1 px-2.5 text-[11px] text-stone-600 hover:text-stone-900 rounded-xl hover:bg-stone-100 border border-transparent hover:border-stone-200 transition"
                        >
                          {copiedId === `copy-tut-${item.id}` ? (
                            <span className="text-emerald-600 font-bold">✓ Tersalin!</span>
                          ) : (
                            <span>🔗 Salin Link</span>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Load More Button */}
              {results.length < totalMatches && (
                <div className="pt-4 pb-2 text-center">
                  <button
                    type="button"
                    onClick={handleLoadMore}
                    disabled={loading}
                    className="px-6 py-3 bg-white hover:bg-stone-50 border-2 border-stone-300 hover:border-stone-400 text-stone-800 rounded-2xl text-xs font-bold transition shadow-sm inline-flex items-center space-x-2.5 disabled:opacity-50"
                  >
                    {loading ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-stone-600 border-t-transparent rounded-full animate-spin"></div>
                        <span>Memuat panduan berikutnya...</span>
                      </>
                    ) : (
                      <>
                        <span>Muat 25 Panduan Tambahan</span>
                        <span className="bg-stone-100 text-stone-700 px-2 py-0.5 rounded-full text-[10px] font-bold border border-stone-200">
                          Tersisa {totalMatches - results.length} lagi
                        </span>
                        <span>➔</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          )
        ) : (
          /* DEFAULT STATE: EXACT MATCHING JOSJIS BOARD SCREENSHOT */
          <div className="space-y-8 pt-2">
            
            {/* SECTION 1: TUTORIAL RESMI JAGOAN HOSTING (Populer & Paling Sering Dicari) */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-3">
                <div className="flex items-center space-x-2">
                  <span className="text-base font-bold text-[#141517]">🔥 Tutorial Populer &amp; Paling Sering Dicari</span>
                  <span className="text-[10px] bg-rose-50 text-rose-700 font-semibold px-2 py-0.5 rounded-full border border-rose-200">
                    Rekomendasi Utama
                  </span>
                </div>
                <span className="text-xs text-stone-500 hidden sm:inline">
                  Klik langsung untuk membuka tutorial resmi
                </span>
              </div>

              {/* Grid 2-Kolom Kartu Populer Tutorial */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {POPULAR_TUTORIALS.map((item) => (
                  <div
                    key={item.id}
                    className="editorial-card rounded-2xl p-5 hover:border-stone-400 transition space-y-3 group flex flex-col justify-between"
                  >
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="space-y-2 block"
                      title="Buka artikel resmi di tab baru"
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${item.category_color}`}>
                          {item.category}
                        </span>
                        <span className="text-[10px] text-stone-400 font-mono">
                          👁 {item.views_count.toLocaleString('id-ID')} views
                        </span>
                      </div>

                      <h3 className="font-bold text-sm text-[#141517] group-hover:text-blue-700 transition leading-snug flex items-center justify-between">
                        <span>{item.title}</span>
                        <span className="text-xs text-blue-400 group-hover:text-blue-600 shrink-0 ml-1">↗</span>
                      </h3>

                      <p className="text-xs text-[#52545A] line-clamp-2 leading-relaxed">
                        {item.excerpt}
                      </p>
                    </a>

                    <div className="pt-2 border-t border-[#EDEDE8] flex items-center justify-between text-[11px]">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1"
                      >
                        <span>Buka Tutorial Asli</span>
                        <span className="text-xs">↗</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => handleCopy(item.url, item.id)}
                        className="p-1 px-2.5 text-[11px] text-stone-600 hover:text-stone-900 rounded-xl hover:bg-stone-100 border border-transparent hover:border-stone-200 transition"
                      >
                        {copiedId === item.id ? (
                          <span className="text-emerald-600 font-bold">✓ Tersalin!</span>
                        ) : (
                          <span>🔗 Salin Link</span>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* SECTION 2: LIVE FEED KASUS SOLVED BY AI DARI BOARD */}
            {includeAi && (
              <div className="space-y-4 pt-4">
                <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-base font-bold text-[#141517]">🤖 Kasus Solved by AI Terbaru di Board</span>
                    <span className="text-[10px] bg-purple-50 text-purple-700 font-semibold px-2 py-0.5 rounded-full border border-purple-200">
                      Live Feed dari Board CS
                    </span>
                  </div>
                  <Link
                    href="/board"
                    className="text-xs text-purple-700 hover:text-purple-900 font-semibold flex items-center space-x-1"
                  >
                    <span>Buka Board Kasus</span>
                    <span>➔</span>
                  </Link>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {defaultAiCases.map((aiCase) => (
                    <div
                      key={aiCase.id}
                      className="editorial-card rounded-2xl p-5 hover:border-purple-300 transition space-y-3 group border-l-4 border-l-purple-500 flex flex-col justify-between"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="px-2 py-0.5 rounded-md font-bold text-[10px] bg-purple-100 text-purple-800 border border-purple-200 flex items-center space-x-1">
                            <span>🤖</span>
                            <span>Solved by AI</span>
                          </span>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md border shrink-0 bg-purple-50 text-purple-800 border-purple-200">
                            {aiCase.platform}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => setActiveModalAi(aiCase)}
                          className="text-left group/title block w-full"
                        >
                          <h3 className="font-bold text-sm text-purple-950 group-hover/title:text-purple-700 transition leading-snug flex items-center justify-between">
                            <span>{aiCase.title}</span>
                            <span className="text-xs text-purple-400 group-hover/title:text-purple-600 shrink-0 ml-1">🔍</span>
                          </h3>
                        </button>

                        <div className="bg-purple-50/40 rounded-xl p-3 border border-purple-100 text-xs text-stone-700 font-mono leading-relaxed line-clamp-3">
                          {aiCase.solution}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-[#EDEDE8] flex items-center justify-between text-[11px]">
                        <button
                          type="button"
                          onClick={() => setActiveModalAi(aiCase)}
                          className="text-purple-700 hover:text-purple-900 font-semibold flex items-center space-x-1"
                        >
                          <span>Buka Solusi Lengkap</span>
                          <span className="text-xs">↗</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCopy(aiCase.solution, `copy-ai-card-${aiCase.id}`)}
                          className="p-1 px-2.5 text-[11px] text-stone-600 hover:text-stone-900 rounded-xl hover:bg-stone-100 border border-transparent hover:border-stone-200 transition"
                        >
                          {copiedId === `copy-ai-card-${aiCase.id}` ? (
                            <span className="text-emerald-600 font-bold">✓ Tersalin!</span>
                          ) : (
                            <span>📋 Salin Solusi</span>
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}
      </div>

      {/* MODAL DETAIL KASUS AI */}
      {activeModalAi && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setActiveModalAi(null)}
          />

          <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
            <div
              className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-2xl border border-stone-200"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="p-5 sm:p-6 border-b border-stone-100 flex items-start justify-between bg-purple-50/40">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded-md font-bold text-[10px] bg-purple-100 text-purple-800 border border-purple-200 flex items-center space-x-1">
                      <span>🤖</span>
                      <span>Studi Kasus Solved by AI</span>
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md border bg-white border-purple-200 text-purple-800">
                      {activeModalAi.platform}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-stone-900 leading-tight pt-1">
                    {activeModalAi.title}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveModalAi(null)}
                  className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
                >
                  ✕
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-5 sm:p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                {activeModalAi.error_log && (
                  <div className="space-y-1.5">
                    <span className="micro-label block text-rose-700 font-bold">⚠️ Pesan Error Log:</span>
                    <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 font-mono text-xs text-rose-900">
                      {activeModalAi.error_log}
                    </div>
                  </div>
                )}

                <div className="space-y-1.5">
                  <span className="micro-label block text-purple-900 font-bold">🛠️ Rekomendasi Solusi Teknis:</span>
                  <div className="p-4 rounded-xl bg-purple-50/50 border border-purple-100 font-mono text-xs text-stone-800 leading-relaxed whitespace-pre-wrap">
                    {activeModalAi.solution}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-4 sm:px-6 border-t border-stone-100 bg-stone-50 flex items-center justify-between">
                <Link
                  href="/board"
                  className="text-xs font-semibold text-purple-700 hover:text-purple-900 flex items-center space-x-1"
                >
                  <span>Buka di Board Kasus</span>
                  <span>➔</span>
                </Link>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => handleCopy(activeModalAi.solution, 'modal-ai-solution')}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 shadow-sm transition"
                  >
                    {copiedId === 'modal-ai-solution' ? '✓ Tersalin!' : '📋 Salin Solusi Lengkap'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveModalAi(null)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-700 bg-white border border-stone-300 hover:bg-stone-100 transition"
                  >
                    Tutup
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL TAMBAH LINK SOLUSI / HOW-TO (by CS) */}
      {showAddLinkModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={() => setShowAddLinkModal(false)} />
          <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
            <div
              className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-lg border border-stone-200 p-6 space-y-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-sm font-bold">
                    🔗
                  </div>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <h3 className="font-display font-bold text-sm text-[#141517]">Bagikan Solusi / Link How-To</h3>
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                        (by CS)
                      </span>
                    </div>
                    <p className="text-[11px] text-[#71737B]">Identitas pengirim dirahasiakan dari rekan CS lain.</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddLinkModal(false)}
                  className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition text-sm font-bold"
                >
                  ✕
                </button>
              </div>

              {linkError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-medium">
                  {linkError}
                </div>
              )}

              <form onSubmit={handleSubmitLink} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Judul Kasus / Solusi <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={newLinkTitle}
                    onChange={(e) => setNewLinkTitle(e.target.value)}
                    placeholder="misal: Cara Deploy React JS di Hosting cPanel"
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400"
                    required
                    autoFocus
                  />
                  <p className="text-[10px] text-stone-500 mt-0.5">Judul ini akan dicocokkan saat rekan CS lain mencari di mesin pencari.</p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Link Artikel / How-To (URL Luar) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="url"
                    value={newLinkUrl}
                    onChange={(e) => setNewLinkUrl(e.target.value)}
                    placeholder="https://... (link tutorial resmi, docs React, atau blog solusi)"
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400 font-mono"
                    required
                  />
                  <p className="text-[10px] text-stone-500 mt-0.5">Ketika card diklik, user langsung diarahkan (membuka tab baru) ke link ini.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Kategori Panduan</label>
                    <select
                      value={newLinkCategory}
                      onChange={(e) => setNewLinkCategory(e.target.value)}
                      className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400"
                    >
                      <option value="Apps & Framework">Apps &amp; Framework (React, Node, Laravel)</option>
                      <option value="Hosting & cPanel">Hosting &amp; cPanel</option>
                      <option value="VPS & Cloud Server">VPS &amp; Cloud Server</option>
                      <option value="WordPress & CMS">WordPress &amp; CMS</option>
                      <option value="Email Bisnis">Email Bisnis</option>
                      <option value="SSL & Keamanan">SSL &amp; Keamanan</option>
                      <option value="Domain & DNS">Domain &amp; DNS</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Pengirim (Otomatis)</label>
                    <input
                      type="text"
                      disabled
                      value={`${user?.name || 'Rekan CS'} (Tersimpan aman untuk Admin)`}
                      className="w-full bg-stone-100 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-stone-500 cursor-not-allowed font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Catatan Teknis / Ringkasan Cara (Opsional)</label>
                  <textarea
                    rows={2}
                    value={newLinkDesc}
                    onChange={(e) => setNewLinkDesc(e.target.value)}
                    placeholder="Contoh: Langkah build npm run build, upload folder dist ke public_html cPanel, tambah file .htaccess."
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-2.5 text-xs text-[#141517] outline-none focus:border-stone-400"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end space-x-2 border-t border-stone-100">
                  <button
                    type="button"
                    onClick={() => setShowAddLinkModal(false)}
                    className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-medium transition"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={submittingLink}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-xs disabled:opacity-50 flex items-center space-x-1.5"
                  >
                    {submittingLink ? (
                      <span>Menyimpan...</span>
                    ) : (
                      <>
                        <span>🚀</span>
                        <span>Simpan Solusi (by CS)</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
