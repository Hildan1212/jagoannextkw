import type { Metadata } from 'next';
import Navbar from '@/components/Navbar';
import ExtensionDownloadModal from '@/components/ExtensionDownloadModal';
import Gatekeeper from '@/components/Gatekeeper';
import { AuthProvider } from '@/context/AuthContext';
import './globals.css';

export const metadata: Metadata = {
  title: 'Jagoan Search — Portal Solusi & Mesin Pencari Tutorial Jagoan Hosting',
  description: 'Pusat pencarian tutorial, panduan error fix, dan alur investigasi troubleshooting resmi Jagoan Hosting.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="h-full bg-[#F6F6F2] text-[#141517] antialiased">
      <head>
        <link rel="icon" type="image/x-icon" href="/favicon.ico" />
        <link rel="icon" type="image/png" sizes="32x32" href="/icon.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon.png" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-[#F6F6F2] text-[#141517] flex flex-col font-sans selection:bg-[#18181B] selection:text-white">
        <AuthProvider>
          {/* TOP NAVIGATION BAR */}
          <Navbar />

          {/* MAIN VIEWPORT PROTECTED BY GATEKEEPER */}
          <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Gatekeeper>{children}</Gatekeeper>
          </main>

          {/* CLEAN MINIMAL EDITORIAL FOOTER */}
          <footer className="border-t border-[#E3E3DC] bg-white py-5 text-xs text-[#71737B]">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
              <p>© 2026 Jagoan Search &bull; Portal Pencarian Tutorial &amp; Dokumentasi Jagoan Hosting</p>
              <div className="flex items-center space-x-3">
                <p className="text-[11px] text-[#A1A1A9]">Sistem Operasional &amp; Knowledge Base</p>
                <span className="text-stone-300">•</span>
                <ExtensionDownloadModal />
              </div>
            </div>
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
