'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { StaffUser } from '@/lib/board-data';

export default function LoginPage() {
  const router = useRouter();
  const { user, login, loginAs, recentUsers } = useAuth();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // If already logged in, redirect to home
  useEffect(() => {
    if (user) {
      router.push('/');
    }
  }, [user, router]);

  async function handleFormSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!username.trim()) {
      setErrorMsg('Mohon masukkan username staf');
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    const res = await login(username, password);
    setLoading(false);

    if (!res.success) {
      setErrorMsg(res.error || 'Kata sandi tidak sesuai. Silakan periksa kembali.');
    }
  }

  function handleQuickLogin(staff: StaffUser) {
    setUsername(staff.username);
    // Focus password field for security
    const passInput = document.getElementById('staffPasswordInput');
    if (passInput) passInput.focus();
  }

  return (
    <div className="max-w-md mx-auto py-8 space-y-6">
      
      {/* BRANDING HEADER */}
      <div className="text-center space-y-2">
        <img
          src="/logo.png"
          className="w-12 h-12 mx-auto rounded-2xl shadow-sm object-contain p-0.5 border border-[#E3E3DC] bg-white"
          alt="JagoanSearch"
        />
        <h1 className="font-display font-bold text-xl text-[#141517] tracking-tight">
          Masuk ke Jagoan Search
        </h1>
        <p className="text-xs text-[#52545A]">
          Portal Pencarian Tutorial &amp; Dokumentasi Teknis Jagoan Hosting
        </p>
      </div>

      {/* RECENT ACCOUNTS (QUICK LOGIN ON THIS DEVICE) */}
      {recentUsers.length > 0 && (
        <div className="editorial-card rounded-2xl p-4 bg-stone-50/80 border border-[#E3E3DC] space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="micro-label text-[10px]">⚡ Akun Terakhir di Perangkat Ini</span>
            <span className="text-[10px] text-stone-500 font-mono">Pilih Cepat</span>
          </div>
          <div className="space-y-1.5">
            {recentUsers.slice(0, 2).map((recent) => (
              <button
                key={recent.username}
                type="button"
                onClick={() => handleQuickLogin(recent)}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-white border border-[#E3E3DC] hover:border-stone-400 hover:bg-stone-50 transition text-left group shadow-2xs"
              >
                <div className="flex items-center space-x-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                    recent.role === 'admin' ? 'bg-rose-100 text-rose-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {recent.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-[#141517]">{recent.name}</p>
                    <p className="text-[10px] text-[#71737B] font-mono">{recent.username}</p>
                  </div>
                </div>
                <span className="text-xs font-medium text-blue-600 group-hover:underline">Gunakan Akun ➔</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* FORM LOGIN */}
      <div className="editorial-card rounded-2xl p-6 sm:p-8 space-y-5 bg-white shadow-xs">
        
        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-start space-x-2 font-medium">
            <span className="text-rose-500 font-bold">!</span>
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleFormSubmit} className="space-y-4">
          
          {/* Username Input */}
          <div className="space-y-1.5">
            <label className="micro-label block">Username Staf</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Masukkan username staf Anda"
              className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3.5 py-2.5 text-xs text-[#141517] outline-none focus:border-stone-900 transition placeholder-[#71737B]"
              required
              autoFocus
            />
          </div>

          {/* Password Input */}
          <div className="space-y-1.5">
            <label className="micro-label block">Kata Sandi (Password)</label>
            <input
              id="staffPasswordInput"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3.5 py-2.5 text-xs text-[#141517] outline-none focus:border-stone-900 transition"
              required
            />
          </div>

          {/* Sesi Terkunci Permanen Notice */}
          <div className="flex items-center space-x-2 pt-1 text-xs text-[#52545A]">
            <input
              type="checkbox"
              id="remember_locked"
              checked
              readOnly
              className="h-3.5 w-3.5 rounded border-stone-300 text-stone-900 focus:ring-0 cursor-not-allowed"
            />
            <label htmlFor="remember_locked" className="text-[11px] cursor-default flex items-center space-x-1">
              <span className="font-semibold text-[#141517]">🔒 Kunci Sesi Permanen</span>
              <span className="text-[#71737B]">(Tidak akan logout otomatis)</span>
            </label>
          </div>

          {/* Tombol Masuk */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 bg-[#141517] hover:bg-black text-white text-xs font-semibold rounded-xl shadow-xs transition duration-150 flex items-center justify-center space-x-2 disabled:opacity-70"
          >
            {loading ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Memverifikasi Akun...</span>
              </>
            ) : (
              <span>Masuk ke Portal Staf ➔</span>
            )}
          </button>
        </form>

      </div>

      <p className="text-center text-[11px] text-[#A1A1A9]">
        Kredensial staf bersifat pribadi. Hubungi Super Admin jika lupa kata sandi.
      </p>

    </div>
  );
}
