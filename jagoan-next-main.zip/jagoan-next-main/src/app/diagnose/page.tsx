'use client';

import React, { useState } from 'react';
import { Cpu, Sparkles, Copy, Check, Save, ArrowRight } from 'lucide-react';

export default function DiagnosePage() {
  const [platform, setPlatform] = useState('WordPress & CMS');
  const [issueTitle, setIssueTitle] = useState('');
  const [errorLog, setErrorLog] = useState('');
  const [solution, setSolution] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleDiagnose(e: React.FormEvent) {
    e.preventDefault();
    if (!issueTitle.trim() && !errorLog.trim()) return;

    setLoading(true);
    setSolution(null);
    setSaved(false);

    // Call AI diagnosis logic
    setTimeout(() => {
      let mockAiSolution = '';
      const text = (issueTitle + ' ' + errorLog).toLowerCase();

      if (text.includes('dmarc') || text.includes('554') || text.includes('yahoo')) {
        mockAiSolution = `🔍 AKAR MASALAH:\nEmail ditolak server tujuan (Yahoo/Google) karena domain pengirim belum memiliki autentikasi DMARC yang valid.\n\n🛠️ LANGKAH PERBAIKAN:\n1. Masuk ke cPanel > Zone Editor domain terkait.\n2. Tambahkan TXT Record:\n   - Name: _dmarc.namadomain.com\n   - TTL: 14400\n   - Record: v=DMARC1; p=none; sp=none; rua=mailto:dmarc@namadomain.com\n3. Verifikasi record SPF menyertakan include/IP server hosting Jagoan Hosting.\n4. Lakukan pengetesan ulang setelah propagasi DNS 15-30 menit.`;
      } else if (text.includes('500') || text.includes('internal server') || text.includes('fatal error')) {
        mockAiSolution = `🔍 AKAR MASALAH:\nInternal Server Error disebabkan oleh kegagalan eksekusi PHP, memori terlampaui (memory_limit), atau aturan rewrite di .htaccess rusak.\n\n🛠️ LANGKAH PERBAIKAN:\n1. Buka File Manager > public_html > periksa file 'error_log'.\n2. Jika terdapat memory exhausted: Naikkan memory_limit menjadi 512M di Select PHP Version > Options.\n3. Jika error terjadi setelah update plugin: Rename sementara folder plugin di wp-content/plugins/.\n4. Cek permission file: Pastikan folder 755 dan file 644.`;
      } else if (text.includes('aapanel') || text.includes('nginx') || text.includes('port 80')) {
        mockAiSolution = `🔍 AKAR MASALAH:\nWeb server di aaPanel gagal berjalan karena terjadi port conflict (bentrok port 80/443 dengan proses lain) atau konfigurasi vhost korup.\n\n🛠️ LANGKAH PERBAIKAN:\n1. Login ke server via SSH: ssh root@IP_SERVER.\n2. Periksa proses yang memakai port 80: netstat -tulpn | grep :80\n3. Hentikan service apache/nginx duplikat: systemctl stop apache2 httpd\n4. Jalankan ulang Nginx melalui aaPanel: systemctl restart nginx.`;
      } else {
        mockAiSolution = `🔍 HASIL ANALISIS KENDALA [${platform}]:\nKendala '${issueTitle || 'Umum'}' memerlukan pemeriksaan log server dan konfigurasi runtime.\n\n🛠️ LANGKAH INVESTIGASI TEKNIS:\n1. Periksa ketersediaan resource server (RAM, Disk, CPU) via htop atau df -h.\n2. Pastikan versi PHP dan modul yang dibutuhkan aplikasi sudah aktif.\n3. Periksa koneksi database di file konfigurasi (kredensial DB_HOST, DB_USER, DB_PASSWORD).\n4. Bersihkan cache aplikasi dan restart service terkait.`;
      }

      setSolution(mockAiSolution);
      setLoading(false);
    }, 1200);
  }

  function handleCopy() {
    if (!solution) return;
    navigator.clipboard.writeText(solution);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      
      {/* HEADER */}
      <div>
        <h1 className="text-2xl font-extrabold text-[#141517] tracking-tight flex items-center space-x-2">
          <span>🤖</span>
          <span>Asisten Diagnosa AI (Gemini & Groq Copilot)</span>
        </h1>
        <p className="text-xs text-stone-500 mt-1">
          Analisis log error dan investigasi kasus teknis secara cerdas langsung di dalam aplikasi.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* INPUT FORM */}
        <form onSubmit={handleDiagnose} className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4 shadow-xs">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-700">Platform Layanan</label>
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-semibold text-stone-800 outline-none focus:border-blue-500"
            >
              <option>Hosting & cPanel</option>
              <option>WordPress & CMS</option>
              <option>VPS & aaPanel</option>
              <option>VPS & CyberPanel</option>
              <option>Email Bisnis</option>
              <option>Domain & DNS</option>
              <option>SSL & Keamanan</option>
              <option>Node.js & Laravel</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-700">Judul Kasus / Gejala Kendala</label>
            <input
              type="text"
              value={issueTitle}
              onChange={(e) => setIssueTitle(e.target.value)}
              placeholder="Contoh: Email bounce 554 di Yahoo atau Error 500 saat login WP"
              className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 outline-none focus:border-blue-500"
              required
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-700">Potongan Error Log / Pesan Kesalahan</label>
            <textarea
              rows={6}
              value={errorLog}
              onChange={(e) => setErrorLog(e.target.value)}
              placeholder="Paste log error dari cPanel error_log, Nginx log, atau pesan bounce pelanggan di sini..."
              className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-800 outline-none focus:border-blue-500"
            ></textarea>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center space-x-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Menganalisis dengan Copilot...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Analisis & Hasilkan Solusi AI</span>
              </>
            )}
          </button>
        </form>

        {/* OUTPUT SOLUTION */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 flex flex-col justify-between shadow-xs">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <span className="text-xs font-bold text-purple-800 flex items-center space-x-1.5">
                <Cpu className="w-3.5 h-3.5" />
                <span>Rekomendasi Langkah Resolusi</span>
              </span>
              {solution && (
                <button
                  onClick={handleCopy}
                  className="text-xs text-stone-500 hover:text-stone-900 font-semibold flex items-center space-x-1"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Tersalin!' : 'Salin Teks'}</span>
                </button>
              )}
            </div>

            {solution ? (
              <div className="bg-purple-50/50 p-4 rounded-xl border border-purple-100 font-mono text-xs text-stone-800 whitespace-pre-wrap leading-relaxed max-h-[380px] overflow-y-auto">
                {solution}
              </div>
            ) : (
              <div className="py-24 text-center text-stone-400 space-y-2">
                <Sparkles className="w-8 h-8 mx-auto text-stone-300" />
                <p className="text-xs">Isi form di samping untuk menghasilkan investigasi akar masalah otomatis.</p>
              </div>
            )}
          </div>

          {solution && (
            <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
              <span className="text-[10px] text-stone-400">Siap dikirim ke pelanggan</span>
              <button
                onClick={() => setSaved(true)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1 transition ${
                  saved ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                <Save className="w-3.5 h-3.5" />
                <span>{saved ? 'Tersimpan di Histori!' : 'Simpan Kasus'}</span>
              </button>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
