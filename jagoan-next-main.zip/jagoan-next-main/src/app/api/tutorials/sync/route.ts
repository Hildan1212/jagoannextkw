import { NextRequest, NextResponse } from 'next/server';
import { getTiDbPool, initTiDbSchema } from '@/lib/db';
import allTutorialsData from '@/lib/tutorials_data.json';

export const dynamic = 'force-dynamic';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: CORS_HEADERS });
}

function decodeHtml(html: string): string {
  if (!html) return '';
  return html
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8216;/g, "'")
    .replace(/&#8217;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#038;/g, '&')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .trim();
}

function cleanExcerpt(rawHtml: string, fallbackTitle: string): string {
  if (!rawHtml) {
    return `Panduan resmi Knowledge Base Jagoan Hosting untuk ${fallbackTitle}. Pelajari langkah konfigurasi dan pemecahan kendala teknis.`;
  }
  const clean = rawHtml.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
  const decoded = decodeHtml(clean);
  if (decoded.length < 15) {
    return `Panduan resmi Knowledge Base Jagoan Hosting untuk ${fallbackTitle}. Pelajari langkah konfigurasi dan pemecahan kendala teknis.`;
  }
  return decoded.slice(0, 220) + (decoded.length > 220 ? '...' : '');
}

function categorize(url: string, title: string): string {
  const combined = (url + ' ' + title).toLowerCase();

  if (
    combined.includes('vps') ||
    combined.includes('cloud server') ||
    combined.includes('aapanel') ||
    combined.includes('cyberpanel') ||
    combined.includes('cloudpanel') ||
    combined.includes('directadmin') ||
    combined.includes('docker') ||
    combined.includes('ssh') ||
    combined.includes('almalinux') ||
    combined.includes('ubuntu') ||
    combined.includes('centos') ||
    combined.includes('debian')
  ) {
    return 'VPS & Cloud Server';
  }

  if (
    combined.includes('email') ||
    combined.includes('webmail') ||
    combined.includes('outlook') ||
    combined.includes('dmarc') ||
    combined.includes('spf') ||
    combined.includes('dkim') ||
    combined.includes('mail server') ||
    combined.includes('thunderbird') ||
    combined.includes('smtp') ||
    combined.includes('pop3') ||
    combined.includes('imap')
  ) {
    return 'Email Bisnis';
  }

  if (
    combined.includes('domain') ||
    combined.includes('dns') ||
    combined.includes('nameserver') ||
    combined.includes('whois') ||
    combined.includes('epp') ||
    combined.includes('cloudflare') ||
    combined.includes('ns ') ||
    combined.includes('a record') ||
    combined.includes('cname')
  ) {
    return 'Domain & DNS';
  }

  if (
    combined.includes('wordpress') ||
    combined.includes('elementor') ||
    combined.includes('woocommerce') ||
    combined.includes('moodle') ||
    combined.includes('joomla') ||
    combined.includes('cms') ||
    combined.includes('plugin') ||
    combined.includes('tema wordpress')
  ) {
    return 'WordPress & CMS';
  }

  if (
    combined.includes('ssl') ||
    combined.includes('https') ||
    combined.includes('keamanan') ||
    combined.includes('security') ||
    combined.includes('malware') ||
    combined.includes('2fa') ||
    combined.includes('imunify') ||
    combined.includes('antivirus')
  ) {
    return 'SSL & Keamanan';
  }

  if (
    combined.includes('laravel') ||
    combined.includes('node') ||
    combined.includes('python') ||
    combined.includes('git') ||
    combined.includes('composer') ||
    combined.includes('database') ||
    combined.includes('mysql') ||
    combined.includes('postgresql') ||
    combined.includes('framework') ||
    combined.includes('codeigniter')
  ) {
    return 'Apps & Framework';
  }

  return 'Hosting & cPanel';
}

function extractTags(url: string, title: string, category: string): string[] {
  const combined = (url + ' ' + title + ' ' + category).toLowerCase();
  const keywords = [
    'cpanel', 'plesk', 'hosting', 'vps', 'ssh', 'domain', 'dns', 'nameserver',
    'wordpress', 'elementor', 'woocommerce', 'email', 'webmail', 'outlook',
    'ssl', 'https', 'laravel', 'mysql', 'database', 'php', 'backup', 'softaculous',
    'aapanel', 'cyberpanel', 'cloudpanel', 'ftp', 'filemanager', 'cloudflare',
    'dmarc', 'spf', 'dkim', 'moodle', 'security', 'malware', 'node', 'python'
  ];
  const tags: string[] = [];
  for (const kw of keywords) {
    if (combined.includes(kw)) {
      tags.push(kw);
    }
  }
  if (tags.length === 0) tags.push('tutorial', 'jagoan-hosting');
  return tags.slice(0, 5);
}

export async function GET(request: NextRequest) {
  try {
    // 1. Fetch the latest posts from Jagoan Hosting official WordPress REST API
    const wpRes = await fetch('https://www.jagoanhosting.com/tutorial/wp-json/wp/v2/posts?per_page=20&page=1', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) JagoanSearch-Sync/4.0',
      },
      next: { revalidate: 0 },
    });

    if (!wpRes.ok) {
      throw new Error(`WordPress API returned status ${wpRes.status}`);
    }

    const totalFromHeader = parseInt(wpRes.headers.get('x-wp-total') || '1856', 10);
    const latestPosts = await wpRes.json();

    let newItemsCount = 0;
    const pool = getTiDbPool();

    if (pool && Array.isArray(latestPosts)) {
      await initTiDbSchema();
      const conn = await pool.getConnection();

      try {
        for (const p of latestPosts) {
          const url = (p.link || '').trim();
          if (!url) continue;

          const title = decodeHtml(p.title?.rendered || p.slug);
          const excerpt = cleanExcerpt(p.excerpt?.rendered, title);
          const category = categorize(url, title);
          const tags = extractTags(url, title, category);

          const [res]: any = await conn.query(
            `INSERT INTO tutorials (id, title, slug, category, url, excerpt, content, tags, reading_time, is_popular, views_count)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               title = VALUES(title),
               excerpt = VALUES(excerpt),
               url = VALUES(url),
               category = VALUES(category),
               tags = VALUES(tags);`,
            [
              p.id,
              title.slice(0, 250),
              p.slug.slice(0, 250),
              category,
              url.slice(0, 490),
              excerpt.slice(0, 500),
              `Dokumentasi resmi: ${url}`,
              JSON.stringify(tags),
              4,
              0,
              150,
            ]
          );

          if (res && res.affectedRows === 1) {
            newItemsCount++;
          }
        }
      } finally {
        conn.release();
      }
    }

    const firstPost = latestPosts[0] || {};

    return NextResponse.json(
      {
        success: true,
        message: `Sinkronisasi berhasil! Database terhubung dengan ${totalFromHeader} panduan resmi terbaru Jagoan Hosting.`,
        total_tutorials: totalFromHeader,
        new_items_found: newItemsCount,
        latest_tutorial: {
          title: decodeHtml(firstPost.title?.rendered || 'Tutorial Terbaru'),
          url: firstPost.link,
          date: firstPost.date,
          modified: firstPost.modified,
        },
        synced_at: new Date().toISOString(),
      },
      { headers: CORS_HEADERS }
    );
  } catch (err: any) {
    console.error('Error syncing tutorials:', err);
    return NextResponse.json(
      {
        success: false,
        error: err.message,
        message: 'Gagal menghubungi server WordPress Jagoan Hosting. Menggunakan indeks lokal 1.856 tutorial.',
        total_tutorials: 1856,
      },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}

export async function POST(request: NextRequest) {
  return GET(request);
}
