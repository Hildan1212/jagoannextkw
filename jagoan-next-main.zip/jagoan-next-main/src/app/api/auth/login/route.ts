import { NextRequest, NextResponse } from 'next/server';
import { getTiDbPool, initTiDbSchema } from '@/lib/db';
import { INITIAL_STAFF_USERS } from '@/lib/board-data';

export const dynamic = 'force-dynamic';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: CORS_HEADERS });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const usernameInput = (body.username || body.email || '').trim().toLowerCase();
    const passwordInput = (body.password || '').trim();

    if (!usernameInput) {
      return NextResponse.json({ success: false, error: 'Mohon masukkan username staf' }, { status: 400, headers: CORS_HEADERS });
    }

    // 1. Try checking TiDB Cloud
    const pool = getTiDbPool();
    if (pool) {
      try {
        await initTiDbSchema();
        const conn = await pool.getConnection();
        try {
          const [rows] = await conn.query(
            `SELECT id, username, name, email, password, role FROM users 
             WHERE LOWER(username) = ? OR LOWER(name) = ? OR LOWER(email) = ?
             LIMIT 1`,
            [usernameInput, usernameInput, usernameInput]
          );

          const foundRow = (rows as any[])[0];
          if (foundRow) {
            // Verify password
            if (foundRow.password === passwordInput) {
              return NextResponse.json(
                {
                  success: true,
                  user: {
                    id: foundRow.id,
                    username: foundRow.username || foundRow.name.toLowerCase().replace(/\s+/g, ''),
                    name: foundRow.name,
                    email: foundRow.email || `${foundRow.username}@jagoanhosting.com`,
                    role: foundRow.role,
                  },
                },
                { headers: CORS_HEADERS }
              );
            } else {
              return NextResponse.json(
                { success: false, error: 'Kata sandi tidak sesuai. Silakan hubungi Admin jika Anda lupa kata sandi.' },
                { status: 401, headers: CORS_HEADERS }
              );
            }
          }
        } finally {
          conn.release();
        }
      } catch (dbErr) {
        console.warn('TiDB auth error, checking memory fallback:', dbErr);
      }
    }

    // 2. Fallback to INITIAL_STAFF_USERS in memory
    const localUser = INITIAL_STAFF_USERS.find(
      (u) =>
        u.username.toLowerCase() === usernameInput ||
        u.name.toLowerCase() === usernameInput ||
        (u.email && u.email.toLowerCase() === usernameInput)
    );

    if (localUser) {
      if (!localUser.password || localUser.password === passwordInput) {
        return NextResponse.json(
          {
            success: true,
            user: {
              id: localUser.id,
              username: localUser.username,
              name: localUser.name,
              email: localUser.email,
              role: localUser.role,
            },
          },
          { headers: CORS_HEADERS }
        );
      } else {
        return NextResponse.json(
          { success: false, error: 'Kata sandi tidak sesuai. Silakan hubungi Admin jika Anda lupa kata sandi.' },
          { status: 401, headers: CORS_HEADERS }
        );
      }
    }

    return NextResponse.json(
      { success: false, error: `Username "${usernameInput}" tidak ditemukan dalam daftar staf resmi.` },
      { status: 404, headers: CORS_HEADERS }
    );
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
  }
}
