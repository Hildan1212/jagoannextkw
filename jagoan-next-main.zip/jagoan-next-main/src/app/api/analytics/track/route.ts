import { NextRequest, NextResponse } from 'next/server';
import { getTiDbPool, initTiDbSchema } from '@/lib/db';

export const dynamic = 'force-dynamic';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
};

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: CORS_HEADERS,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const tutorialId = body.tutorial_id || null;
    const tutorialTitle = (body.tutorial_title || body.title || '').trim();
    const tutorialUrl = (body.tutorial_url || body.url || '').trim();
    const username = (body.username || 'guest').trim();
    const userRole = (body.user_role || 'agent').trim();
    const source = (body.source || 'web').trim(); // 'web' or 'extension'

    if (!tutorialTitle && !tutorialUrl) {
      return NextResponse.json(
        { success: false, error: 'Informasi tutorial tidak lengkap' },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    const pool = getTiDbPool();
    if (pool) {
      try {
        await initTiDbSchema();
        const conn = await pool.getConnection();
        try {
          // 1. Insert into tutorial_views audit log
          await conn.query(
            `INSERT INTO tutorial_views (tutorial_id, tutorial_title, tutorial_url, username, user_role, source)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [tutorialId, tutorialTitle, tutorialUrl, username, userRole, source]
          );

          // 2. Increment views_count in tutorials if tutorial_id exists
          if (tutorialId) {
            await conn.query(`UPDATE tutorials SET views_count = views_count + 1 WHERE id = ?`, [tutorialId]);
          } else if (tutorialUrl) {
            await conn.query(`UPDATE tutorials SET views_count = views_count + 1 WHERE url = ?`, [tutorialUrl]);
          }
        } finally {
          conn.release();
        }
      } catch (dbErr) {
        console.warn('Gagal mencatat audit log tutorial_views ke TiDB:', dbErr);
      }
    }

    return NextResponse.json({ success: true, message: 'Audit view tercatat' }, { status: 200, headers: CORS_HEADERS });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
  }
}
