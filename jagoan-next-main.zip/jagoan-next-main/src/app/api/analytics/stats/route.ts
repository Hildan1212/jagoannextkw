import { NextRequest, NextResponse } from 'next/server';
import { getTiDbPool, initTiDbSchema } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const username = searchParams.get('username') || '';
  const role = searchParams.get('role') || '';

  // PRIVILEGE CHECK: Only Super Admin has privilege to view audit analytics!
  if (role !== 'admin' && username.toLowerCase() !== 'admin') {
    return NextResponse.json(
      {
        success: false,
        error: 'Akses ditolak: Statistik dan audit pembacaan tutorial adalah hak istimewa (privilege) Super Admin.',
      },
      { status: 403 }
    );
  }

  const pool = getTiDbPool();
  if (!pool) {
    return NextResponse.json({
      success: true,
      total_views: 0,
      views_today: 0,
      by_agent: [],
      by_source: [],
      top_tutorials: [],
      recent_logs: [],
    });
  }

  try {
    await initTiDbSchema();
    const conn = await pool.getConnection();

    try {
      // 1. Total views
      const [totalRows] = await conn.query('SELECT COUNT(*) as count FROM tutorial_views');
      const totalViews = (totalRows as any[])[0]?.count || 0;

      // 2. Views today
      const [todayRows] = await conn.query(
        'SELECT COUNT(*) as count FROM tutorial_views WHERE DATE(viewed_at) = CURRENT_DATE'
      );
      const viewsToday = (todayRows as any[])[0]?.count || 0;

      // 3. Breakdown by Agent
      const [agentRows] = await conn.query(
        `SELECT username, user_role, COUNT(*) as count, MAX(viewed_at) as last_viewed 
         FROM tutorial_views 
         GROUP BY username, user_role 
         ORDER BY count DESC`
      );

      // 4. Breakdown by Source (Web vs Extension)
      const [sourceRows] = await conn.query(
        `SELECT source, COUNT(*) as count 
         FROM tutorial_views 
         GROUP BY source`
      );

      // 5. Top Tutorials Opened
      const [tutorialRows] = await conn.query(
        `SELECT tutorial_title, tutorial_url, COUNT(*) as count, 
                GROUP_CONCAT(DISTINCT username ORDER BY username SEPARATOR ', ') as viewers 
         FROM tutorial_views 
         GROUP BY tutorial_title, tutorial_url 
         ORDER BY count DESC 
         LIMIT 20`
      );

      // 6. Recent Logs
      const [recentRows] = await conn.query(
        `SELECT id, tutorial_title, tutorial_url, username, user_role, source, viewed_at 
         FROM tutorial_views 
         ORDER BY viewed_at DESC 
         LIMIT 60`
      );

      return NextResponse.json({
        success: true,
        total_views: totalViews,
        views_today: viewsToday,
        by_agent: agentRows,
        by_source: sourceRows,
        top_tutorials: tutorialRows,
        recent_logs: recentRows,
      });
    } finally {
      conn.release();
    }
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
