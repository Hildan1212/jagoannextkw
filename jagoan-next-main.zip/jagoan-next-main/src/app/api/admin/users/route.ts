import { NextRequest, NextResponse } from 'next/server';
import {
  getAllStaffUsers,
  createStaffUser,
  deleteStaffUser,
  updateStaffUserPassword,
} from '@/lib/db';

export const dynamic = 'force-dynamic';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: CORS_HEADERS });
}

// 1. GET: Ambil daftar seluruh user / akun CS
export async function GET(request: NextRequest) {
  try {
    const users = await getAllStaffUsers();
    return NextResponse.json(
      {
        success: true,
        total: users.length,
        users: users.map((u: any) => ({
          id: u.id,
          username: u.username,
          name: u.name,
          email: u.email || `${u.username}@jagoanhosting.com`,
          role: u.role || 'agent',
          password: u.password || '******',
          created_at: u.created_at || null,
        })),
      },
      { headers: CORS_HEADERS }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Gagal mengambil daftar user' },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}

// 2. POST: Tambah akun baru atau perbarui password
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const action = body.action || 'create';

    if (action === 'updatePassword') {
      const { id, password } = body;
      if (!id || !password) {
        return NextResponse.json(
          { success: false, error: 'ID user dan password baru harus diisi' },
          { status: 400, headers: CORS_HEADERS }
        );
      }
      const res = await updateStaffUserPassword(Number(id), password);
      if (!res.success) {
        return NextResponse.json(
          { success: false, error: res.error },
          { status: 400, headers: CORS_HEADERS }
        );
      }
      return NextResponse.json(
        { success: true, message: 'Password user berhasil diperbarui.' },
        { headers: CORS_HEADERS }
      );
    }

    // Default: create user
    const { username, name, password, role, email } = body;
    if (!username || !name) {
      return NextResponse.json(
        { success: false, error: 'Username dan Nama Staf wajib diisi.' },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    const res = await createStaffUser({
      username,
      name,
      password,
      role: role || 'agent',
      email,
    });

    if (!res.success) {
      return NextResponse.json(
        { success: false, error: res.error },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    return NextResponse.json(
      {
        success: true,
        user: res.user,
        message: `Akun untuk "${res.user?.name}" (@${res.user?.username}) berhasil dibuat!`,
      },
      { headers: CORS_HEADERS }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Gagal memproses permintaan' },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}

// 3. DELETE: Hapus akun CS
export async function DELETE(request: NextRequest) {
  try {
    let id: number | null = null;
    const { searchParams } = new URL(request.url);
    const queryId = searchParams.get('id');

    if (queryId) {
      id = Number(queryId);
    } else {
      try {
        const body = await request.json();
        if (body.id) id = Number(body.id);
      } catch (e) {
        // no body
      }
    }

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'ID user yang akan dihapus wajib disertakan' },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    const res = await deleteStaffUser(id);
    if (!res.success) {
      return NextResponse.json(
        { success: false, error: res.error },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    return NextResponse.json(
      { success: true, message: 'Akun staf berhasil dihapus dari sistem.' },
      { headers: CORS_HEADERS }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Gagal menghapus user' },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}
