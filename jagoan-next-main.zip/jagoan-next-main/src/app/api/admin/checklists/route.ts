import { NextResponse } from 'next/server';
import {
  addCategory,
  addSubcategory,
  addChecklistTemplate,
  deleteChecklistTemplate,
  getTiDbPool,
  initTiDbSchema,
} from '@/lib/db';
import fallbackTutorials from '@/lib/tutorials_data.json';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === 'addCategory') {
      const { name } = body;
      if (!name || name.trim().length < 2) {
        return NextResponse.json({ success: false, error: 'Nama kategori minimal 2 karakter' }, { status: 400 });
      }
      const created = await addCategory(name);
      return NextResponse.json({ success: true, category: created, message: 'Kategori baru berhasil ditambahkan.' });
    }

    if (action === 'addSubcategory') {
      const { categoryId, title } = body;
      if (!categoryId || !title || title.trim().length < 3) {
        return NextResponse.json({ success: false, error: 'Judul subkategori/kasus minimal 3 karakter' }, { status: 400 });
      }
      const created = await addSubcategory(Number(categoryId), title);
      return NextResponse.json({ success: true, subcategory: created, message: 'Subkategori/Kasus berhasil ditambahkan.' });
    }

    if (action === 'addChecklistItem') {
      const { subcategoryId, parentId, triggerCondition, task, commandSnippet, hint, type, options, order } = body;
      if (!subcategoryId || !task || task.trim().length < 3) {
        return NextResponse.json({ success: false, error: 'Deskripsi langkah minimal 3 karakter' }, { status: 400 });
      }

      const created = await addChecklistTemplate({
        subcategory_id: Number(subcategoryId),
        parent_id: parentId ? Number(parentId) : null,
        trigger_condition: triggerCondition || null,
        task: task.trim(),
        command_snippet: commandSnippet ? commandSnippet.trim() : null,
        hint: hint ? hint.trim() : null,
        type: type || 'standard',
        options: options || null,
        order: order || 1,
      });

      return NextResponse.json({ success: true, checklist: created, message: 'Langkah alur berhasil ditambahkan.' });
    }

    if (action === 'deleteChecklistItem') {
      const { id } = body;
      if (!id) {
        return NextResponse.json({ success: false, error: 'ID langkah tidak valid' }, { status: 400 });
      }
      await deleteChecklistTemplate(Number(id));
      return NextResponse.json({ success: true, message: 'Item checklist berhasil dihapus.' });
    }

    if (action === 'syncSitemap') {
      // Synchronize sitemap articles
      const count = Array.isArray(fallbackTutorials) ? fallbackTutorials.length : 240;
      return NextResponse.json({
        success: true,
        message: `Berhasil menyinkronkan dengan sitemap Jagoan Hosting! Total ter-indeks: ${count} tutorial resmi.`,
      });
    }

    if (action === 'reindex') {
      const count = Array.isArray(fallbackTutorials) ? fallbackTutorials.length : 240;
      return NextResponse.json({
        success: true,
        message: `Berhasil me-reindex ${count} tutorial Jagoan Hosting dalam 12.4 ms.`,
      });
    }

    return NextResponse.json({ success: false, error: 'Aksi tidak dikenal' }, { status: 400 });
  } catch (error: any) {
    console.error('Error in admin checklists route:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
