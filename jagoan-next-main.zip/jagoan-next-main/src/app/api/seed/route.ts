import { NextResponse } from 'next/server';
import { exec } from 'child_process';
import path from 'path';

export async function POST() {
  return new Promise((resolve) => {
    const scriptPath = path.resolve(process.cwd(), 'scripts/seed.mjs');
    exec(`node "${scriptPath}"`, (error, stdout, stderr) => {
      if (error) {
        console.error('Seed execution error:', error, stderr);
        resolve(NextResponse.json({ success: false, error: stderr || error.message }, { status: 500 }));
      } else {
        resolve(NextResponse.json({
          success: true,
          output: stdout,
          message: 'Database TiDB Cloud berhasil di-seed dengan seluruh data staf, alur checklist, kasus, dan 236 tutorial!',
        }));
      }
    });
  });
}
