import { NextRequest, NextResponse } from 'next/server';
import { getTiDbPool, initTiDbSchema, getAllCsExternalLinks } from '@/lib/db';
import allTutorialsData from '@/lib/tutorials_data.json';
import { defaultAiCases } from '@/lib/constants';

export const dynamic = 'force-dynamic';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
};

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: CORS_HEADERS,
  });
}

interface ScoredTutorial {
  tutorial: any;
  score: number;
}

function calculateFuzzyScore(query: string, title: string, excerpt: string = '', tags: string[] = [], category: string = ''): number {
  const q = query.toLowerCase().trim();
  const t = (title || '').toLowerCase();
  const e = (excerpt || '').toLowerCase();
  const cat = (category || '').toLowerCase();
  const tagStr = (tags || []).join(' ').toLowerCase();

  // 1. Exact match
  if (t === q) return 1000;
  if (t.includes(q)) return 500 + Math.min(100, (q.length / t.length) * 100);
  if (e.includes(q)) return 300;
  if (tagStr.includes(q) || cat.includes(q)) return 250;

  // 2. Tokenized words match
  const words = q.split(/[\s,.-]+/).filter((w) => w.length >= 2);
  let wordHits = 0;
  for (const w of words) {
    if (t.includes(w)) wordHits += 3;
    else if (e.includes(w)) wordHits += 1.5;
    else if (tagStr.includes(w) || cat.includes(w)) wordHits += 2;
  }
  if (words.length > 0 && wordHits > 0) {
    return 150 + (wordHits / words.length) * 100;
  }

  // 3. Trigram similarity for typo tolerance
  if (q.length >= 3) {
    const qTrigrams = new Set<string>();
    for (let i = 0; i <= q.length - 3; i++) {
      qTrigrams.add(q.slice(i, i + 3));
    }

    let matchCount = 0;
    for (let i = 0; i <= t.length - 3; i++) {
      if (qTrigrams.has(t.slice(i, i + 3))) {
        matchCount++;
      }
    }

    const similarity = matchCount / Math.max(1, qTrigrams.size);
    if (similarity > 0.22) {
      return 80 * similarity;
    }
  }

  // 4. Character overlap
  const cleanQ = q.replace(/[^a-z0-9]/g, '');
  if (cleanQ.length >= 4) {
    const uniqueChars = new Set(cleanQ.split(''));
    let charMatches = 0;
    for (const ch of uniqueChars) {
      if (t.includes(ch)) charMatches++;
    }
    const ratio = charMatches / uniqueChars.size;
    if (ratio >= 0.75) {
      return 25 * ratio;
    }
  }

  return 0;
}

export async function GET(request: NextRequest) {
  const start = performance.now();
  const searchParams = request.nextUrl.searchParams;

  const rawQuery = (searchParams.get('q') || '').trim();
  const category = (searchParams.get('category') || 'Semua').trim();
  const includeAi = searchParams.get('include_ai') !== '0' && searchParams.get('include_ai') !== 'false';
  const limit = Math.min(Math.max(parseInt(searchParams.get('limit') || '25', 10), 1), 200);

  const results: any[] = [];
  let totalMatches = 0;
  let isFuzzy = false;
  let searchMessage: string | null = null;
  const pool = getTiDbPool();

  try {
    // 1. Fetch AI Cases if enabled
    if (includeAi) {
      let aiFound: any[] = [];

      if (pool) {
        try {
          await initTiDbSchema();
          const conn = await pool.getConnection();
          try {
            let aiSql = "SELECT id, platform, issue_title, gemini_solution, error_log, status, created_at FROM cs_reports WHERE (status = 'solved' OR gemini_solution IS NOT NULL)";
            const aiParams: any[] = [];

            if (rawQuery) {
              aiSql += " AND (issue_title LIKE ? OR gemini_solution LIKE ? OR platform LIKE ?)";
              aiParams.push(`%${rawQuery}%`, `%${rawQuery}%`, `%${rawQuery}%`);
            }

            aiSql += " ORDER BY created_at DESC LIMIT 5";
            const [aiRows] = await conn.query(aiSql, aiParams);

            for (const item of aiRows as any[]) {
              aiFound.push({
                type: 'ai_case',
                id: item.id,
                title: item.issue_title,
                platform: item.platform,
                category: item.platform,
                category_color: 'bg-purple-50 text-purple-800 border-purple-200',
                solution: item.gemini_solution,
                board_url: '/board?tab=gemini',
                created_at: 'Baru saja',
              });
            }
          } finally {
            conn.release();
          }
        } catch (e) {
          // ignore, fallback below
        }
      }

      // Robust fallback to defaultAiCases if TiDB returned nothing or wasn't reachable
      if (aiFound.length === 0 && Array.isArray(defaultAiCases)) {
        for (const item of defaultAiCases) {
          const matchQuery = !rawQuery ||
            item.title.toLowerCase().includes(rawQuery.toLowerCase()) ||
            item.solution.toLowerCase().includes(rawQuery.toLowerCase()) ||
            item.platform.toLowerCase().includes(rawQuery.toLowerCase());

          if (matchQuery) {
            aiFound.push({
              type: 'ai_case',
              id: item.id,
              title: item.title,
              platform: item.platform,
              category: item.category || item.platform,
              category_color: item.category_color || 'bg-purple-50 text-purple-800 border-purple-200',
              solution: item.solution,
              board_url: '/board?tab=gemini',
              created_at: item.created_at || 'Baru saja',
            });
          }
        }
      }

      results.push(...aiFound);
    }

    // 2. Fetch CS External Links with (by CS) badge
    try {
      const allCsLinks = await getAllCsExternalLinks();
      const userRole = (searchParams.get('role') || '').toLowerCase();
      const isAdmin = userRole === 'admin';

      for (const link of allCsLinks) {
        const match =
          !rawQuery ||
          calculateFuzzyScore(rawQuery, link.title, link.description || '', [], link.category || '') > 0 ||
          link.title.toLowerCase().includes(rawQuery.toLowerCase()) ||
          (link.description && link.description.toLowerCase().includes(rawQuery.toLowerCase()));

        if (match) {
          results.push({
            type: 'cs_link',
            id: link.id,
            title: link.title,
            url: link.url,
            category: link.category || 'Rekomendasi CS',
            category_color: 'bg-emerald-50 text-emerald-800 border-emerald-300',
            excerpt: link.description || `Panduan eksternal rekomendasi rekan tim CS untuk topik "${link.title}". Klik untuk membuka halaman resmi.`,
            badge: '(by CS)',
            tag_cs: true,
            created_by_name: isAdmin ? link.created_by_name : undefined,
            created_by_username: isAdmin ? link.created_by_username : undefined,
            created_at: link.created_at || 'Baru saja',
          });
        }
      }
    } catch (e) {
      console.warn('Error querying cs_external_links:', e);
    }

    // 3. Query Tutorials from 1,856 Knowledge Base
    const allTutorials: any[] = Array.isArray(allTutorialsData) ? allTutorialsData : [];

    // Filter by category if selected
    let candidatePool = allTutorials;
    if (category !== 'Semua') {
      candidatePool = allTutorials.filter((t) => t.category === category);
      if (candidatePool.length === 0) candidatePool = allTutorials;
    }

    if (!rawQuery) {
      totalMatches = candidatePool.length;
      // Return popular & top read tutorials
      const topItems = candidatePool
        .slice()
        .sort((a, b) => (b.views_count || 0) - (a.views_count || 0))
        .slice(0, limit);

      for (const tut of topItems) {
        results.push({
          type: 'tutorial',
          id: tut.id,
          title: tut.title,
          slug: tut.slug,
          category: tut.category,
          url: tut.url,
          excerpt: tut.excerpt,
          reading_time: tut.reading_time || 3,
          views_count: tut.views_count || 500,
          tags: tut.tags || [],
        });
      }
    } else {
      // SMART MULTI-TIER SEARCH (EXACT -> TOKENIZED -> FUZZY / NEAREST)
      const scoredList: ScoredTutorial[] = [];

      for (const tut of candidatePool) {
        const score = calculateFuzzyScore(rawQuery, tut.title, tut.excerpt, tut.tags, tut.category);
        if (score > 0) {
          scoredList.push({ tutorial: tut, score });
        }
      }

      scoredList.sort((a, b) => b.score - a.score);
      totalMatches = scoredList.length;

      // Check if we found exact/strong matches
      const strongMatches = scoredList.filter((s) => s.score >= 100);

      if (strongMatches.length > 0) {
        const selected = scoredList.slice(0, limit);
        for (const s of selected) {
          results.push({
            type: 'tutorial',
            id: s.tutorial.id,
            title: s.tutorial.title,
            slug: s.tutorial.slug,
            category: s.tutorial.category,
            url: s.tutorial.url,
            excerpt: s.tutorial.excerpt,
            reading_time: s.tutorial.reading_time || 3,
            views_count: s.tutorial.views_count || 500,
            tags: s.tutorial.tags || [],
            score: s.score,
          });
        }
      } else if (scoredList.length > 0) {
        // FUZZY / NEAREST MATCH FOUND
        isFuzzy = true;
        searchMessage = `Menampilkan ${scoredList.length} artikel dengan kata atau topik yang paling mendekati "${rawQuery}".`;

        const selected = scoredList.slice(0, limit);
        for (const s of selected) {
          results.push({
            type: 'tutorial',
            id: s.tutorial.id,
            title: s.tutorial.title,
            slug: s.tutorial.slug,
            category: s.tutorial.category,
            url: s.tutorial.url,
            excerpt: s.tutorial.excerpt,
            reading_time: s.tutorial.reading_time || 3,
            views_count: s.tutorial.views_count || 500,
            tags: s.tutorial.tags || [],
            score: s.score,
            is_fuzzy: true,
          });
        }
      } else {
        // NO DIRECT CHAR MATCH -> NEVER SAY "TIDAK ADA", RETURN POPULAR FALLBACK
        isFuzzy = true;
        searchMessage = `Topik tidak ditemukan persis untuk "${rawQuery}". Menampilkan rekomendasi panduan terpopuler & sering dicari:`;

        const fallbackTop = candidatePool
          .slice()
          .sort((a, b) => (b.views_count || 0) - (a.views_count || 0))
          .slice(0, 10);

        totalMatches = fallbackTop.length;

        for (const tut of fallbackTop) {
          results.push({
            type: 'tutorial',
            id: tut.id,
            title: tut.title,
            slug: tut.slug,
            category: tut.category,
            url: tut.url,
            excerpt: tut.excerpt,
            reading_time: tut.reading_time || 3,
            views_count: tut.views_count || 500,
            tags: tut.tags || [],
            is_fallback: true,
          });
        }
      }
    }
  } catch (err: any) {
    console.error('Search API error:', err);
  }

  const durationMs = Math.round((performance.now() - start) * 100) / 100;

  return NextResponse.json(
    {
      success: true,
      query: rawQuery,
      category: category,
      total_found: results.length,
      total_matches: totalMatches,
      total_database: allTutorialsData.length || 1856,
      duration_ms: durationMs,
      is_fuzzy: isFuzzy,
      message: searchMessage,
      results: results,
    },
    {
      status: 200,
      headers: CORS_HEADERS,
    }
  );
}
