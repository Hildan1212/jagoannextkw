import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: CORS_HEADERS });
}

export async function GET() {
  return NextResponse.json(
    {
      version: '1.0.1',
      name: 'JagoanSearch Extension',
      release_date: '2026-10-15',
      download_url: '/downloads/jagoan-search-extension.zip',
      changelog: [
        'Sinkronisasi otomatis dengan sesi login portal website',
        'Tampilan airy dan eye-friendly dengan badge CS ringkas',
        'Live feed kasus Solved by AI langsung di layar awal',
        'CORS dan host permissions terintegrasi penuh',
      ],
    },
    {
      headers: CORS_HEADERS,
    }
  );
}
