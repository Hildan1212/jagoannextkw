import { NextResponse } from 'next/server';
import { runAiDiagnosis } from '@/lib/ai-diagnose';
import { createCsReport, updateCsReportSolution } from '@/lib/db';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { platform, issueTitle, errorLog, reporterName, customApiKey, reportId, solutionInput } = body;

    // Mode 1: Edit / Update existing CS report solution
    if (reportId && solutionInput) {
      await updateCsReportSolution(reportId, solutionInput);
      return NextResponse.json({ success: true, message: 'Solusi berhasil diperbarui!' });
    }

    // Mode 2: Run diagnosis
    if (!issueTitle) {
      return NextResponse.json({ success: false, error: 'Judul kendala wajib diisi' }, { status: 400 });
    }

    const solution = await runAiDiagnosis({
      platform: platform || 'WordPress',
      title: issueTitle,
      errorLog: errorLog || null,
      customApiKey: customApiKey || null,
    });

    // Auto-save to knowledge base
    const saved = await createCsReport({
      platform: platform || 'WordPress',
      issue_title: issueTitle,
      error_log: errorLog || null,
      reporter_name: reporterName || 'Rekan CS',
      generated_prompt: `Diagnosa langsung in-app untuk: ${issueTitle}`,
      gemini_solution: solution,
      status: 'solved',
    });

    return NextResponse.json({
      success: true,
      solution,
      report: saved,
      message: 'Analisis selesai! Solusi teknis dan draf balasan tiket telah dihasilkan langsung & otomatis tersimpan ke Knowledge Base.',
    });
  } catch (error: any) {
    console.error('Error in AI diagnose route:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
