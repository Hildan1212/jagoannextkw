import { NextResponse } from 'next/server';
import {
  getCategories,
  getSubcategories,
  getChecklists,
  getCaseReports,
  getCsReports,
  createCaseReport,
  getStaffUsers,
  getTiDbPool,
  initTiDbSchema,
} from '@/lib/db';
import { CaseReport } from '@/lib/board-data';

export async function GET() {
  try {
    await initTiDbSchema();
    const categories = await getCategories();
    const subcategories = await getSubcategories();
    const caseReports = await getCaseReports();
    const csReports = await getCsReports();
    const staffUsers = getStaffUsers();

    // Fetch all checklists for all subcategories
    const allChecklists = [];
    for (const sub of subcategories) {
      const items = await getChecklists(sub.id);
      allChecklists.push(...items);
    }

    // Calculate dynamic statistics
    const totalCases = caseReports.length;
    const totalAi = csReports.length;
    const avgDuration = totalCases > 0
      ? Math.round(caseReports.reduce((acc, c) => acc + (c.duration_seconds || 0), 0) / totalCases / 60)
      : 13;
    const avgCsat = 5.0;

    // Case frequencies
    const caseFrequencies = subcategories.map((sub) => {
      const matched = caseReports.filter((c) => c.subcategory_id === sub.id);
      const count = matched.length;
      const agents = Array.from(new Set(matched.map((m) => m.agent_name).filter(Boolean)));
      const subAvg = count > 0
        ? Math.round(matched.reduce((acc, m) => acc + (m.duration_seconds || 0), 0) / count / 60)
        : 14;
      const parentCat = categories.find((c) => c.id === sub.category_id);

      return {
        subcategory_id: sub.id,
        title: sub.title,
        category_name: parentCat ? parentCat.name : 'Umum',
        count,
        percentage: totalCases > 0 ? Math.round((count / totalCases) * 100) : 0,
        avg_duration: subAvg,
        agents,
      };
    }).sort((a, b) => b.count - a.count);

    // Agent statistics
    const agentStats = staffUsers.map((ag) => {
      const handled = caseReports.filter((c) => c.agent_name === ag.name || c.user_id === ag.id);
      const aiSearches = csReports.filter((r) => r.reporter_name === ag.name || r.user_id === ag.id);
      const lastCase = handled[0];
      const sub = lastCase ? subcategories.find((s) => s.id === lastCase.subcategory_id) : null;
      const avgDur = handled.length > 0
        ? Math.round(handled.reduce((acc, h) => acc + (h.duration_seconds || 0), 0) / handled.length / 60)
        : 0;

      return {
        id: ag.id,
        name: ag.name,
        email: ag.email,
        role: ag.role,
        handled_count: handled.length,
        ai_searches: aiSearches.length,
        avg_duration: avgDur,
        avg_csat: 5.0,
        last_activity: lastCase ? lastCase.created_at : 'Belum ada',
        last_case_title: sub ? sub.title : (lastCase?.subcategory_title || '-'),
      };
    }).sort((a, b) => b.handled_count - a.handled_count);

    return NextResponse.json({
      success: true,
      categories,
      subcategories,
      checklists: allChecklists,
      caseReports,
      csReports,
      staffUsers,
      statistics: {
        total_cases: totalCases,
        total_ai_consultations: totalAi,
        avg_duration: avgDuration,
        avg_csat: avgCsat,
        case_frequencies: caseFrequencies,
        agent_stats: agentStats,
      },
    });
  } catch (error: any) {
    console.error('Error fetching board data:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { subcategoryId, customerName, agentName, durationSeconds, solutionSummary, items, ticketId } = body;

    const report = await createCaseReport({
      subcategory_id: subcategoryId,
      customer_name: customerName || 'Pelanggan',
      agent_name: agentName || 'Customer Support',
      ticket_id: ticketId || `#${Math.floor(Math.random() * 8999) + 1000}`,
      status: 'resolved',
      started_at: new Date(Date.now() - durationSeconds * 1000).toISOString(),
      resolved_at: new Date().toISOString(),
      duration_seconds: durationSeconds || 720,
      csat_score: 5,
      csat_comment: 'Kasus diselesaikan cepat dan terstruktur!',
      solution_summary: solutionSummary,
      redundant_checks_count: 0,
      items: items || [],
    });

    return NextResponse.json({ success: true, report });
  } catch (error: any) {
    console.error('Error submitting case report:', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
