import { NextRequest, NextResponse } from 'next/server';
import {
  getAllCsExternalLinks,
  createCsExternalLink,
  deleteCsExternalLink,
} from '@/lib/db';

export const dynamic = 'force-dynamic';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: CORS_HEADERS });
}

// 1. GET: Ambil daftar link eksternal (Masked untuk CS biasa, Full untuk Admin)
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const role = (searchParams.get('role') || '').toLowerCase();
    const isAdmin = role === 'admin';

    const links = await getAllCsExternalLinks();

    const formatted = links.map((link) => ({
      id: link.id,
      title: link.title,
      url: link.url,
      category: link.category || 'Rekomendasi CS',
      description: link.description || '',
      tag: '(by CS)',
      views_count: link.views_count || 0,
      created_at: link.created_at || 'Baru saja',
      // Jika Admin: tampilkan nama & username pembuat asli. Jika CS biasa: sembunyikan demi anonimitas
      created_by_name: isAdmin ? link.created_by_name : 'Rekan CS',
      created_by_username: isAdmin ? link.created_by_username : 'cs',
      is_anonymous_to_peer: !isAdmin,
    }));

    return NextResponse.json(
      {
        success: true,
        total: formatted.length,
        links: formatted,
      },
      { headers: CORS_HEADERS }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Gagal memuat link solusi' },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}

// 2. POST: Tambah link eksternal baru (bisa dilakukan oleh CS biasa maupun Admin)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, url, category, description, username, name } = body;

    if (!title || !title.trim()) {
      return NextResponse.json(
        { success: false, error: 'Judul tutorial/panduan wajib diisi.' },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    if (!url || !url.trim() || !url.startsWith('http')) {
      return NextResponse.json(
        { success: false, error: 'Link URL tidak valid (harus diawali http:// atau https://)' },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    const created = await createCsExternalLink({
      title: title.trim(),
      url: url.trim(),
      category: category?.trim() || 'Rekomendasi CS',
      description: description?.trim() || '',
      username: username?.trim() || 'cs',
      name: name?.trim() || 'Rekan CS',
    });

    return NextResponse.json(
      {
        success: true,
        link: created,
        message: 'Link panduan berhasil disimpan dan akan tampil dengan tag (by CS).',
      },
      { headers: CORS_HEADERS }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Gagal menyimpan link panduan' },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}

// 3. DELETE: Hapus link eksternal (Privilege Admin)
export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    let id = searchParams.get('id');

    if (!id) {
      try {
        const body = await request.json();
        if (body.id) id = body.id;
      } catch (e) {
        // no body
      }
    }

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'ID link wajib disertakan' },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    const res = await deleteCsExternalLink(Number(id));
    if (!res.success) {
      return NextResponse.json(
        { success: false, error: res.error },
        { status: 400, headers: CORS_HEADERS }
      );
    }

    return NextResponse.json(
      { success: true, message: 'Link solusi berhasil dihapus dari sistem.' },
      { headers: CORS_HEADERS }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, error: err.message || 'Gagal menghapus link solusi' },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}
