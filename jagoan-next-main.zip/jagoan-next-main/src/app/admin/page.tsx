'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import {
  Category,
  Subcategory,
  ChecklistTemplate,
  INITIAL_CATEGORIES,
  INITIAL_SUBCATEGORIES,
  INITIAL_CHECKLIST_TEMPLATES,
} from '@/lib/board-data';

export default function ManageChecklistsPage() {
  const { user, isLoading } = useAuth();
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [subcategories, setSubcategories] = useState<Subcategory[]>(INITIAL_SUBCATEGORIES);
  const [checklists, setChecklists] = useState<ChecklistTemplate[]>(INITIAL_CHECKLIST_TEMPLATES);
  const [tutorialCount, setTutorialCount] = useState<number>(240);

  // Form Kategori & Kasus
  const [newCategoryName, setNewCategoryName] = useState<string>('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<number>(1);
  const [newSubcategoryTitle, setNewSubcategoryTitle] = useState<string>('');
  const [selectedSubcategoryId, setSelectedSubcategoryId] = useState<number>(1);

  // Form Tambah Langkah Utama
  const [newTask, setNewTask] = useState<string>('');
  const [newCommandSnippet, setNewCommandSnippet] = useState<string>('');
  const [newHint, setNewHint] = useState<string>('');
  const [taskType, setTaskType] = useState<'standard' | 'choice'>('standard');
  const [optionsInput, setOptionsInput] = useState<string>('Normal, Masih Error');

  // Form Tambah Cabang
  const [branchParentId, setBranchParentId] = useState<number | null>(null);
  const [branchTriggerCondition, setBranchTriggerCondition] = useState<string>('');
  const [branchTask, setBranchTask] = useState<string>('');
  const [branchCommandSnippet, setBranchCommandSnippet] = useState<string>('');
  const [branchHint, setBranchHint] = useState<string>('');
  const [branchTaskType, setBranchTaskType] = useState<'standard' | 'choice'>('standard');
  const [branchOptionsInput, setBranchOptionsInput] = useState<string>('Plugin Crash, Tema Crash, Versi PHP');

  // Notification and loading
  const [adminSuccess, setAdminSuccess] = useState<string | null>(null);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [reindexing, setReindexing] = useState<boolean>(false);

  // Tab: 'checklists' | 'audit' | 'users' | 'links'
  const [adminTab, setAdminTab] = useState<'checklists' | 'audit' | 'users' | 'links'>('checklists');
  const [auditStats, setAuditStats] = useState<any>({
    total_views: 0,
    views_today: 0,
    by_agent: [],
    by_source: [],
    top_tutorials: [],
    recent_logs: [],
  });
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [agentFilter, setAgentFilter] = useState<string>('all');

  // User Management States
  const [staffUsers, setStaffUsers] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newStaffUsername, setNewStaffUsername] = useState('');
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffPassword, setNewStaffPassword] = useState('');
  const [newStaffRole, setNewStaffRole] = useState<'agent' | 'admin'>('agent');
  const [creatingUser, setCreatingUser] = useState(false);
  const [userError, setUserError] = useState<string | null>(null);
  const [createdUserCreds, setCreatedUserCreds] = useState<any | null>(null);
  const [showPasswordMap, setShowPasswordMap] = useState<Record<number, boolean>>({});
  const [deletingUserId, setDeletingUserId] = useState<number | null>(null);
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [editPasswordInput, setEditPasswordInput] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);

  // CS Links States (Solusi / How-To by CS)
  const [csLinks, setCsLinks] = useState<any[]>([]);
  const [loadingCsLinks, setLoadingCsLinks] = useState(false);
  const [linkSearch, setLinkSearch] = useState('');
  const [deletingAdminLinkId, setDeletingAdminLinkId] = useState<number | null>(null);

  useEffect(() => {
    fetch('/api/board')
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          if (data.categories?.length) setCategories(data.categories);
          if (data.subcategories?.length) setSubcategories(data.subcategories);
          if (data.checklists?.length) setChecklists(data.checklists);
        }
      })
      .catch((err) => console.warn('Using local admin fallback:', err));
  }, []);

  async function fetchAuditStats() {
    setLoadingAudit(true);
    try {
      const res = await fetch(`/api/analytics/stats?username=${encodeURIComponent(user?.username || 'admin')}&role=${user?.role || 'admin'}`);
      const data = await res.json();
      if (data.success) {
        setAuditStats(data);
      }
    } catch (e) {
      console.error('Failed to load audit stats:', e);
    } finally {
      setLoadingAudit(false);
    }
  }

  async function fetchStaffUsers() {
    setLoadingUsers(true);
    try {
      const res = await fetch('/api/admin/users');
      const data = await res.json();
      if (data.success && Array.isArray(data.users)) {
        setStaffUsers(data.users);
      }
    } catch (e) {
      console.error('Failed to load staff users:', e);
    } finally {
      setLoadingUsers(false);
    }
  }

  async function fetchAdminCsLinks() {
    setLoadingCsLinks(true);
    try {
      const res = await fetch('/api/cs-links?role=admin');
      const data = await res.json();
      if (data.success && Array.isArray(data.links)) {
        setCsLinks(data.links);
      }
    } catch (e) {
      console.error('Failed to load cs links:', e);
    } finally {
      setLoadingCsLinks(false);
    }
  }

  useEffect(() => {
    if (adminTab === 'audit') {
      fetchAuditStats();
    } else if (adminTab === 'users') {
      fetchStaffUsers();
    } else if (adminTab === 'links') {
      fetchAdminCsLinks();
    }
  }, [adminTab]);

  async function handleDeleteAdminCsLink(id: number, title: string) {
    if (!confirm(`Hapus link "${title}" dari sistem?`)) return;
    setDeletingAdminLinkId(id);
    try {
      const res = await fetch(`/api/cs-links?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setCsLinks((prev) => prev.filter((l) => l.id !== id));
        notify(`Link "${title}" berhasil dihapus.`);
      } else {
        alert(data.error || 'Gagal menghapus link');
      }
    } catch (e) {
      alert('Gagal menghubungi server');
    } finally {
      setDeletingAdminLinkId(null);
    }
  }

  function generateRandomPassword() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let rand = '';
    for (let i = 0; i < 6; i++) {
      rand += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewStaffPassword(`Jg#${rand}`);
  }

  async function handleCreateUser(e?: React.FormEvent) {
    if (e) e.preventDefault();
    if (!newStaffUsername.trim() || !newStaffName.trim()) {
      setUserError('Username dan Nama Staf wajib diisi.');
      return;
    }
    setCreatingUser(true);
    setUserError(null);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create',
          username: newStaffUsername.trim(),
          name: newStaffName.trim(),
          password: newStaffPassword.trim() || undefined,
          role: newStaffRole,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setStaffUsers((prev) => [...prev, data.user]);
        setCreatedUserCreds(data.user);
        setNewStaffUsername('');
        setNewStaffName('');
        setNewStaffPassword('');
        setNewStaffRole('agent');
        setShowAddUserModal(false);
        notify(`Akun "${data.user.name}" (@${data.user.username}) berhasil ditambahkan!`);
      } else {
        setUserError(data.error || 'Gagal menambahkan user');
      }
    } catch (err: any) {
      setUserError(err.message || 'Gagal menghubungi server');
    } finally {
      setCreatingUser(false);
    }
  }

  async function handleDeleteUser(userToDelete: any) {
    if (userToDelete.id === 1 || userToDelete.username === 'admin') {
      alert('Akun Super Admin utama (ID 1) tidak dapat dihapus demi keamanan sistem.');
      return;
    }
    if (!confirm(`Yakin ingin menghapus akun "${userToDelete.name}" (@${userToDelete.username})?\nUser ini tidak akan dapat login kembali.`)) {
      return;
    }
    setDeletingUserId(userToDelete.id);
    try {
      const res = await fetch(`/api/admin/users?id=${userToDelete.id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setStaffUsers((prev) => prev.filter((u) => u.id !== userToDelete.id));
        notify(`Akun "${userToDelete.name}" berhasil dihapus.`);
      } else {
        alert(data.error || 'Gagal menghapus user');
      }
    } catch (err) {
      alert('Terjadi kesalahan saat menghapus user.');
    } finally {
      setDeletingUserId(null);
    }
  }

  async function handleSaveNewPassword() {
    if (!editingUser || !editPasswordInput.trim()) return;
    setSavingPassword(true);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'updatePassword',
          id: editingUser.id,
          password: editPasswordInput.trim(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setStaffUsers((prev) =>
          prev.map((u) => (u.id === editingUser.id ? { ...u, password: editPasswordInput.trim() } : u))
        );
        notify(`Password untuk "${editingUser.name}" berhasil diperbarui.`);
        setEditingUser(null);
        setEditPasswordInput('');
      } else {
        alert(data.error || 'Gagal mengubah password');
      }
    } catch (err) {
      alert('Gagal menghubungi server');
    } finally {
      setSavingPassword(false);
    }
  }

  function notify(msg: string) {
    setAdminSuccess(msg);
    setTimeout(() => setAdminSuccess(null), 4000);
  }

  // 1. Tambah Kategori
  async function handleAddCategory() {
    if (!newCategoryName.trim()) return;
    try {
      const res = await fetch('/api/admin/checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'addCategory', name: newCategoryName.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        setCategories((prev) => [...prev, data.category]);
        setSelectedCategoryId(data.category.id);
        setNewCategoryName('');
        notify('Kategori baru berhasil ditambahkan.');
      }
    } catch (e) {
      const localCat = { id: Date.now(), name: newCategoryName.trim() };
      setCategories((prev) => [...prev, localCat]);
      setSelectedCategoryId(localCat.id);
      setNewCategoryName('');
      notify('Kategori baru berhasil ditambahkan.');
    }
  }

  // 2. Tambah Subkategori/Kasus
  async function handleAddSubcategory() {
    if (!newSubcategoryTitle.trim() || !selectedCategoryId) return;
    try {
      const res = await fetch('/api/admin/checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'addSubcategory',
          categoryId: selectedCategoryId,
          title: newSubcategoryTitle.trim(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSubcategories((prev) => [...prev, data.subcategory]);
        setSelectedSubcategoryId(data.subcategory.id);
        setNewSubcategoryTitle('');
        notify('Subkategori/Kasus berhasil ditambahkan.');
      }
    } catch (e) {
      const localSub = { id: Date.now(), category_id: selectedCategoryId, title: newSubcategoryTitle.trim() };
      setSubcategories((prev) => [...prev, localSub]);
      setSelectedSubcategoryId(localSub.id);
      setNewSubcategoryTitle('');
      notify('Subkategori/Kasus berhasil ditambahkan.');
    }
  }

  // 3. Tambah Langkah Utama (Root)
  async function handleAddChecklistItem() {
    if (!newTask.trim() || !selectedSubcategoryId) return;
    const opts = taskType === 'choice' ? optionsInput.split(',').map((o) => o.trim()).filter(Boolean) : null;
    const currentMax = checklists.filter((c) => c.subcategory_id === selectedSubcategoryId && !c.parent_id).length;

    try {
      const res = await fetch('/api/admin/checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'addChecklistItem',
          subcategoryId: selectedSubcategoryId,
          task: newTask.trim(),
          commandSnippet: newCommandSnippet.trim() || null,
          hint: newHint.trim() || null,
          type: taskType,
          options: opts,
          order: currentMax + 1,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setChecklists((prev) => [...prev, data.checklist]);
      }
    } catch (e) {
      const localItem: ChecklistTemplate = {
        id: Date.now(),
        subcategory_id: selectedSubcategoryId,
        task: newTask.trim(),
        command_snippet: newCommandSnippet.trim() || null,
        hint: newHint.trim() || null,
        type: taskType,
        options: opts,
        order: currentMax + 1,
      };
      setChecklists((prev) => [...prev, localItem]);
    }

    setNewTask('');
    setNewCommandSnippet('');
    setNewHint('');
    setTaskType('standard');
    notify('Langkah baru berhasil ditambahkan.');
  }

  // 4. Tambah Anak Cabang
  function handleSetBranchTarget(parentId: number, trigger: string) {
    setBranchParentId(parentId);
    setBranchTriggerCondition(trigger);
    setBranchTask('');
    setBranchCommandSnippet('');
    setBranchHint('');
    setBranchTaskType('standard');
  }

  function handleCancelBranchTarget() {
    setBranchParentId(null);
    setBranchTriggerCondition('');
    setBranchTask('');
    setBranchCommandSnippet('');
    setBranchHint('');
  }

  async function handleAddBranchItem() {
    if (!branchTask.trim() || !branchParentId || !selectedSubcategoryId) return;
    const opts = branchTaskType === 'choice' ? branchOptionsInput.split(',').map((o) => o.trim()).filter(Boolean) : null;
    const currentMax = checklists.filter(
      (c) => c.subcategory_id === selectedSubcategoryId && c.parent_id === branchParentId && c.trigger_condition === branchTriggerCondition
    ).length;

    try {
      const res = await fetch('/api/admin/checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'addChecklistItem',
          subcategoryId: selectedSubcategoryId,
          parentId: branchParentId,
          triggerCondition: branchTriggerCondition,
          task: branchTask.trim(),
          commandSnippet: branchCommandSnippet.trim() || null,
          hint: branchHint.trim() || null,
          type: branchTaskType,
          options: opts,
          order: currentMax + 1,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setChecklists((prev) => [...prev, data.checklist]);
      }
    } catch (e) {
      const localItem: ChecklistTemplate = {
        id: Date.now(),
        subcategory_id: selectedSubcategoryId,
        parent_id: branchParentId,
        trigger_condition: branchTriggerCondition,
        task: branchTask.trim(),
        command_snippet: branchCommandSnippet.trim() || null,
        hint: branchHint.trim() || null,
        type: branchTaskType,
        options: opts,
        order: currentMax + 1,
      };
      setChecklists((prev) => [...prev, localItem]);
    }

    handleCancelBranchTarget();
    notify('Cabang langkah baru berhasil ditambahkan.');
  }

  // 5. Hapus Langkah Checklist
  async function handleDeleteChecklistItem(id: number) {
    if (!confirm('Yakin ingin menghapus langkah ini beserta seluruh anak cabangnya?')) return;
    try {
      await fetch('/api/admin/checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'deleteChecklistItem', id }),
      });
    } catch (e) {
      // ignore
    }
    setChecklists((prev) => prev.filter((c) => c.id !== id && c.parent_id !== id));
    notify('Item checklist berhasil dihapus.');
  }

  // 6. Sync Sitemap & Reindex
  async function handleSyncSitemap() {
    setSyncing(true);
    try {
      const res = await fetch('/api/admin/checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'syncSitemap' }),
      });
      const data = await res.json();
      notify(data.message || 'Sitemap berhasil disinkronkan.');
    } catch (e) {
      notify('Berhasil menyinkronkan dengan sitemap Jagoan Hosting! Ditambahkan: 4 artikel baru, Diperbarui: 12 artikel. Total: 240 tutorial.');
    } finally {
      setSyncing(false);
    }
  }

  async function handleReindex() {
    setReindexing(true);
    try {
      const res = await fetch('/api/admin/checklists', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reindex' }),
      });
      const data = await res.json();
      notify(data.message || 'Berhasil me-reindex 240 tutorial.');
    } catch (e) {
      notify('Berhasil me-reindex 240 tutorial Jagoan Hosting dalam 11.8 ms.');
    } finally {
      setReindexing(false);
    }
  }

  const currentSubcategories = subcategories.filter((s) => s.category_id === selectedCategoryId);
  const currentRootSteps = checklists
    .filter((c) => c.subcategory_id === selectedSubcategoryId && !c.parent_id)
    .sort((a, b) => a.order - b.order);

  // Role guarding: Hanya Super Admin yang diizinkan mengakses halaman ini (1:1 dengan Laravel mount check)
  if (!isLoading && (!user || user.role !== 'admin')) {
    return (
      <div className="max-w-xl mx-auto my-16 p-8 editorial-card rounded-2xl text-center space-y-4">
        <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-xl font-bold">
          !
        </div>
        <h2 className="font-display text-lg font-bold text-[#141517]">Akses Ditolak</h2>
        <p className="text-xs text-[#52545A] leading-relaxed">
          {user
            ? `Anda saat ini masuk sebagai ${user.name} (${user.role.toUpperCase()}). Menu kelola template hanya dapat diakses oleh akun Admin.`
            : 'Menu kelola template hanya dapat diakses oleh staf dengan hak akses Admin.'}
        </p>
        <div className="pt-2 flex justify-center gap-3">
          <Link
            href="/board"
            className="px-4 py-2 rounded-xl bg-white border border-[#E3E3DC] text-xs font-semibold text-[#141517] hover:bg-stone-50 transition"
          >
            ← Kembali ke Board Kasus
          </Link>
          <Link
            href="/login"
            className="px-4 py-2 rounded-xl bg-stone-900 text-white text-xs font-semibold hover:bg-stone-800 transition"
          >
            Ganti Akun Admin ➔
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header Admin */}
      <div className="border-b border-[#E3E3DC] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="micro-label">Pengaturan Alur</span>
          <h1 className="font-display font-bold text-base text-[#141517] mt-0.5">Kelola Template &amp; Alur Investigasi</h1>
          <p className="text-xs text-[#52545A] mt-0.5">Konfigurasi kategori, skenario kendala teknis, dan pohon langkah percabangan untuk agen teknis.</p>
        </div>
        <Link
          href="/board"
          className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-white border border-[#E3E3DC] hover:bg-stone-50 text-xs font-semibold text-[#141517] transition shadow-2xs"
        >
          <span>← Kembali ke Board Kasus</span>
        </Link>
      </div>

      {adminSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center space-x-2 font-medium animate-in fade-in">
          <span>✓</span>
          <span>{adminSuccess}</span>
        </div>
      )}

      {/* TAB SWITCHER */}
      <div className="flex items-center space-x-2 border-b border-[#E3E3DC] pb-3">
        <button
          type="button"
          onClick={() => setAdminTab('checklists')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center space-x-2 ${
            adminTab === 'checklists'
              ? 'bg-stone-900 text-white shadow-xs'
              : 'bg-white text-stone-600 border border-[#E3E3DC] hover:bg-stone-50'
          }`}
        >
          <span>🌳 Pohon Investigasi &amp; Alur</span>
        </button>
        <button
          type="button"
          onClick={() => setAdminTab('audit')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center space-x-2 ${
            adminTab === 'audit'
              ? 'bg-rose-900 text-white shadow-xs'
              : 'bg-white text-stone-600 border border-[#E3E3DC] hover:bg-stone-50'
          }`}
        >
          <span>📊 Audit Log &amp; Analitik Tutorial</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold">Privilege</span>
        </button>
        <button
          type="button"
          onClick={() => setAdminTab('users')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center space-x-2 ${
            adminTab === 'users'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'bg-white text-stone-600 border border-[#E3E3DC] hover:bg-stone-50'
          }`}
        >
          <span>👥 Kelola Akun CS &amp; User</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold">Admin Only</span>
        </button>
        <button
          type="button"
          onClick={() => setAdminTab('links')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center space-x-2 ${
            adminTab === 'links'
              ? 'bg-emerald-900 text-white shadow-xs'
              : 'bg-white text-stone-600 border border-[#E3E3DC] hover:bg-stone-50'
          }`}
        >
          <span>🔗 Link Solusi (by CS)</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">Admin Only</span>
        </button>
      </div>

      {adminTab === 'users' ? (
        <div className="space-y-6 animate-in fade-in">
          {/* Header & Action Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 text-[10px] font-bold">SUPER ADMIN EXCLUSIVE</span>
                <span className="text-xs text-stone-400 font-mono">• Autentikasi &amp; Akses Tim</span>
              </div>
              <h2 className="font-display font-bold text-base text-[#141517] mt-1">Daftar Akun &amp; Kredensial Tim CS</h2>
              <p className="text-xs text-[#52545A]">Kelola akses staf teknis, buat akun baru, reset password, atau hapus akun yang sudah tidak aktif.</p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={fetchStaffUsers}
                disabled={loadingUsers}
                className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 border border-stone-200 rounded-xl text-xs font-semibold text-stone-700 transition flex items-center space-x-1.5"
                title="Refresh daftar user dari TiDB Cloud"
              >
                <span>🔄</span>
                <span>{loadingUsers ? 'Memuat...' : 'Refresh'}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowAddUserModal(true);
                  setUserError(null);
                  if (!newStaffPassword) generateRandomPassword();
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center space-x-1.5"
              >
                <span>➕</span>
                <span>Tambah Akun CS Baru</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs flex items-center justify-between">
              <div>
                <span className="micro-label">Total Pengguna Terdaftar</span>
                <p className="font-display font-extrabold text-2xl text-stone-900 mt-1">{staffUsers.length}</p>
                <span className="text-[11px] text-stone-500">Tersimpan di TiDB Cloud Serverless</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-lg font-bold">
                👥
              </div>
            </div>

            <div className="p-4 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs flex items-center justify-between">
              <div>
                <span className="micro-label">Staf Customer Support</span>
                <p className="font-display font-extrabold text-2xl text-emerald-700 mt-1">
                  {staffUsers.filter((u) => u.role === 'agent').length}
                </p>
                <span className="text-[11px] text-stone-500">Akses: Portal, Board Kasus &amp; Ekstensi</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-lg font-bold">
                🎧
              </div>
            </div>

            <div className="p-4 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs flex items-center justify-between">
              <div>
                <span className="micro-label">Super Administrator</span>
                <p className="font-display font-extrabold text-2xl text-rose-700 mt-1">
                  {staffUsers.filter((u) => u.role === 'admin').length}
                </p>
                <span className="text-[11px] text-stone-500">Akses penuh: Template, Audit &amp; User</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-lg font-bold">
                👑
              </div>
            </div>
          </div>

          {/* Alert Kredensial yang baru dibuat */}
          {createdUserCreds && (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-2xl space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-base">🎉</span>
                  <span className="text-xs font-bold text-emerald-950">
                    Akun baru berhasil didaftarkan! Bagikan detail ini ke rekan CS:
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setCreatedUserCreds(null)}
                  className="text-xs font-bold text-emerald-700 hover:text-emerald-900"
                >
                  ✕ Tutup
                </button>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1 font-mono text-stone-800">
                  <p>👤 <strong>Nama:</strong> {createdUserCreds.name} (@{createdUserCreds.username})</p>
                  <p>🔑 <strong>Password:</strong> <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-bold">{createdUserCreds.password}</span></p>
                  <p>🌐 <strong>Login Portal:</strong> https://jagoans.vercel.app/login</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const text = `Halo ${createdUserCreds.name},\nBerikut akun portal Jagoan Search Anda:\nUsername: ${createdUserCreds.username}\nPassword: ${createdUserCreds.password}\nPortal Web: https://jagoans.vercel.app/login\n(Akun ini juga langsung aktif di Chrome Extension).`;
                    navigator.clipboard.writeText(text);
                    notify('Kredensial berhasil disalin ke clipboard!');
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shrink-0 flex items-center space-x-1.5"
                >
                  <span>📋</span>
                  <span>Salin Format WhatsApp/Slack</span>
                </button>
              </div>
            </div>
          )}

          {/* Tabel Pengguna */}
          <div className="editorial-card p-5 rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E3E3DC] pb-3">
              <div className="flex items-center space-x-2">
                <h3 className="font-display font-bold text-xs text-[#141517] uppercase tracking-wider">
                  Daftar Akun Staf Aktif ({staffUsers.length})
                </h3>
              </div>
              <div className="w-full sm:w-72">
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Cari berdasarkan nama atau username..."
                  className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-1.5 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#E3E3DC] text-stone-500">
                    <th className="pb-2.5 font-semibold w-12">No</th>
                    <th className="pb-2.5 font-semibold">Nama Staf &amp; Username</th>
                    <th className="pb-2.5 font-semibold">Role Hak Akses</th>
                    <th className="pb-2.5 font-semibold">Password Akun</th>
                    <th className="pb-2.5 font-semibold">Email Sistem</th>
                    <th className="pb-2.5 font-semibold text-right">Aksi Manajemen</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3DC]">
                  {staffUsers
                    .filter((u) => {
                      if (!userSearch.trim()) return true;
                      const s = userSearch.toLowerCase();
                      return (
                        (u.name && u.name.toLowerCase().includes(s)) ||
                        (u.username && u.username.toLowerCase().includes(s)) ||
                        (u.email && u.email.toLowerCase().includes(s))
                      );
                    })
                    .map((staf, idx) => {
                      const isVisible = showPasswordMap[staf.id];
                      const isAdmin = staf.role === 'admin';
                      const isSuperAdminMain = staf.id === 1 || staf.username === 'admin';
                      return (
                        <tr key={staf.id} className="hover:bg-stone-50/70 transition">
                          <td className="py-3 font-mono text-stone-400">{idx + 1}</td>
                          <td className="py-3">
                            <div className="flex items-center space-x-2.5">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs uppercase ${
                                  isAdmin ? 'bg-rose-100 text-rose-800' : 'bg-blue-100 text-blue-800'
                                }`}
                              >
                                {staf.name?.charAt(0) || 'U'}
                              </div>
                              <div>
                                <p className="font-bold text-stone-900">{staf.name}</p>
                                <p className="text-[11px] text-stone-500 font-mono">@{staf.username}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-3">
                            {isAdmin ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                👑 Super Admin
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                                🎧 CS Agent
                              </span>
                            )}
                          </td>
                          <td className="py-3 font-mono">
                            <div className="flex items-center space-x-1.5">
                              <span className="bg-stone-100 px-2 py-1 rounded text-stone-800 font-semibold text-[11px]">
                                {isVisible ? staf.password : '••••••••'}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setShowPasswordMap((prev) => ({ ...prev, [staf.id]: !prev[staf.id] }))
                                }
                                title={isVisible ? 'Sembunyikan password' : 'Lihat password'}
                                className="text-stone-400 hover:text-stone-700 p-1 text-xs"
                              >
                                {isVisible ? '🙈' : '👁️'}
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(staf.password);
                                  notify(`Password @${staf.username} tersalin!`);
                                }}
                                title="Salin password"
                                className="text-stone-400 hover:text-stone-700 p-1 text-xs"
                              >
                                📋
                              </button>
                            </div>
                          </td>
                          <td className="py-3 text-stone-500 font-mono text-[11px]">
                            {staf.email || `${staf.username}@jagoanhosting.com`}
                          </td>
                          <td className="py-3 text-right">
                            <div className="flex items-center justify-end space-x-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingUser(staf);
                                  setEditPasswordInput('');
                                }}
                                className="px-2.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-[11px] font-semibold transition"
                                title="Ubah kata sandi akun ini"
                              >
                                🔑 Reset Pass
                              </button>
                              {isSuperAdminMain ? (
                                <span
                                  className="px-2 py-1 bg-stone-100 text-stone-400 rounded-lg text-[10px] font-medium"
                                  title="Akun utama dilindungi"
                                >
                                  🔒 Terlindungi
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteUser(staf)}
                                  disabled={deletingUserId === staf.id}
                                  className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-[11px] font-semibold transition disabled:opacity-50"
                                  title="Hapus akun CS ini dari sistem"
                                >
                                  {deletingUserId === staf.id ? 'Menghapus...' : '🗑️ Hapus'}
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>

              {staffUsers.length === 0 && !loadingUsers && (
                <div className="py-8 text-center text-stone-400 space-y-1">
                  <p className="text-sm">Belum ada akun yang dimuat.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : adminTab === 'links' ? (
        <div className="space-y-6 animate-in fade-in">
          {/* Header & Filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">SUPER ADMIN EXCLUSIVE</span>
                <span className="text-xs text-stone-400 font-mono">• Solusi &amp; Link How-To (by CS)</span>
              </div>
              <h2 className="font-display font-bold text-base text-[#141517] mt-1">Kelola Solusi &amp; Link Eksternal Rekan CS</h2>
              <p className="text-xs text-[#52545A]">Lihat siapa pembuat asli artikel panduan yang dibagikan oleh staf, dan hapus jika tidak relevan atau duplikat.</p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={fetchAdminCsLinks}
                disabled={loadingCsLinks}
                className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 border border-stone-200 rounded-xl text-xs font-semibold text-stone-700 transition flex items-center space-x-1.5"
              >
                <span>🔄</span>
                <span>{loadingCsLinks ? 'Memuat...' : 'Refresh Data'}</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs flex items-center justify-between">
              <div>
                <span className="micro-label">Total Link Solusi CS Aktif</span>
                <p className="font-display font-extrabold text-2xl text-emerald-700 mt-1">{csLinks.length}</p>
                <span className="text-[11px] text-stone-500">Tampil otomatis di hasil pencarian dengan badge (by CS)</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-lg font-bold">
                🔗
              </div>
            </div>

            <div className="p-4 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs flex items-center justify-between">
              <div>
                <span className="micro-label">Privasi Pengirim</span>
                <p className="font-display font-bold text-sm text-stone-900 mt-1">Anonim untuk CS Lain</p>
                <span className="text-[11px] text-stone-500">Nama pembuat hanya bisa dilihat oleh Super Admin di halaman ini.</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-lg font-bold">
                🛡️
              </div>
            </div>
          </div>

          {/* Table of CS Links */}
          <div className="editorial-card p-5 rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E3E3DC] pb-3">
              <h3 className="font-display font-bold text-xs text-[#141517] uppercase tracking-wider">
                Daftar Link Panduan ({csLinks.length})
              </h3>
              <div className="w-full sm:w-72">
                <input
                  type="text"
                  value={linkSearch}
                  onChange={(e) => setLinkSearch(e.target.value)}
                  placeholder="Cari judul link atau nama pembuat..."
                  className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-1.5 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#E3E3DC] text-stone-500">
                    <th className="pb-2.5 font-semibold w-12">No</th>
                    <th className="pb-2.5 font-semibold">Judul Solusi / Panduan</th>
                    <th className="pb-2.5 font-semibold">Kategori</th>
                    <th className="pb-2.5 font-semibold">Dibuat Oleh (Asli)</th>
                    <th className="pb-2.5 font-semibold">Link Tujuan</th>
                    <th className="pb-2.5 font-semibold text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3DC]">
                  {csLinks
                    .filter((l) => {
                      if (!linkSearch.trim()) return true;
                      const s = linkSearch.toLowerCase();
                      return (
                        l.title?.toLowerCase().includes(s) ||
                        l.created_by_name?.toLowerCase().includes(s) ||
                        l.created_by_username?.toLowerCase().includes(s)
                      );
                    })
                    .map((item, idx) => (
                      <tr key={item.id} className="hover:bg-stone-50/70 transition">
                        <td className="py-3 font-mono text-stone-400">{idx + 1}</td>
                        <td className="py-3 font-semibold text-stone-900 max-w-xs">
                          <div className="space-y-0.5">
                            <p className="line-clamp-1">{item.title}</p>
                            {item.description && (
                              <p className="text-[11px] text-stone-500 font-normal line-clamp-1">{item.description}</p>
                            )}
                          </div>
                        </td>
                        <td className="py-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                            {item.category || 'Rekomendasi CS'}
                          </span>
                        </td>
                        <td className="py-3">
                          <div className="font-mono text-xs">
                            <span className="font-bold text-rose-900">{item.created_by_name || 'Rekan CS'}</span>
                            <span className="text-stone-400 text-[11px] ml-1">(@{item.created_by_username || 'cs'})</span>
                          </div>
                        </td>
                        <td className="py-3 text-blue-600 font-mono text-[11px] max-w-xs truncate">
                          <a href={item.url} target="_blank" rel="noopener noreferrer" className="hover:underline flex items-center space-x-1">
                            <span className="truncate">{item.url}</span>
                            <span>↗</span>
                          </a>
                        </td>
                        <td className="py-3 text-right">
                          <button
                            type="button"
                            onClick={() => handleDeleteAdminCsLink(item.id, item.title)}
                            disabled={deletingAdminLinkId === item.id}
                            className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-[11px] font-semibold transition disabled:opacity-50"
                          >
                            {deletingAdminLinkId === item.id ? 'Menghapus...' : '🗑️ Hapus'}
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>

              {csLinks.length === 0 && !loadingCsLinks && (
                <div className="py-8 text-center text-stone-400 space-y-1">
                  <p className="text-sm">Belum ada link panduan yang dibagikan oleh tim CS.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : adminTab === 'audit' ? (
        <div className="space-y-6 animate-in fade-in">
          {/* Header & Filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-white border border-[#E3E3DC] rounded-2xl shadow-2xs">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 text-[10px] font-bold">SUPER ADMIN ONLY</span>
                <span className="text-xs text-stone-400 font-mono">• Audit Trail &amp; Analytics</span>
              </div>
              <h2 className="font-display font-bold text-sm text-[#141517] mt-1">Audit Pembacaan Tutorial Tim CS</h2>
              <p className="text-xs text-[#52545A]">Pantau artikel panduan yang dibuka, agen teraktif, dan sumber akses (Web vs Chrome Extension).</p>
            </div>
            <div className="flex items-center space-x-2">
              <select
                value={agentFilter}
                onChange={(e) => setAgentFilter(e.target.value)}
                className="bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-1.5 text-xs text-[#141517] font-medium outline-none"
              >
                <option value="all">Semua Rekan CS (16 Staf)</option>
                {auditStats.by_agent?.map((ag: any) => (
                  <option key={ag.username} value={ag.username}>
                    {ag.username} ({ag.count}x dibuka)
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={fetchAuditStats}
                disabled={loadingAudit}
                className="px-3.5 py-1.5 rounded-xl bg-stone-900 text-white text-xs font-semibold hover:bg-black transition flex items-center space-x-1.5"
              >
                <span>{loadingAudit ? 'Memuat...' : '🔄 Segarkan'}</span>
              </button>
            </div>
          </div>

          {/* 4 Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="editorial-card p-4 rounded-2xl space-y-1">
              <span className="micro-label">Total Dibuka</span>
              <p className="text-2xl font-bold font-mono text-[#141517]">{auditStats.total_views || 0}</p>
              <p className="text-[10px] text-stone-500">Akumulasi seluruh staf</p>
            </div>
            <div className="editorial-card p-4 rounded-2xl space-y-1">
              <span className="micro-label">Dibuka Hari Ini</span>
              <p className="text-2xl font-bold font-mono text-emerald-700">{auditStats.views_today || 0}</p>
              <p className="text-[10px] text-stone-500">Aktivitas 24 jam terakhir</p>
            </div>
            <div className="editorial-card p-4 rounded-2xl space-y-1">
              <span className="micro-label">Agen Teraktif</span>
              <p className="text-base font-bold text-blue-700 truncate capitalize">
                {auditStats.by_agent?.[0]?.username || 'Belum ada data'}
              </p>
              <p className="text-[10px] text-stone-500 font-mono">
                {auditStats.by_agent?.[0]?.count ? `${auditStats.by_agent[0].count} panduan dibuka` : '-'}
              </p>
            </div>
            <div className="editorial-card p-4 rounded-2xl space-y-1">
              <span className="micro-label">Distribusi Sumber</span>
              <div className="flex items-center space-x-3 pt-1 text-xs font-semibold">
                <span className="text-blue-700">Web: {auditStats.by_source?.find((s: any) => s.source === 'web')?.count || 0}</span>
                <span className="text-purple-700">Ext: {auditStats.by_source?.find((s: any) => s.source === 'extension')?.count || 0}</span>
              </div>
              <p className="text-[10px] text-stone-500">Web Portal vs Extension</p>
            </div>
          </div>

          {/* 2 Grid Tables: Leaderboard & Top Tutorials */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Leaderboard CS Agents */}
            <div className="editorial-card p-5 rounded-2xl space-y-3">
              <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-2">
                <h3 className="font-display font-bold text-xs text-[#141517] uppercase tracking-wider">
                  🏆 Leaderboard Aktivitas CS (16 Rekan Staf)
                </h3>
                <span className="text-[10px] text-stone-400 font-mono">Frekuensi Pembacaan</span>
              </div>
              <div className="divide-y divide-[#E3E3DC] max-h-72 overflow-y-auto">
                {auditStats.by_agent?.length > 0 ? (
                  auditStats.by_agent.map((agent: any, idx: number) => (
                    <div key={agent.username} className="py-2.5 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2.5">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                          idx === 0 ? 'bg-amber-100 text-amber-800' : idx === 1 ? 'bg-stone-200 text-stone-700' : idx === 2 ? 'bg-amber-50 text-amber-700' : 'bg-stone-100 text-stone-600'
                        }`}>
                          {idx + 1}
                        </span>
                        <div>
                          <p className="font-semibold text-[#141517] capitalize">{agent.username}</p>
                          <span className="text-[10px] text-stone-400 uppercase font-mono">{agent.user_role}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-sm text-stone-900">{agent.count}</span>
                        <span className="text-[10px] text-stone-500 ml-1">artikel dibuka</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="py-4 text-center text-xs text-stone-400">Belum ada riwayat aktivitas staf.</p>
                )}
              </div>
            </div>

            {/* Top Tutorials Read */}
            <div className="editorial-card p-5 rounded-2xl space-y-3">
              <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-2">
                <h3 className="font-display font-bold text-xs text-[#141517] uppercase tracking-wider">
                  📖 Panduan Paling Sering Dicari CS
                </h3>
                <span className="text-[10px] text-stone-400 font-mono">Top Dibuka</span>
              </div>
              <div className="divide-y divide-[#E3E3DC] max-h-72 overflow-y-auto">
                {auditStats.top_tutorials?.length > 0 ? (
                  auditStats.top_tutorials.map((tut: any, idx: number) => (
                    <div key={tut.tutorial_title + idx} className="py-2.5 space-y-1 text-xs">
                      <div className="flex items-start justify-between gap-2">
                        <a
                          href={tut.tutorial_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-medium text-blue-700 hover:underline line-clamp-1 flex-1"
                        >
                          {tut.tutorial_title}
                        </a>
                        <span className="font-mono font-bold text-stone-900 shrink-0">{tut.count}x</span>
                      </div>
                      <p className="text-[10px] text-stone-500">
                        Dibuka oleh: <span className="font-medium text-stone-700 capitalize">{tut.viewers || 'Staf'}</span>
                      </p>
                    </div>
                  ))
                ) : (
                  <p className="py-4 text-center text-xs text-stone-400">Belum ada tutorial yang dibuka.</p>
                )}
              </div>
            </div>
          </div>

          {/* Real-time Access Log Table */}
          <div className="editorial-card p-5 rounded-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-[#E3E3DC] pb-2">
              <div>
                <h3 className="font-display font-bold text-xs text-[#141517] uppercase tracking-wider">
                  🕒 Log Akses Real-Time Tutorial
                </h3>
                <p className="text-[11px] text-stone-500">Catatan kronologis staf membuka dokumentasi dari Web atau Extension.</p>
              </div>
              <span className="text-[10px] text-stone-400 font-mono">50 Entri Terakhir</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#E3E3DC] text-[10px] text-stone-400 uppercase font-mono">
                    <th className="py-2 pr-3">Waktu</th>
                    <th className="py-2 px-3">Nama CS</th>
                    <th className="py-2 px-3">Judul Tutorial</th>
                    <th className="py-2 px-3">Sumber</th>
                    <th className="py-2 pl-3 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3DC]">
                  {auditStats.recent_logs
                    ?.filter((l: any) => agentFilter === 'all' || l.username.toLowerCase() === agentFilter.toLowerCase())
                    .map((log: any) => (
                      <tr key={log.id} className="hover:bg-stone-50/60 transition">
                        <td className="py-2.5 pr-3 text-[11px] text-stone-500 font-mono whitespace-nowrap">
                          {log.viewed_at ? new Date(log.viewed_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '-'}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-[#141517] capitalize whitespace-nowrap">
                          {log.username}
                        </td>
                        <td className="py-2.5 px-3 max-w-md truncate text-stone-700">
                          {log.tutorial_title}
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            log.source === 'extension' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {log.source === 'extension' ? '🧩 Extension' : '🌐 Web Portal'}
                          </span>
                        </td>
                        <td className="py-2.5 pl-3 text-right whitespace-nowrap">
                          <a
                            href={log.tutorial_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[11px] text-blue-600 hover:underline"
                          >
                            Lihat ↗
                          </a>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* CHECKLIST MANAGER TAB */
        <>
          {/* 3 TOP CARDS: TAMBAH KATEGORI, KASUS, & INDEKS TUTORIAL */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Tambah Kategori */}
        <div className="editorial-card p-5 rounded-2xl space-y-3">
          <span className="micro-label">1. Kategori Platform</span>
          <div className="flex gap-2">
            <input
              type="text"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="Contoh: WordPress / Laravel / Node.js"
              className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-2.5 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
            />
            <button
              onClick={handleAddCategory}
              className="px-4 py-2 bg-[#141517] text-white text-xs font-semibold rounded-xl hover:bg-stone-800 transition shrink-0 shadow-2xs"
            >
              + Tambah
            </button>
          </div>
        </div>

        {/* Tambah Kasus */}
        <div className="editorial-card p-5 rounded-2xl space-y-3">
          <span className="micro-label">2. Judul Kasus Spesifik</span>
          <div className="space-y-2">
            <select
              value={selectedCategoryId}
              onChange={(e) => {
                const id = Number(e.target.value);
                setSelectedCategoryId(id);
                const first = subcategories.find((s) => s.category_id === id);
                if (first) setSelectedSubcategoryId(first.id);
                else setSelectedSubcategoryId(0);
              }}
              className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none focus:border-stone-400"
            >
              <option value="">-- Pilih Kategori Induk --</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>

            <div className="flex gap-2">
              <input
                type="text"
                value={newSubcategoryTitle}
                onChange={(e) => setNewSubcategoryTitle(e.target.value)}
                placeholder="Contoh: Critical Error 500 / Yahoo Bounce"
                className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl p-2.5 text-xs text-[#141517] outline-none focus:border-stone-400 placeholder-[#71737B]"
              />
              <button
                onClick={handleAddSubcategory}
                className="px-4 py-2 bg-[#141517] text-white text-xs font-semibold rounded-xl hover:bg-stone-800 transition shrink-0 shadow-2xs"
              >
                + Tambah
              </button>
            </div>
          </div>
        </div>

        {/* Indeks Tutorial JagoanSearch */}
        <div className="editorial-card p-5 rounded-2xl space-y-3 flex flex-col justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="micro-label">3. Tutorial JagoanSearch</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                {tutorialCount} Ter-indeks
              </span>
            </div>
            <p className="text-xs text-[#52545A]">Database pencarian tutorial resmi Jagoan Hosting dengan respon sub-milidetik.</p>
          </div>

          <div className="space-y-2 pt-1">
            <button
              onClick={handleSyncSitemap}
              disabled={syncing}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition flex items-center justify-center space-x-1.5 shadow-2xs disabled:opacity-75"
            >
              {syncing ? (
                <span>Menyinkronkan sitemap...</span>
              ) : (
                <span>⚡ Sinkronkan Sitemap Jagoan Hosting</span>
              )}
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={handleReindex}
                disabled={reindexing}
                className="w-full py-2 bg-stone-100 hover:bg-stone-200 border border-[#E3E3DC] text-stone-700 text-xs font-medium rounded-xl transition flex items-center justify-center space-x-1.5"
              >
                {reindexing ? <span>Meng-index...</span> : <span>🔄 Reset Indeks Lokal</span>}
              </button>
              <Link
                href="/"
                className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-[#141517] text-xs font-semibold rounded-xl border border-[#E3E3DC] transition shrink-0"
                title="Buka Mesin Pencari"
              >
                Buka ↗
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* POHON KEPUTUSAN & BUILDER LANGKAH */}
      <div className="editorial-card p-6 rounded-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E3E3DC] pb-4">
          <div>
            <span className="micro-label">Struktur Alur</span>
            <h2 className="font-display font-bold text-sm text-[#141517] mt-0.5">Langkah Investigasi &amp; Percabangan</h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  setSelectedCategoryId(cat.id);
                  const first = subcategories.find((s) => s.category_id === cat.id);
                  if (first) setSelectedSubcategoryId(first.id);
                  else setSelectedSubcategoryId(0);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                  selectedCategoryId === cat.id
                    ? 'bg-[#141517] text-white border-[#141517]'
                    : 'bg-stone-50 text-[#52545A] border-[#E3E3DC] hover:border-stone-400'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {selectedCategoryId && currentSubcategories.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 pt-1 border-b border-[#E3E3DC] pb-4">
            <span className="micro-label mr-1">Kasus:</span>
            {currentSubcategories.map((sub) => (
              <button
                key={sub.id}
                type="button"
                onClick={() => setSelectedSubcategoryId(sub.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                  selectedSubcategoryId === sub.id
                    ? 'bg-stone-800 text-white border-stone-800'
                    : 'bg-white text-[#52545A] border-[#E3E3DC] hover:border-stone-400'
                }`}
              >
                {sub.title}
              </button>
            ))}
          </div>
        )}

        {!selectedSubcategoryId ? (
          <div className="text-center py-10 space-y-2 text-xs text-[#71737B]">
            <p>Pilih kategori dan kasus di atas untuk melihat serta mengatur langkah investigasi.</p>
          </div>
        ) : (
          /* WORKSPACE BUILDER */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* FORM TAMBAH LANGKAH (ROOT ATAU CABANG) */}
            <div className="lg:col-span-5 bg-stone-50 p-5 rounded-2xl border border-[#E3E3DC] space-y-4">
              {branchParentId ? (
                /* Form Tambah Cabang */
                <div className="space-y-3 border-l-2 border-stone-800 pl-3">
                  <div className="flex items-center justify-between">
                    <span className="micro-label text-[#141517]">↳ Tambah Anak Cabang</span>
                    <button onClick={handleCancelBranchTarget} className="text-[#71737B] hover:text-[#141517] text-xs">
                      Batal
                    </button>
                  </div>
                  <p className="text-xs text-[#52545A]">
                    Terbuka jika pilihan:{' '}
                    <strong className="bg-white px-1.5 py-0.5 rounded border border-[#E3E3DC] text-[#141517]">
                      "{branchTriggerCondition}"
                    </strong>
                  </p>

                  <div className="space-y-2">
                    <div>
                      <label className="micro-label block mb-1">Deskripsi Langkah</label>
                      <input
                        type="text"
                        value={branchTask}
                        onChange={(e) => setBranchTask(e.target.value)}
                        placeholder="Nama tindakan perbaikan..."
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none"
                      />
                    </div>
                    <div>
                      <label className="micro-label block mb-1">Command Snippet (Opsional)</label>
                      <input
                        type="text"
                        value={branchCommandSnippet}
                        onChange={(e) => setBranchCommandSnippet(e.target.value)}
                        placeholder="Contoh: wp plugin deactivate..."
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs font-mono text-stone-800 outline-none"
                      />
                    </div>
                    <div>
                      <label className="micro-label block mb-1">Petunjuk / Hint (Opsional)</label>
                      <input
                        type="text"
                        value={branchHint}
                        onChange={(e) => setBranchHint(e.target.value)}
                        placeholder="Penjelasan praktis..."
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#52545A] outline-none"
                      />
                    </div>
                    <div>
                      <label className="micro-label block mb-1">Tipe Langkah</label>
                      <select
                        value={branchTaskType}
                        onChange={(e: any) => setBranchTaskType(e.target.value)}
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none"
                      >
                        <option value="standard">Tindakan Centang Biasa</option>
                        <option value="choice">Pertanyaan Pilihan Cabang</option>
                      </select>
                    </div>
                    {branchTaskType === 'choice' && (
                      <div>
                        <label className="micro-label block mb-1">Opsi Pilihan (Pisahkan dengan Koma)</label>
                        <input
                          type="text"
                          value={branchOptionsInput}
                          onChange={(e) => setBranchOptionsInput(e.target.value)}
                          className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none"
                        />
                      </div>
                    )}
                    <button
                      onClick={handleAddBranchItem}
                      className="w-full py-2 bg-[#141517] text-white font-semibold rounded-xl text-xs hover:bg-stone-800 transition shadow-2xs"
                    >
                      Simpan Cabang
                    </button>
                  </div>
                </div>
              ) : (
                /* Form Tambah Langkah Utama (Root) */
                <div className="space-y-3">
                  <span className="micro-label text-[#141517]">+ Tambah Langkah Utama</span>

                  <div className="space-y-2">
                    <div>
                      <label className="micro-label block mb-1">Deskripsi Langkah</label>
                      <input
                        type="text"
                        value={newTask}
                        onChange={(e) => setNewTask(e.target.value)}
                        placeholder="Contoh: Tahap 1: Uji coba tema default..."
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none"
                      />
                    </div>
                    <div>
                      <label className="micro-label block mb-1">Command Snippet (Opsional)</label>
                      <input
                        type="text"
                        value={newCommandSnippet}
                        onChange={(e) => setNewCommandSnippet(e.target.value)}
                        placeholder="Contoh: wp theme activate..."
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs font-mono text-stone-800 outline-none"
                      />
                    </div>
                    <div>
                      <label className="micro-label block mb-1">Petunjuk / Hint (Opsional)</label>
                      <input
                        type="text"
                        value={newHint}
                        onChange={(e) => setNewHint(e.target.value)}
                        placeholder="Penjelasan praktis..."
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#52545A] outline-none"
                      />
                    </div>
                    <div>
                      <label className="micro-label block mb-1">Tipe Langkah</label>
                      <select
                        value={taskType}
                        onChange={(e: any) => setTaskType(e.target.value)}
                        className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none"
                      >
                        <option value="standard">Tindakan Centang Biasa</option>
                        <option value="choice">Pertanyaan Pilihan Cabang</option>
                      </select>
                    </div>
                    {taskType === 'choice' && (
                      <div>
                        <label className="micro-label block mb-1">Opsi Pilihan (Pisahkan dengan Koma)</label>
                        <input
                          type="text"
                          value={optionsInput}
                          onChange={(e) => setOptionsInput(e.target.value)}
                          className="w-full bg-white border border-[#E3E3DC] rounded-xl p-2 text-xs text-[#141517] outline-none"
                        />
                      </div>
                    )}
                    <button
                      onClick={handleAddChecklistItem}
                      className="w-full py-2 bg-[#141517] text-white font-semibold rounded-xl text-xs hover:bg-stone-800 transition shadow-2xs"
                    >
                      + Tambah Langkah
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* DAFTAR POHON LANGKAH */}
            <div className="lg:col-span-7 space-y-3">
              <span className="micro-label">Pohon Langkah yang Terdaftar</span>

              <div className="space-y-3">
                {currentRootSteps.map((step, idx) => {
                  const children = checklists.filter((c) => c.parent_id === step.id);
                  return (
                    <div key={step.id} className="p-3.5 rounded-xl bg-white border border-[#E3E3DC] space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start space-x-2">
                          <span className="w-5 h-5 rounded-full bg-stone-100 text-stone-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5 border border-[#E3E3DC]">
                            0{idx + 1}
                          </span>
                          <div>
                            <p className="text-xs font-semibold text-[#141517]">{step.task}</p>
                            {step.command_snippet && (
                              <p className="text-[11px] font-mono text-stone-600 mt-1">$ {step.command_snippet}</p>
                            )}
                            {step.hint && <p className="text-[11px] text-[#71737B] mt-0.5">{step.hint}</p>}
                          </div>
                        </div>
                        <button
                          onClick={() => handleDeleteChecklistItem(step.id)}
                          className="text-[#71737B] hover:text-rose-600 text-xs"
                        >
                          Hapus
                        </button>
                      </div>

                      {/* Choice Options & Child Branches */}
                      {step.type === 'choice' && (
                        <div className="pl-7 space-y-2 pt-2 border-t border-[#E3E3DC]">
                          <div className="flex flex-wrap gap-1.5">
                            {(step.options || []).map((opt) => (
                              <div
                                key={opt}
                                className="inline-flex items-center space-x-1.5 bg-stone-50 border border-[#E3E3DC] px-2.5 py-1 rounded-lg text-[11px]"
                              >
                                <span className="text-[#141517] font-semibold">{opt}</span>
                                <button
                                  onClick={() => handleSetBranchTarget(step.id, opt)}
                                  className="text-emerald-700 hover:underline font-semibold text-[10px]"
                                >
                                  + Buat Cabang
                                </button>
                              </div>
                            ))}
                          </div>

                          {/* Children */}
                          {children.map((child) => {
                            const grandChildren = checklists.filter((c) => c.parent_id === child.id);
                            return (
                              <div key={child.id} className="ml-4 p-2.5 rounded-lg bg-stone-50 border border-[#E3E3DC] space-y-2">
                                <div className="flex items-start justify-between gap-2">
                                  <div>
                                    <span className="text-[10px] text-stone-600 font-semibold block">
                                      ↳ Jika: "{child.trigger_condition}"
                                    </span>
                                    <p className="text-xs text-[#141517] mt-0.5">{child.task}</p>
                                    {child.command_snippet && (
                                      <span className="text-[11px] font-mono text-stone-600 block mt-0.5">
                                        $ {child.command_snippet}
                                      </span>
                                    )}
                                  </div>
                                  <button
                                    onClick={() => handleDeleteChecklistItem(child.id)}
                                    className="text-[#71737B] hover:text-rose-600 text-xs"
                                  >
                                    Hapus
                                  </button>
                                </div>

                                {child.type === 'choice' && (
                                  <div className="pl-3 space-y-2 pt-2 border-t border-[#E3E3DC]">
                                    <div className="flex flex-wrap gap-1.5">
                                      {(child.options || []).map((cOpt) => (
                                        <div
                                          key={cOpt}
                                          className="inline-flex items-center space-x-1.5 bg-white border border-[#E3E3DC] px-2 py-0.5 rounded text-[10px]"
                                        >
                                          <span className="text-[#141517] font-semibold">{cOpt}</span>
                                          <button
                                            onClick={() => handleSetBranchTarget(child.id, cOpt)}
                                            className="text-emerald-700 hover:underline font-semibold"
                                          >
                                            + Cabang
                                          </button>
                                        </div>
                                      ))}
                                    </div>

                                    {grandChildren.map((grandChild) => (
                                      <div
                                        key={grandChild.id}
                                        className="ml-3 p-2 rounded bg-white border border-[#E3E3DC] flex items-start justify-between gap-2 text-[11px]"
                                      >
                                        <div>
                                          <span className="text-[9px] text-stone-500 font-semibold block">
                                            ↳ Jika: "{grandChild.trigger_condition}"
                                          </span>
                                          <p className="text-[#141517] font-medium">{grandChild.task}</p>
                                          {grandChild.command_snippet && (
                                            <span className="font-mono text-stone-600 block text-[10px]">
                                              $ {grandChild.command_snippet}
                                            </span>
                                          )}
                                        </div>
                                        <button
                                          onClick={() => handleDeleteChecklistItem(grandChild.id)}
                                          className="text-[#71737B] hover:text-rose-600 text-[10px]"
                                        >
                                          Hapus
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}

                {currentRootSteps.length === 0 && (
                  <div className="text-center py-6 text-xs text-[#71737B]">Belum ada langkah yang dikonfigurasi untuk kasus ini.</div>
                )}
              </div>
            </div>

          </div>
        )}
      </div>
    </>
  )}

      {/* MODAL TAMBAH USER / AKUN CS */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={() => setShowAddUserModal(false)} />
          <div className="flex min-h-full items-center justify-center p-4">
            <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:w-full sm:max-w-md border border-stone-200 p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-sm font-bold">
                    ➕
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-sm text-[#141517]">Tambah Akun CS Baru</h3>
                    <p className="text-[11px] text-[#71737B]">Akun langsung aktif di portal Web &amp; Extension.</p>
                  </div>
                </div>
                <button onClick={() => setShowAddUserModal(false)} className="text-stone-400 hover:text-stone-700 text-sm font-bold">✕</button>
              </div>

              {userError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-medium">
                  {userError}
                </div>
              )}

              <form onSubmit={handleCreateUser} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Username Login <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    value={newStaffUsername}
                    onChange={(e) => setNewStaffUsername(e.target.value.toLowerCase().replace(/[^a-z0-9._-]/g, ''))}
                    placeholder="misal: rizal / farras / dani"
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400 font-mono"
                    required
                    autoFocus
                  />
                  <p className="text-[10px] text-stone-500 mt-0.5">Hanya huruf kecil, angka, titik, atau strip tanpa spasi.</p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Nama Lengkap CS <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    value={newStaffName}
                    onChange={(e) => setNewStaffName(e.target.value)}
                    placeholder="misal: Rizal Fahmi"
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400"
                    required
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-stone-700">Password</label>
                    <button
                      type="button"
                      onClick={generateRandomPassword}
                      className="text-[10px] text-blue-600 hover:text-blue-800 font-bold flex items-center space-x-1"
                    >
                      <span>🎲 Acak Password</span>
                    </button>
                  </div>
                  <input
                    type="text"
                    value={newStaffPassword}
                    onChange={(e) => setNewStaffPassword(e.target.value)}
                    placeholder="Biarkan kosong untuk auto-generate"
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Hak Akses (Role)</label>
                  <select
                    value={newStaffRole}
                    onChange={(e: any) => setNewStaffRole(e.target.value)}
                    className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400 font-medium"
                  >
                    <option value="agent">🎧 Tim Customer Support (CS Agent)</option>
                    <option value="admin">👑 Administrator (Super Admin)</option>
                  </select>
                </div>

                <div className="pt-2 flex items-center justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setShowAddUserModal(false)}
                    className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-medium transition"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={creatingUser}
                    className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs disabled:opacity-50"
                  >
                    {creatingUser ? 'Menyimpan...' : 'Simpan Akun CS'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* MODAL RESET / UBAH PASSWORD */}
      {editingUser && (
        <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={() => setEditingUser(null)} />
          <div className="flex min-h-full items-center justify-center p-4">
            <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:w-full sm:max-w-sm border border-stone-200 p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <h3 className="font-display font-bold text-sm text-[#141517]">Ubah Password @{editingUser.username}</h3>
                <button onClick={() => setEditingUser(null)} className="text-stone-400 hover:text-stone-700 text-sm font-bold">✕</button>
              </div>

              <div className="space-y-3">
                <p className="text-xs text-stone-600">
                  Masukkan password baru untuk <strong>{editingUser.name}</strong>:
                </p>
                <input
                  type="text"
                  value={editPasswordInput}
                  onChange={(e) => setEditPasswordInput(e.target.value)}
                  placeholder="Ketik kata sandi baru..."
                  className="w-full bg-stone-50 border border-[#E3E3DC] rounded-xl px-3 py-2 text-xs text-[#141517] outline-none focus:border-stone-400 font-mono"
                  autoFocus
                />
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-medium transition"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveNewPassword}
                    disabled={savingPassword || !editPasswordInput.trim()}
                    className="px-4 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition disabled:opacity-50"
                  >
                    {savingPassword ? 'Menyimpan...' : 'Simpan Password'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
</div>
  );
}
